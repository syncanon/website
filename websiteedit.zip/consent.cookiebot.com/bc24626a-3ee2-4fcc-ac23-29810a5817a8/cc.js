// 2.91.0 - 2025-05-20T09:07:05.267Z
! function() {
    var DialogVersion;
    ! function(DialogVersion) {
        DialogVersion[DialogVersion.ElementalCustom = 1] = "ElementalCustom", DialogVersion[DialogVersion.Swift = 2] = "Swift"
    }(DialogVersion || (DialogVersion = {}));
    var css = '#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner *{background:transparent;box-sizing:border-box;color:inherit;font-family:inherit;font-size:15px;margin:0;outline:0;padding:0;vertical-align:baseline}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBannerWrapper,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner{display:none}#CybotCookiebotDialogWrapper.CybotCookiebotDialogActive+#CybotCookiebotDialogBodyUnderlay{opacity:.75;pointer-events:auto}@media screen and (min-width:1280px){#CybotCookiebotDialogWrapper{opacity:0;transition:opacity .5s ease}#CybotCookiebotDialogWrapper.CybotCookiebotDialogActive{left:50%;opacity:1;position:fixed;top:50%;transform:translate(-50%,-50%);width:900px;z-index:2147483631}#CybotCookiebotDialogWrapper.CybotCookiebotDialogActive #CybotCookiebotDialog{left:auto;margin:0;max-width:auto;position:relative;top:auto;transform:translate(0);transition:none;width:100%}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner.CybotCookiebotDialogActive{align-items:center;background:#051041;border-radius:8px;box-shadow:0 30px 70px rgba(20,20,20,.3);color:#fff;display:flex;font-family:sans-serif;justify-content:space-between;margin-bottom:8px;overflow:hidden;padding:16px 16px 16px 24px;text-decoration:none}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner p,#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner strong,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner p,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner strong{letter-spacing:.3px;line-height:25px;margin:0}#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner strong{font-size:18px}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner p,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner p{font-size:15px;opacity:.7}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerButtonsWrapper,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerButtonsWrapper{align-items:flex-start;display:flex}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner button,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner button{align-items:center;display:flex;justify-content:center}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerInstallButton,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerInstallButton{background:linear-gradient(180deg,#1032CF,#2E52EF);border:none;border-radius:4px;color:#fff;cursor:pointer;font-size:15px;font-weight:600;letter-spacing:.1px;margin-right:8px;padding:12px 16px 12px 12px;position:relative;z-index:1}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerInstallButton:before,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerInstallButton:before{background:linear-gradient(180deg,#1032CF,#5471F2);border-radius:inherit;box-shadow:0 0 40px rgba(46,82,239,.8);content:"";height:100%;left:0;opacity:0;position:absolute;top:0;transition:all .75s ease;width:100%;z-index:-1}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner:hover .CybotCookiebotDialogPromotionBannerInstallButton:before,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner:hover .CybotCookiebotDialogPromotionBannerInstallButton:before{opacity:1}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerInstallButton svg,#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerInstallButton svg{margin-right:8px}#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner #CybotCookiebotDialogPromotionBannerCloseButton{fill:#fff;align-content:center;background:none;border:none;cursor:pointer;display:flex;height:24px;justify-content:center;width:24px}#CybotCookiebotDialogWrapper .CybotCookiebotDialogPromotionBanner #CybotCookiebotDialogPromotionBannerCloseButton svg{height:14px;width:14px}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBannerWrapper{display:block;padding-top:16px}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner{background:#ECEFFE;border-radius:16px;box-shadow:none;color:#141414}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner strong{font-size:17px}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner .CybotCookiebotDialogPromotionBannerInstallButton{margin:0}#CybotCookiebotDialog .CybotCookiebotDialogPromotionBanner #CybotCookiebotDialogPromotionBannerCloseButton{display:none}}';

    function appendStylesheet(document, updatedStylesheet, canShowPromotionBanner) {
        var head = document.head || document.getElementsByTagName("head")[0],
            styleElement = document.createElement("style");
        styleElement.setAttribute("type", "text/css"), styleElement.id = "CookiebotDialogStyle", styleElement.appendChild(document.createTextNode(updatedStylesheet)), canShowPromotionBanner && styleElement.appendChild(document.createTextNode(css)), head.appendChild(styleElement)
    }
    var generateStylesAndAppendStylesheet = function(document, dialog, templatename) {
            var newstylesheet;
            if ("custom" === templatename) return newstylesheet = dialog.customTemplateDef.CSS, void appendStylesheet(document, newstylesheet, dialog.canShowPromotionBanner);
            var isDefaultColorTheme = "white" === dialog.theme || "dark" === dialog.theme,
                isWhiteTheme = "white" === dialog.theme,
                isDarkTheme = "dark" === dialog.theme;
            if (newstylesheet = dialog.styles[templatename], dialog.version === DialogVersion.ElementalCustom) return isDefaultColorTheme && (dialog.customColors.background = isWhiteTheme ? "#ffffff" : "#161616", dialog.customColors.text = isWhiteTheme ? "#2a2a2a" : "#ffffff", dialog.customColors.acceptbutton = "#188600", dialog.customColors.selectionbutton = "#188600", dialog.customColors.declinebutton = "#333333", dialog.customColors.buttontext = "#ffffff", dialog.customColors.tab = isWhiteTheme ? "#f6f6f9" : "#262626", dialog.customColors.border = isWhiteTheme ? "#cccccc" : "#404040"), newstylesheet = newstylesheet.replace(/#000001/g, dialog.customColors.background).replace(/#000002/g, dialog.customColors.text).replace(/#000003/g, dialog.customColors.acceptbutton).replace(/#000004/g, dialog.customColors.declinebutton).replace(/#000005/g, dialog.customColors.buttontext).replace(/#000006/g, dialog.customColors.tab).replace(/#000008/g, dialog.customColors.border).replace(/#000009/g, dialog.customColors.selectionbutton).replace(/url\(showdetails\.png\)/g, "url(" + dialog.customImages.showdetails + ")").replace(/url\(hidedetails\.png\)/g, "url(" + dialog.customImages.hidedetails + ")").replace(/url\(CheckedNofocus\.png\)/g, "url(" + dialog.customImages.cbCheckedNofocus + ")").replace(/url\(CheckedFocus\.png\)/g, "url(" + dialog.customImages.cbCheckedFocus + ")").replace(/url\(CheckedDisabled\.png\)/g, "url(" + dialog.customImages.cbCheckedDisabled + ")").replace(/url\(NotCheckedFocus\.png\)/g, "url(" + dialog.customImages.cbNotCheckedFocus + ")").replace(/url\(NotCheckedNoFocus\.png\)/g, "url(" + dialog.customImages.cbNotCheckedNoFocus + ")"), void appendStylesheet(document, newstylesheet, dialog.canShowPromotionBanner);
            if (dialog.version === DialogVersion.Swift) {
                if (newstylesheet += getTemporaryStyles(), isDefaultColorTheme) {
                    var primaryColor = isWhiteTheme ? "#1032CF" : "#2EA7FF",
                        textColor = isWhiteTheme ? "#141414" : "#f2f2f2",
                        primaryButtonBackground = primaryColor,
                        primaryButtonBorder = primaryColor,
                        primaryButtonText = isWhiteTheme ? "#ffffff" : "#141414",
                        secondaryButtonBackground = "transparent",
                        secondaryButtonBorder = primaryColor,
                        secondaryButtonText = textColor;
                    "solid" === dialog.bannerButtonDesign ? (secondaryButtonBackground = primaryButtonBackground, secondaryButtonBorder = primaryButtonBorder, secondaryButtonText = primaryButtonText) : "outlined" === dialog.bannerButtonDesign && (primaryButtonBackground = secondaryButtonBackground, primaryButtonBorder = secondaryButtonBorder, primaryButtonText = secondaryButtonText), dialog.customColors.background = isWhiteTheme ? "#ffffff" : "#141414", dialog.customColors.text = textColor, dialog.customColors.highlight = primaryColor, dialog.customColors.shade = isWhiteTheme ? "#D6D6D6" : "rgba(255, 255, 255, 0.08)", dialog.customColors.acceptBackground = primaryButtonBackground, dialog.customColors.acceptBorder = primaryButtonBorder, dialog.customColors.acceptText = primaryButtonText, dialog.customColors.selectionBackground = secondaryButtonBackground, dialog.customColors.selectionBorder = secondaryButtonBorder, dialog.customColors.selectionText = secondaryButtonText, dialog.customColors.declineBackground = secondaryButtonBackground, dialog.customColors.declineBorder = secondaryButtonBorder, dialog.customColors.declineText = secondaryButtonText, dialog.customColors.scrollbarHandle = isWhiteTheme ? "#141414" : "#e2e2e2", dialog.customColors.linkColorDetailsBox = isWhiteTheme ? "#2A4EEF" : "#009AEE", dialog.customColors.detailsBoxBackground = isDarkTheme ? "#232323" : "#F4F4F4"
                } else dialog.customColors.linkColorDetailsBox = dialog.customColors.highlight, dialog.customColors.detailsBoxBackground = isDarkTheme ? "rgba(255, 255, 255, 0.05)" : "rgba(0, 0, 0, 0.05)";
                newstylesheet = newstylesheet.replace(/#000001/g, dialog.customColors.background).replace(/#000002/g, dialog.customColors.text).replace(/#000003/g, dialog.customColors.highlight).replace(/#000004/g, dialog.customColors.shade).replace(/#000005/g, dialog.customColors.acceptBackground).replace(/#000006/g, dialog.customColors.acceptBorder).replace(/#000008/g, dialog.customColors.acceptText).replace(/#000009/g, dialog.customColors.selectionBackground).replace(/#000010/g, dialog.customColors.selectionBorder).replace(/#000012/g, dialog.customColors.selectionText).replace(/#000013/g, dialog.customColors.declineBackground).replace(/#000014/g, dialog.customColors.declineBorder).replace(/#000015/g, dialog.customColors.declineText).replace(/#000016/g, dialog.customColors.detailsBoxBackground).replace(/#000017/g, "#ffffff").replace(/#000020/g, isDarkTheme ? "#ffffff" : dialog.customColors.text).replace(/#000018/g, isDarkTheme ? "#202020" : "#f2f2f2").replace(/#000019/g, isDefaultColorTheme ? dialog.customColors.scrollbarHandle : dialog.customColors.text).replace(/#000023/g, dialog.customColors.linkColorDetailsBox)
            }
            appendStylesheet(document, newstylesheet, dialog.canShowPromotionBanner)
        },
        calculateDoNotSellButtonSizes = function(version) {
            var AcceptButton = document.getElementById("CybotCookiebotDialogBodyButtonAccept"),
                DeclineButton = document.getElementById("CybotCookiebotDialogBodyButtonDecline");
            if (AcceptButton && DeclineButton && null !== AcceptButton.offsetParent && null !== DeclineButton.offsetParent) {
                var buttonPadding = 4;
                if (version === DialogVersion.ElementalCustom) {
                    AcceptButton.style.removeProperty("width"), DeclineButton.style.removeProperty("width");
                    var buttonWidth = Math.max(AcceptButton.clientWidth, DeclineButton.clientWidth),
                        buttonWidthPx = buttonWidth - 4 + "px";
                    AcceptButton.style.width = buttonWidthPx, DeclineButton.style.width = buttonWidthPx
                } else {
                    AcceptButton.style.removeProperty("height"), DeclineButton.style.removeProperty("height");
                    var buttonHeight = Math.max(AcceptButton.clientHeight, DeclineButton.clientHeight),
                        buttonHeightPx = buttonHeight + 4 + "px";
                    AcceptButton.style.height = buttonHeightPx, DeclineButton.style.height = buttonHeightPx
                }
            }
        },
        getTemporaryStyles = function() {
            return '\n    #CybotCookiebotDialog[dir="rtl"] .CybotCookiebotScrollContainer .CybotCookiebotScrollbarContainer {\n      right: auto;\n      left: 0.375em;\n    }\n\n    #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow,\n    #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide {\n        top: .75em;\n        right: 1.35em;\n    }\n\n    #CybotCookiebotDialog[dir="rtl"] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow,\n    #CybotCookiebotDialog[dir="rtl"] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide {\n        left: 1.35em;\n    }\n\n    #CybotCookiebotDialogDetailBodyContentIABv2Tabs #CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonWrapper:nth-of-type(2) {\n      margin-right: 3.5em;\n    }\n\n    #CybotCookiebotDialog[dir="rtl"] #CybotCookiebotDialogDetailBodyContentIABv2Tabs #CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonWrapper:nth-of-type(2) {\n        margin-right: 0;\n        margin-left: 3.5em;\n    }\n\n    #CybotCookiebotDialog .CybotCookiebotDialogBodyContentHeading {\n      margin-bottom: 0.5em;\n      font-weight: 600;\n      line-height: 1.6em;\n      letter-spacing: 0.25px;\n    }\n\n    #CybotCookiebotDialog .CybotCookiebotDialogSROnly {\n      position: absolute;\n      width: 1px;\n      height: 1px;\n      padding: 0;\n      margin: -1px;\n      overflow: hidden;\n      clip: rect(0, 0, 0, 0);\n      border: 0;\n    }\n\n    #CybotCookiebotDialog #CybotCookiebotDialogBodyContentText a,\n    #CybotCookiebotDialog #CybotCookiebotDialogDetailFooter a,\n    #CybotCookiebotDialog #CybotCookiebotDialogDetailBulkConsentList dt a,\n    #CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABDescription a,\n    #CybotCookiebotDialog .CybotCookiebotDialogDetailBodyContentCookieLink,\n    #CybotCookiebotDialog #CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink,\n    #CybotCookiebotDialogDetailBodyContentTextAbout a {\n        color: #000023;\n    }\n\n    #CybotCookiebotDialog #CybotCookiebotDialogBodyContentText a:hover,\n    #CybotCookiebotDialog #CybotCookiebotDialogDetailFooter a:hover,\n    #CybotCookiebotDialog #CybotCookiebotDialogDetailBulkConsentList dt a:hover,\n    #CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABDescription a:hover,\n    #CybotCookiebotDialog .CybotCookiebotDialogDetailBodyContentCookieLink:hover,\n    #CybotCookiebotDialog #CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink:hover,\n    #CybotCookiebotDialogDetailBodyContentTextAbout a:hover,\n    #CybotCookiebotDialog #CybotCookiebotDialogBodyContentText a:focus,\n    #CybotCookiebotDialog #CybotCookiebotDialogDetailFooter a:focus,\n    #CybotCookiebotDialog #CybotCookiebotDialogDetailBulkConsentList dt a:focus,\n    #CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABDescription a:focus,\n    #CybotCookiebotDialog .CybotCookiebotDialogDetailBodyContentCookieLink:focus,\n    #CybotCookiebotDialog #CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink:focus,\n    #CybotCookiebotDialogDetailBodyContentTextAbout a:focus {\n        text-decoration: underline;\n    }\n\n    #CybotCookiebotDialogTabContent {\n      min-height: 60px;\n    }\n\n    #CybotCookiebotDialog .CybotCookiebotScrollContainer {\n      min-height: auto;\n    }\n\n    #CybotCookiebotDialogFooter.CybotCookiebotScrollContainer {\n      height: auto;\n      min-height: 80px;\n      width: 100%;\n    }\n\n    #CybotCookiebotDialogFooter .CybotCookiebotScrollArea {\n      width: 100%;\n      padding: 1em;\n    }\n\n    #CybotCookiebotDialog:not(.CybotCookiebotDialogZoomed) #CybotCookiebotDialogFooter.CybotCookiebotScrollContainer {\n      min-height: 80px;\n      padding: .375em;\n    }\n\n    #CybotCookiebotDialog:not(.CybotCookiebotDialogZoomedLg):not(.CybotCookiebotDialogZoomedXl) #CybotCookiebotDialogFooter.CybotCookiebotScrollContainer {\n      min-height: auto;\n      padding: 0;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter .CybotCookiebotScrollArea,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter .CybotCookiebotScrollArea {\n      overflow: auto;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter > div:first-of-type::-webkit-scrollbar,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter > div:first-of-type::-webkit-scrollbar {\n      width: .25em;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter > div:first-of-type::-webkit-scrollbar-track,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter > div:first-of-type::-webkit-scrollbar-track {\n        background: #000018;\n        border-radius: .313em;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter > div:first-of-type::-webkit-scrollbar-thumb,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter > div:first-of-type::-webkit-scrollbar-thumb {\n        background: #000019;\n        border-radius: .313em;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter > div:first-of-type:focus::-webkit-scrollbar-thumb,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter > div:first-of-type:focus::-webkit-scrollbar-thumb {\n        background: #000006;\n    }\n\n    @-moz-document url-prefix() {\n        #CybotCookiebotDialog .CybotCookiebotScrollContainer > div:first-of-type,\n        #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter > div:first-of-type,\n        #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter > div:first-of-type {\n            scrollbar-width: thin;\n            scrollbar-color: #000019 #000018;\n            scrollbar-track-color: #000018;\n            scrollbar-face-color: #000019;\n        }\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter > div:first-of-type:focus,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter > div:first-of-type:focus {\n      scrollbar-color: #000006 #000018;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl {\n      width: calc(100vw - 10px);\n      max-height: calc(100vh - 10px);\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogHeader {\n      padding: .5em 1em;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogNav .CybotCookiebotDialogNavItemLink,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter .CybotCookiebotScrollArea,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogDetailBodyContentIABv2TabsIntro,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogDetailBodyContentTextAbout {\n      padding: .5em;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogBodyContent {\n      padding: .8em;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl .CookieCard:first-of-type {\n      padding-top: .5em;\n    }\n\n    #CybotCookiebotDialog .CybotCookiebotFader:not(.CybotCookiebotFaderRight):not(.CybotCookiebotFaderLeft) {\n      max-height: 50%;\n    }\n\n    #CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyButton:not(:first-of-type) {\n      margin-top: 0.5em;\n    }\n\n    #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton,\n    #CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyButton:not(:last-of-type) {\n      margin-bottom: 0;\n    }\n\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter,\n    #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter {\n      overflow: auto;\n    }\n\n    #CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtonsWrapper {\n      flex-direction: column;\n    }\n\n    #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:last-of-type {\n        margin-bottom: 0;\n    }\n\n    #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggle {\n      flex-direction: row;\n    }\n\n    #CybotCookiebotDialogPoweredbyCybot svg {\n      display: block;\n      height: 1.7em;\n      opacity: 1;\n      max-width: 133px;\n    }\n\n    #CybotCookiebotDialogPoweredByText {\n      display: none;\n    }\n\n    #CybotCookiebotDialog .CybotCookiebotBannerCloseButton {\n      margin-left: 2.313rem;\n    }\n\n    #CybotCookiebotDialog[dir="rtl"] .CybotCookiebotBannerCloseButton {\n      margin-left: auto;\n      margin-right: 2.313rem;\n    }\n\n    #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper {\n      position: relative;\n      margin-top: 3.125em;\n    }\n\n    #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper.CybotCookiebotDialogShow {\n      display: block;\n    }\n\n    #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper:before {\n      content: \'\';\n      position: absolute;\n      top: -1.5em;\n      left: 0;\n      width: 100%;\n      border-top: 1px solid #000004;\n    }\n\n    #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProviderDescription {\n      margin-bottom: 1.56em;\n    }\n\n    #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfo:before {\n      display: none;\n    }\n\n    @media screen and (min-width: 601px) {\n      #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton,\n      #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:not(:first-of-type),\n      #CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyButton:not(:last-of-type),\n        #CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyButton:not(:first-of-type) {\n          margin-bottom: 0;\n          margin-top: 0;\n          width: 33%;\n      }\n\n      #CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtonsWrapper {\n        flex-direction: row;\n      }\n\n      #CybotCookiebotDialogPoweredbyCybot svg {\n          height: 2em;\n      }\n\n      #CybotCookiebotDialog .CybotCookiebotDialogBodyButton:focus-visible,\n      #CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectVendorsLink:focus-visible,\n      #CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectVendorsLink:focus-visible,\n      #CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABHeaderButton:focus-visible,\n      #CybotCookiebotDialog .CybotCookiebotBannerCloseButton:focus-visible,\n      #CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper input:focus-visible + span {\n          outline-offset: 2px;\n      }\n    }\n\n    @media screen and (min-width: 1280px) {\n      #CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter > div:first-of-type::-webkit-scrollbar,\n      #CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter > div:first-of-type::-webkit-scrollbar {\n        width: .5em;\n      }\n\n      #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow,\n      #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide {\n          top: 1.2em;\n      }\n\n      #CybotCookiebotDialogFooter {\n        padding: 0;\n      }\n\n      #CybotCookiebotDialogFooter .CybotCookiebotScrollArea {\n        padding: 1em 1.5em 1.5em;\n      }\n\n      #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter {\n          display: block;\n      }\n\n      #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:not(:first-of-type) {\n        margin-top: 0.5em;\n      }\n\n      #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton,\n      #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:not(:last-of-type) {\n        margin-bottom: 0;\n      }\n\n      #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton {\n        width: 286px;\n        max-width: none;\n      }\n\n      #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotScrollArea {\n        padding: 0;\n      }\n\n      #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotScrollbarContainer {\n        display: none;\n      }\n\n      #CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtonsWrapper {\n        flex-direction: column;\n      }\n\n      #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper {\n        margin-top: 3.75em;\n      }\n\n      #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProviderDescription {\n        margin-bottom: 1.875em;\n      }\n\n      #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper:before {\n        top: -2em;\n      }\n  \n    }\n  '
        },
        __assign = function() {
            return __assign = Object.assign || function __assign(t) {
                for (var s, i = 1, n = arguments.length; i < n; i++)
                    for (var p in s = arguments[i], s) Object.prototype.hasOwnProperty.call(s, p) && (t[p] = s[p]);
                return t
            }, __assign.apply(this, arguments)
        },
        hideElement = function(element) {
            void 0 !== element && null != element && (element.style.display = "none")
        },
        getTruncatedString = function(value, length) {
            return value.length > length ? value.substring(0, length - 3) + "..." : value
        };

    function getPurposeCountsFromConsent(dialog, allowedLists) {
        var IABGVL = dialog.IABGVL,
            allowedPurposes = allowedLists.purposes,
            allowedVendors = allowedLists.vendors,
            purposeCounts = {};
        return allowedPurposes.forEach((function(purposeId) {
            var _a;
            purposeCounts = __assign(__assign({}, purposeCounts), (_a = {}, _a[purposeId] = 0, _a))
        })), allowedVendors.forEach((function(vendorId) {
            var iABGVLVendor = IABGVL.vendors[vendorId],
                allowedVendorPurposes = restrictedList(iABGVLVendor.purposes, allowedPurposes),
                allowedLegIntPurposes = restrictedList(iABGVLVendor.legIntPurposes, allowedPurposes),
                selectedPurposes = allowedVendorPurposes.concat(allowedLegIntPurposes);
            selectedPurposes.forEach((function(purposeId) {
                purposeCounts[purposeId]++
            }))
        })), purposeCounts
    }

    function getInlineConfiguration(cookieConsent) {
        return cookieConsent.inlineConfiguration && cookieConsent.inlineConfiguration.Frameworks && cookieConsent.inlineConfiguration.Frameworks.IABTCF2
    }

    function getContentNameWithCount(dialog, sectionName, count) {
        return dialog.version === DialogVersion.ElementalCustom ? sectionName : sectionName + "<span class='CybotCookiebotDialogDetailBulkConsentCount'>" + count + "</span>"
    }

    function restrictedList(netList, grossList) {
        var result = [];
        if (netList.length < 0 || grossList.length < 0) return [];
        for (var t = 0; t < netList.length; t++) grossList.indexOf(netList[t]) >= 0 && result.push(netList[t]);
        return result
    }

    function getAllowedLists(inlineConfig, dialog, iabCmp) {
        var IABGVL = dialog.IABGVL,
            allowedPurposes = [],
            allowedSpecialPurposes = [],
            allowedFeatures = [],
            allowedSpecialFeatures = [],
            allowedGooglePartners = dialog.googlePartnersSortedIds,
            allowedVendors = [];
        if (inlineConfig && inlineConfig.AllowedPurposes) allowedPurposes = inlineConfig.AllowedPurposes.filter((function(id) {
            return IABGVL.purposes[id]
        }));
        else
            for (var iabAllowedPurposeIndex in IABGVL.purposes) allowedPurposes.push(IABGVL.purposes[iabAllowedPurposeIndex].id);
        if (inlineConfig && inlineConfig.AllowedSpecialPurposes) allowedSpecialPurposes = inlineConfig.AllowedSpecialPurposes.filter((function(id) {
            return IABGVL.specialPurposes[id]
        }));
        else
            for (var iabAllowedSpecialPurposeIndex in IABGVL.specialPurposes) allowedSpecialPurposes.push(IABGVL.specialPurposes[iabAllowedSpecialPurposeIndex].id);
        if (inlineConfig && inlineConfig.AllowedFeatures) allowedFeatures = inlineConfig.AllowedFeatures.filter((function(id) {
            return IABGVL.features[id]
        }));
        else
            for (var iabAllowedFeatureIndex in IABGVL.features) allowedFeatures.push(IABGVL.features[iabAllowedFeatureIndex].id);
        if (inlineConfig && inlineConfig.AllowedSpecialFeatures) allowedSpecialFeatures = inlineConfig.AllowedSpecialFeatures.filter((function(id) {
            return IABGVL.specialFeatures[id]
        }));
        else
            for (var iabAllowedSpecialFeatureIndex in IABGVL.specialFeatures) allowedSpecialFeatures.push(IABGVL.specialFeatures[iabAllowedSpecialFeatureIndex].id);
        if (inlineConfig && inlineConfig.AllowedVendors && inlineConfig.AllowedVendors.length > 0) {
            for (var i = 0; i < dialog.IABSortedVendorList.length; i++)
                if (inlineConfig.AllowedVendors.indexOf(dialog.IABSortedVendorList[i]) >= 0) {
                    var allowedIABVendor = IABGVL.vendors[dialog.IABSortedVendorList[i]];
                    !allowedIABVendor.deletedDate && allowedVendors.push(allowedIABVendor.id)
                }
        } else
            for (var sortedVendorIndex = 0; sortedVendorIndex < dialog.IABSortedVendorList.length; sortedVendorIndex++) {
                var sortedVendorId = dialog.IABSortedVendorList[sortedVendorIndex],
                    sortedVendorObject = IABGVL.vendors[sortedVendorId];
                !sortedVendorObject.deletedDate && allowedVendors.push(sortedVendorId)
            }
        if (inlineConfig)
            for (var j = 0; j < allowedVendors.length; j++) {
                var allowedVendor = IABGVL.vendors[allowedVendors[j]];
                if (allowedVendor.specialPurposes && allowedVendor.specialPurposes.length > 0)
                    for (var k = 0; k < allowedVendor.specialPurposes.length; k++) allowedSpecialPurposes.indexOf(allowedVendor.specialPurposes[k]) < 0 && allowedSpecialPurposes.push(allowedVendor.specialPurposes[k]);
                if (allowedVendor.features && allowedVendor.features.length > 0)
                    for (var m = 0; m < allowedVendor.features.length; m++) allowedFeatures.indexOf(allowedVendor.features[m]) < 0 && allowedFeatures.push(allowedVendor.features[m])
            }
        if (inlineConfig && inlineConfig.AllowedGoogleACVendors) {
            if (allowedGooglePartners = [], inlineConfig.AllowedGoogleACVendors.length > 0)
                for (var n = 0; n < dialog.googlePartnersSortedIds.length; n++)
                    if (inlineConfig.AllowedGoogleACVendors.indexOf(dialog.googlePartnersSortedIds[n]) >= 0) {
                        var allowedGoogleACVendor = dialog.googlePartners[dialog.googlePartnersSortedIds[n]];
                        allowedGooglePartners.push(allowedGoogleACVendor.id)
                    }
        } else if ("object" == typeof iabCmp && iabCmp.GACMCommonList) {
            allowedGooglePartners = [];
            for (var o = 0; o < dialog.googlePartnersSortedIds.length; o++)
                if (iabCmp.GACMCommonList.indexOf(dialog.googlePartnersSortedIds[o]) >= 0) {
                    var allowedGooglePartner = dialog.googlePartners[dialog.googlePartnersSortedIds[o]];
                    allowedGooglePartners.push(allowedGooglePartner.id)
                }
        }
        return {
            purposes: allowedPurposes,
            specialPurposes: allowedSpecialPurposes,
            features: allowedFeatures,
            specialFeatures: allowedSpecialFeatures,
            vendors: allowedVendors,
            googlePartners: allowedGooglePartners
        }
    }

    function renderCardListHeader(dialog, sectionName, sectionCount, noBorder, buttonId) {
        var spacingStyle = noBorder ? " style='border-top:none'" : "",
            headerContent = "<div class='CybotCookiebotDialogBodyLevelButtonIABHeader'" + spacingStyle + ">";
        if (headerContent += getContentNameWithCount(dialog, sectionName, sectionCount), buttonId) {
            var iabHeaderButtonClass = "CybotCookiebotDialogBodyLevelButtonIABHeaderButton",
                iabHeaderButtonSelectId = "CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectAll" + buttonId + "Link",
                iabHeaderButtonDeselectId = "CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectAll" + buttonId + "Link",
                selectButton = "<a  class='" + iabHeaderButtonClass + " select' id='" + iabHeaderButtonSelectId + "' href='#'>" + dialog.IABResourceStrings.selectAll + "</a>",
                deselectButton = "<a class='" + iabHeaderButtonClass + " reject' id='" + iabHeaderButtonDeselectId + "' href='#'>" + dialog.IABResourceStrings.deselectAll + "</a> ";
            headerContent += "<span class='CybotCookiebotDialogBodyLevelButtonIABHeaderToggle'>", dialog.version === DialogVersion.Swift ? (headerContent += deselectButton, headerContent += selectButton) : (headerContent += selectButton, headerContent += " | ", headerContent += deselectButton), headerContent += "</span>"
        }
        return headerContent += "</div>", headerContent
    }

    function renderCardBulletPointList(dialog, header, bullets) {
        var htmlList = "<ul class='CybotCookiebotDialogBodyLevelButtonIABList' style='margin-top: 1em; padding: 0; font-weight: bold;'>";
        htmlList += header + ":";
        for (var margin = dialog.version === DialogVersion.Swift ? 2 : 18, i = 0; i < bullets.length; i++) htmlList += "ltr" === dialog.textDirection ? "<li style='margin-left: " + margin + "px; font-weight: normal;'>" : "<li style='margin-right: " + margin + "px; font-weight: normal;'>", htmlList += bullets[i] + "</li>";
        return htmlList += "</ul>", htmlList
    }

    function getIabIntroSection(dialog, count) {
        var legitimateInterestText = dialog.IABResourceStrings.legitimateInterestIntro.replace("<a>", "<a id='CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink' href='#'>"),
            intro = dialog.IABResourceStrings.mainIntro.replace("%VENDOR_COUNT%", count.toString());
        return {
            title: dialog.IABResourceStrings.tabTitle,
            text: intro,
            legitimateInterestText: legitimateInterestText,
            preferenceText: dialog.IABResourceStrings.preferencesIntro
        }
    }

    function getIabPurposesSection(dialog, count, vendorCounts, allowedLists) {
        var IABGVL = dialog.IABGVL,
            allowedPurposes = allowedLists.purposes,
            allowedSpecialPurposes = allowedLists.specialPurposes,
            purposeContent = "";
        dialog.version === DialogVersion.ElementalCustom && (purposeContent = "<div>", purposeContent += dialog.IABResourceStrings.mainIntro.replace("%VENDOR_COUNT%", count.toString()), purposeContent += "<br/><br/>", "custom" === dialog.template ? purposeContent += dialog.IABResourceStrings.legitimateInterestIntro.replace("<a>", "").replace("</a>", "") : purposeContent += dialog.IABResourceStrings.legitimateInterestIntro.replace("<a>", "<a id='CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink' href='#'>"), purposeContent += "<br/><br/>" + dialog.IABResourceStrings.preferencesIntro + "<br/><br/>", purposeContent += "</div>"), purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABWrapper'>", purposeContent += renderCardListHeader(dialog, dialog.IABResourceStrings.purpose, allowedPurposes.length, !1, "Purposes"), dialog.version === DialogVersion.ElementalCustom && (purposeContent += "<div class='CybotCookiebotDialogBodyIABIntroContainer'>" + dialog.IABResourceStrings.purposeIntro + "</div>");
        for (var p = 0; p < allowedPurposes.length; p++) {
            var currentPurpose = IABGVL.purposes[allowedPurposes[p]];
            purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainer'>", dialog.version === DialogVersion.Swift && (purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainerTogglesWrapper'>"), purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'>", purposeContent += "<input type='checkbox' id='CybotCookiebotDialogBodyLevelButtonIABPurpose" + currentPurpose.id + "' data-iabpurposeid='" + currentPurpose.id + "' ", purposeContent += "class='CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyIABButtonPurposes' checked='checked' tabindex='0'>", purposeContent += "<label class='CybotCookiebotDialogBodyLevelButtonIABLabel' for='CybotCookiebotDialogBodyLevelButtonIABPurpose" + currentPurpose.id + "'>", purposeContent += currentPurpose.name + "</label></div>";
            var doesHaveLegitimateInterests = 1 !== currentPurpose.id && 3 !== currentPurpose.id && 4 !== currentPurpose.id && 5 !== currentPurpose.id && 6 !== currentPurpose.id;
            doesHaveLegitimateInterests && (purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'>", purposeContent += "<input type='checkbox' id='CybotCookiebotDialogBodyLevelButtonIABPurposeLegitimateInterest" + currentPurpose.id + "' ", purposeContent += "data-iabpurposeid='" + currentPurpose.id + "' ", purposeContent += "class='CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyIABButtonPurposesLegitimateInterestSelection' ", purposeContent += "checked='checked' tabindex='0'>", purposeContent += "<label for='CybotCookiebotDialogBodyLevelButtonIABPurposeLegitimateInterest" + currentPurpose.id + "'>", purposeContent += dialog.IABResourceStrings.legitimateInterestHeader + "</label></div>"), dialog.version === DialogVersion.Swift && (purposeContent += "</div>"), purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>", purposeContent += currentPurpose.description;
            var illustrations = currentPurpose.illustrations;
            illustrations && illustrations.length > 0 && (purposeContent += renderCardBulletPointList(dialog, dialog.IABResourceStrings.illustrationsHeader, illustrations)), purposeContent += '<p class="CybotCookiebotDialogBodyLevelButtonIABPurposeCount" style="margin-top: 2em">' + dialog.IABResourceStrings.vendors + ' <span id="CybotCookiebotDialogBodyLevelButtonIABPurpose' + currentPurpose.id + 'Count" class="CybotCookiebotDialogDetailBulkConsentCount" style="margin-left: 0.4em">' + vendorCounts[currentPurpose.id] + "</span></p>", purposeContent += "</div></div>"
        }
        if (purposeContent += "</div>", allowedSpecialPurposes.length > 0) {
            purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABWrapper'>", purposeContent += renderCardListHeader(dialog, dialog.IABResourceStrings.specialPurpose, allowedSpecialPurposes.length, !0, null);
            for (var q = 0; q < allowedSpecialPurposes.length; q++) {
                var currentSpecialPurpose = IABGVL.specialPurposes[allowedSpecialPurposes[q]];
                purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainer'>", purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'>", purposeContent += "<label class='CybotCookiebotDialogBodyLevelButtonIABLabel'>" + currentSpecialPurpose.name + "</label></div>", purposeContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>", purposeContent += currentSpecialPurpose.description;
                var illustrations = currentSpecialPurpose.illustrations;
                illustrations && illustrations.length > 0 && (purposeContent += renderCardBulletPointList(dialog, dialog.IABResourceStrings.illustrationsHeader, illustrations)), purposeContent += "</div></div>"
            }
            purposeContent += "</div>"
        }
        var purposeIntro = dialog.version === DialogVersion.ElementalCustom ? dialog.IABResourceStrings.generalIntro : dialog.IABResourceStrings.purposeIntro + " " + dialog.IABResourceStrings.legitimateInterestObjection,
            purposeCount = allowedPurposes.length + allowedSpecialPurposes.length;
        return {
            title: getContentNameWithCount(dialog, dialog.IABResourceStrings.purpose, purposeCount),
            text: purposeIntro,
            content: purposeContent,
            sectionAriaLabel: dialog.IABResourceStrings.purpose + " (" + purposeCount + ")"
        }
    }

    function getIabFeaturesSection(dialog, allowedLists) {
        var IABGVL = dialog.IABGVL,
            allowedFeatures = allowedLists.features,
            allowedSpecialFeatures = allowedLists.specialFeatures,
            featureContent = "";
        if (allowedFeatures.length > 0) {
            featureContent = "<div class='CybotCookiebotDialogBodyLevelButtonIABWrapper'>", featureContent += renderCardListHeader(dialog, dialog.IABResourceStrings.feature, allowedFeatures.length, !1, null);
            for (var r = 0; r < allowedFeatures.length; r++) {
                var currentFeature = IABGVL.features[allowedFeatures[r]];
                featureContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainer'>", featureContent += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'>", featureContent += "<label class='CybotCookiebotDialogBodyLevelButtonIABLabel'>" + currentFeature.name + "</label></div>", featureContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>", featureContent += currentFeature.description;
                var illustrations = currentFeature.illustrations;
                illustrations && illustrations.length > 0 && (featureContent += renderCardBulletPointList(dialog, dialog.IABResourceStrings.illustrationsHeader, illustrations)), featureContent += "</div></div>"
            }
            featureContent += "</div>"
        }
        if (allowedSpecialFeatures.length > 0) {
            featureContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABWrapper'>", featureContent += renderCardListHeader(dialog, dialog.IABResourceStrings.specialFeature, allowedSpecialFeatures.length, !0, "Features");
            for (var s = 0; s < allowedSpecialFeatures.length; s++) {
                var currentSpecialFeature = IABGVL.specialFeatures[allowedSpecialFeatures[s]];
                featureContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainer'>", dialog.version === DialogVersion.Swift && (featureContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainerTogglesWrapper'>"), featureContent += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'>", featureContent += "<input type='checkbox' id='CybotCookiebotDialogBodyLevelButtonIABFeature" + currentSpecialFeature.id + "' ", featureContent += "data-iabspecialfeatureid='" + currentSpecialFeature.id + "' ", featureContent += "class='CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyIABButtonFeatures' ", featureContent += "checked='checked' tabindex='0'><label class='CybotCookiebotDialogBodyLevelButtonIABLabel' ", featureContent += "for='CybotCookiebotDialogBodyLevelButtonIABFeature" + currentSpecialFeature.id + "'>" + currentSpecialFeature.name + "</label></div>", dialog.version === DialogVersion.Swift && (featureContent += "</div>"), featureContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>", featureContent += currentSpecialFeature.description;
                var illustrations = currentSpecialFeature.illustrations;
                illustrations && illustrations.length > 0 && (featureContent += renderCardBulletPointList(dialog, dialog.IABResourceStrings.illustrationsHeader, illustrations)), featureContent += "</div></div>"
            }
            featureContent += "</div>"
        }
        var featureCount = allowedFeatures.length + allowedSpecialFeatures.length;
        return {
            title: getContentNameWithCount(dialog, dialog.IABResourceStrings.feature, featureCount),
            text: dialog.IABResourceStrings.featureIntro,
            content: featureContent,
            sectionAriaLabel: dialog.IABResourceStrings.feature + " (" + featureCount + ")"
        }
    }

    function getIabVendorsSection(cookieConsent, dialog, allowedLists) {
        var IABGVL = dialog.IABGVL,
            allowedFeatures = allowedLists.features,
            allowedSpecialFeatures = allowedLists.specialFeatures,
            allowedPurposes = allowedLists.purposes,
            allowedSpecialPurposes = allowedLists.specialPurposes,
            allowedVendors = allowedLists.vendors,
            allowedGooglePartners = allowedLists.googlePartners,
            externalLinkIcon = dialog.version === DialogVersion.Swift ? "<img class='CybotExternalLinkArrow' src=" + dialog.externalLinkIcon + ' alt="" />' : "",
            vendorIntro = dialog.version === DialogVersion.Swift ? dialog.IABResourceStrings.partnersIntro + " " + dialog.IABResourceStrings.legitimateInterestVendorObjection : "",
            selectButton = "<a class='CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectVendorsLink' href='#'>" + dialog.IABResourceStrings.selectAll + "</a>",
            deselectButton = "<a class='CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectVendorsLink' href='#'>" + dialog.IABResourceStrings.deselectAll + "</a>",
            vendorContent = dialog.version === DialogVersion.ElementalCustom ? dialog.IABResourceStrings.partnersIntro + " " + dialog.IABResourceStrings.legitimateInterestVendorObjection : "";
        vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABWrapper'>", vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABHeader' style='border-top:none;'>", vendorContent += getContentNameWithCount(dialog, dialog.IABResourceStrings.thirdPartyVendors, allowedVendors.length), vendorContent += '<span class="CybotCookiebotDialogBodyLevelButtonIABHeaderToggle">', dialog.version === DialogVersion.Swift ? (vendorContent += deselectButton, vendorContent += selectButton) : (vendorContent += selectButton, vendorContent += " | ", vendorContent += deselectButton), vendorContent += "</span></div>";
        for (var u = 0; u < allowedVendors.length; u++) {
            var iABGVLVendor = IABGVL.vendors[allowedVendors[u]],
                allowedVendorPurposes = restrictedList(iABGVLVendor.purposes, allowedPurposes),
                allowedVendorlegIntPurposes = restrictedList(iABGVLVendor.legIntPurposes, allowedPurposes),
                allowedVendorspecialPurposes = restrictedList(iABGVLVendor.specialPurposes, allowedSpecialPurposes),
                allowedVendorFeatures = restrictedList(iABGVLVendor.features, allowedFeatures),
                allowedVendorSpecialFeatures = restrictedList(iABGVLVendor.specialFeatures, allowedSpecialFeatures),
                ariaExpanded = dialog.version === DialogVersion.Swift ? "aria-expanded='false'" : "";
            if (vendorContent += "<div ", vendorContent += "class='CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed'", vendorContent += "id='CybotCookiebotDialogBodyLevelButtonIABVendorContainer" + iABGVLVendor.id + "'", vendorContent += ariaExpanded, vendorContent += ">", dialog.version === DialogVersion.ElementalCustom && (vendorContent += "<a data-iabvendorid='" + iABGVLVendor.id + "' title='" + dialog.IABResourceStrings.expand + "' ", vendorContent += "class='CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow' href='#'></a>"), dialog.version === DialogVersion.Swift && (vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainerTogglesWrapper'>"), vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'>", iABGVLVendor.purposes.length > 0 ? (vendorContent += "<input type='checkbox' id='CybotCookiebotDialogBodyLevelButtonIABVendor" + iABGVLVendor.id, vendorContent += "' data-iabvendorid='" + iABGVLVendor.id + "' class='CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyIABButtonVendors' ", vendorContent += "checked='checked' tabindex='0'><label class='CybotCookiebotDialogBodyLevelButtonIABLabel' ", vendorContent += "for='CybotCookiebotDialogBodyLevelButtonIABVendor" + iABGVLVendor.id + "'>" + iABGVLVendor.name + "</label>") : vendorContent += "<p class='CybotCookiebotDialogBodyLevelButtonIABLabel' style='padding-left: 2em;'>" + iABGVLVendor.name + "</p>", vendorContent += "</div>", iABGVLVendor.legIntPurposes.length > 0) {
                for (var legIntAllowed = !1, v = 0; v < iABGVLVendor.legIntPurposes.length; v++)
                    if (allowedVendorlegIntPurposes.indexOf(iABGVLVendor.legIntPurposes[v]) >= 0) {
                        legIntAllowed = !0;
                        break
                    }
                legIntAllowed && (vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'><input type='checkbox'", vendorContent += " id='CybotCookiebotDialogBodyLevelButtonIABVendorLegitimateInterest" + iABGVLVendor.id + "' data-iabvendorid='" + iABGVLVendor.id + "'", vendorContent += " class='CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyIABButtonVendorsLegitimateInterestSelection' checked='checked'", vendorContent += " tabindex='0'><label for='CybotCookiebotDialogBodyLevelButtonIABVendorLegitimateInterest" + iABGVLVendor.id + "'>", vendorContent += dialog.IABResourceStrings.legitimateInterestHeader + "</label></div>")
            }
            dialog.version === DialogVersion.Swift && (vendorContent += "</div>", vendorContent += "<a data-iabvendorid='" + iABGVLVendor.id + "' title='" + dialog.IABResourceStrings.expand + "' ", vendorContent += "class='CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow' href='#'></a>"), vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>";
            var iABGVLVendorUrls = iABGVLVendor.urls,
                urls = iABGVLVendorUrls.find((function(urls) {
                    return urls.langId.toLowerCase() === cookieConsent.userCulture.toLowerCase()
                }));
            urls = urls || iABGVLVendorUrls.find((function(urls) {
                return urls.langId.toLocaleLowerCase() === cookieConsent.userCulture.toLowerCase().substring(0, urls.langId.length)
            })), urls = urls || iABGVLVendorUrls.find((function(urls) {
                return "en" === urls.langId.toLowerCase()
            })), urls = urls || iABGVLVendorUrls[0];
            var policyURL = urls.privacy,
                legIntClaimURL = urls.legIntClaim;
            if (vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABLinkWrapper' style='font-weight: bold;'>", vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABLinkHeader'>" + dialog.IABResourceStrings.policyURL + ":</div>", vendorContent += " <a href='" + policyURL + "' target='_blank' aria-label='" + dialog.IABResourceStrings.policyURL + " - " + dialog.opensInNewWindowText + "'", vendorContent += " rel='noopener noreferrer nofollow' style='margin-top: 0; word-break: break-word;'>", vendorContent += policyURL + externalLinkIcon + "</a>", vendorContent += "</div>", legIntClaimURL && (vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABLinkWrapper' style='font-weight: bold; margin-top: 1em;'>", vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABLinkHeader'>" + dialog.IABResourceStrings.legitimateInterestHeader + ":</div>", vendorContent += " <a href='" + legIntClaimURL + "' target='_blank' aria-label='" + dialog.IABResourceStrings.legitimateInterestHeader + " - " + dialog.opensInNewWindowText + "'", vendorContent += " rel='noopener noreferrer nofollow' style='margin-top: 0; word-break: break-word;'>", vendorContent += legIntClaimURL + externalLinkIcon + "</a>", vendorContent += "</div>"), allowedVendorPurposes.length > 0) {
                for (var vendorPurposesList = [], w = 0; w < allowedVendorPurposes.length; w++) {
                    var allowedPurpose = allowedVendorPurposes[w],
                        dataRetention = iABGVLVendor.dataRetention,
                        retentionPeriod = dataRetention.purposes[allowedPurpose];
                    if (retentionPeriod && retentionPeriod !== dataRetention.stdRetention) {
                        var retentionString = " (" + dialog.IABResourceStrings.dataRetentionPeriod + ": " + retentionPeriod + " " + dialog.IABResourceStrings.days + ")";
                        vendorPurposesList.push(dialog.getIAB2PurposeById(allowedPurpose) + retentionString)
                    } else vendorPurposesList.push(dialog.getIAB2PurposeById(allowedPurpose))
                }
                var vendorPurposesHeader = dialog.IABResourceStrings.purpose + " (" + dialog.IABResourceStrings.consent + ")";
                vendorContent += renderCardBulletPointList(dialog, vendorPurposesHeader, vendorPurposesList)
            }
            if (allowedVendorlegIntPurposes.length > 0) {
                for (var vendorLegitimatePurposesList = [], w = 0; w < allowedVendorlegIntPurposes.length; w++) {
                    var vendorPurposeString = dialog.getIAB2PurposeById(allowedVendorlegIntPurposes[w]);
                    vendorLegitimatePurposesList.push(vendorPurposeString)
                }
                var vendorLegitimatePurposesHeader = dialog.IABResourceStrings.purpose + " (" + dialog.IABResourceStrings.legitimateInterestHeader + ")";
                vendorContent += renderCardBulletPointList(dialog, vendorLegitimatePurposesHeader, vendorLegitimatePurposesList)
            }
            if (allowedVendorspecialPurposes.length > 0) {
                for (var vendorSpecialPurposesList = [], w = 0; w < allowedVendorspecialPurposes.length; w++) {
                    var allowedSpecialPurpose = allowedVendorspecialPurposes[w],
                        dataRetention = iABGVLVendor.dataRetention,
                        retentionPeriod = dataRetention.purposes[allowedSpecialPurpose];
                    if (retentionPeriod && retentionPeriod !== dataRetention.stdRetention) {
                        var retentionString = " (" + dialog.IABResourceStrings.dataRetentionPeriod + ": " + retentionPeriod + " " + dialog.IABResourceStrings.days + ")";
                        vendorSpecialPurposesList.push(dialog.getIAB2SpecialPurposeById(allowedSpecialPurpose) + retentionString)
                    } else vendorSpecialPurposesList.push(dialog.getIAB2SpecialPurposeById(allowedSpecialPurpose))
                }
                var vendorSpecialPurposesHeader = dialog.IABResourceStrings.specialPurpose;
                vendorContent += renderCardBulletPointList(dialog, vendorSpecialPurposesHeader, vendorSpecialPurposesList)
            }
            if (allowedVendorFeatures.length > 0) {
                for (var vendorFeaturesList = [], w = 0; w < allowedVendorFeatures.length; w++) {
                    var vendorFeatureString = dialog.getIAB2FeatureById(allowedVendorFeatures[w]);
                    vendorFeaturesList.push(vendorFeatureString)
                }
                var vendorFeaturesHeader = dialog.IABResourceStrings.feature;
                vendorContent += renderCardBulletPointList(dialog, vendorFeaturesHeader, vendorFeaturesList)
            }
            if (allowedVendorSpecialFeatures.length > 0) {
                for (var vendorSpecialFeaturesList = [], w = 0; w < allowedVendorSpecialFeatures.length; w++) {
                    var vendorSpecialFeatureString = dialog.getIAB2SpecialFeatureById(allowedVendorSpecialFeatures[w]);
                    vendorSpecialFeaturesList.push(vendorSpecialFeatureString)
                }
                var vendorSpecialFeaturesHeader = dialog.IABResourceStrings.specialFeature;
                vendorContent += renderCardBulletPointList(dialog, vendorSpecialFeaturesHeader, vendorSpecialFeaturesList)
            }
            if (iABGVLVendor.dataDeclaration && iABGVLVendor.dataDeclaration.length > 0) {
                for (var dataCategories = IABGVL.dataCategories, vendorDataCategoriesList = [], w = 0; w < iABGVLVendor.dataDeclaration.length; w++) {
                    var dataCategoryIndex = iABGVLVendor.dataDeclaration[w];
                    dataCategories[dataCategoryIndex] && vendorDataCategoriesList.push(dataCategories[dataCategoryIndex].name)
                }
                var vendorDataCategoriesHeader = dialog.IABResourceStrings.dataCategoriesHeader;
                vendorContent += renderCardBulletPointList(dialog, vendorDataCategoriesHeader, vendorDataCategoriesList)
            }
            if (iABGVLVendor.dataRetention.stdRetention) {
                var retentionPeriod = iABGVLVendor.dataRetention.stdRetention + " " + dialog.IABResourceStrings.days;
                vendorContent += renderCardBulletPointList(dialog, dialog.IABResourceStrings.dataRetentionPeriod, [retentionPeriod])
            }
            var hasMaxAgeSeconds = void 0 !== iABGVLVendor.cookieMaxAgeSeconds && null !== iABGVLVendor.cookieMaxAgeSeconds && -100 !== iABGVLVendor.cookieMaxAgeSeconds,
                hasCookiesAccessData = void 0 !== iABGVLVendor.usesNonCookieAccess && null !== iABGVLVendor.usesNonCookieAccess;
            if (hasMaxAgeSeconds || hasCookiesAccessData || iABGVLVendor.deviceStorageDisclosureUrl) {
                var vendorConsentDataList = [];
                if (hasMaxAgeSeconds) {
                    var cookieExpiry = dialog.CalculateHumanDuration(iABGVLVendor.cookieMaxAgeSeconds, dialog.IABResourceStrings);
                    vendorConsentDataList.push(dialog.IABResourceStrings.consentExpiry + ": " + cookieExpiry)
                }
                if (iABGVLVendor.cookieRefresh && vendorConsentDataList.push(dialog.IABResourceStrings.expiryRefreshText), hasCookiesAccessData) {
                    var trackingMethod = iABGVLVendor.usesNonCookieAccess ? dialog.IABResourceStrings.cookiesAndOther : dialog.IABResourceStrings.cookiesOnly;
                    vendorConsentDataList.push(dialog.IABResourceStrings.trackingType + ": " + trackingMethod)
                }
                if (iABGVLVendor.deviceStorageDisclosureUrl) {
                    var storageDisclosureLink = "<a class='CybotCookiebotDialogBodyLevelButtonIABShowDetails' data-iabvendorid='" + iABGVLVendor.id + "'";
                    storageDisclosureLink += " href='#'>" + dialog.IABResourceStrings.showDetails + "</a>", vendorConsentDataList.push(storageDisclosureLink)
                }
                var vendorConsentDataHeader = dialog.IABResourceStrings.consentHandlingHeader;
                vendorContent += renderCardBulletPointList(dialog, vendorConsentDataHeader, vendorConsentDataList), iABGVLVendor.deviceStorageDisclosureUrl && (vendorContent += "<div class='CybotCookiebotDialogBodyIABDetails'></div>")
            }
            vendorContent += "</div></div>"
        }
        if (vendorContent += "</div>", allowedGooglePartners.length > 0) {
            vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABWrapper'>", vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABHeader' style='border-top:none;'>", vendorContent += getContentNameWithCount(dialog, dialog.IABResourceStrings.googleHeader, allowedGooglePartners.length) + "</div>", vendorContent += "<div class='CybotCookiebotDialogBodyIABIntroContainer'>" + dialog.IABResourceStrings.googleIntro + "</div>";
            for (var b = 0; b < allowedGooglePartners.length; b++) {
                var currentGooglePartner = dialog.googlePartners[allowedGooglePartners[b]];
                vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed CybotCookiebotDialogBodyGACMVendor' ", vendorContent += "id='CybotCookiebotDialogBodyLevelButtonGoogleVendorContainer" + currentGooglePartner.id + "'>", dialog.version === DialogVersion.ElementalCustom && (vendorContent += "<a data-googlevendorid='" + currentGooglePartner.id + "' title='" + dialog.IABResourceStrings.expand + "' ", vendorContent += "class='CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow' href='#')'></a>"), vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'>", vendorContent += "<input type='checkbox' id='CybotCookiebotDialogBodyLevelButtonGoogleVendor" + currentGooglePartner.id + "' ", vendorContent += "data-googlevendorid='" + currentGooglePartner.id + "' class='CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyIABButtonVendors' ", vendorContent += "checked='checked' tabindex='0'><label class='CybotCookiebotDialogBodyLevelButtonIABLabel' ", vendorContent += "for='CybotCookiebotDialogBodyLevelButtonGoogleVendor" + currentGooglePartner.id + "'>" + currentGooglePartner.name + "</label></div>", dialog.version === DialogVersion.Swift && (vendorContent += "<a data-googlevendorid='" + currentGooglePartner.id + "' title='" + dialog.IABResourceStrings.expand + "' ", vendorContent += "class='CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow' href='#')'></a>"), vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>", vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABLinkWrapper' style='font-weight: bold;'>", vendorContent += "<div class='CybotCookiebotDialogBodyLevelButtonIABLinkHeader'>" + dialog.IABResourceStrings.policyURL + ":</div>", vendorContent += " <a href='" + currentGooglePartner.policyUrl + "' target='_blank' aria-label='" + dialog.IABResourceStrings.policyURL + " - " + dialog.opensInNewWindowText + "'", vendorContent += " rel='noopener noreferrer nofollow' style='margin-top: 0; word-break: break-word;'>", vendorContent += currentGooglePartner.policyUrl + externalLinkIcon + "</a>", vendorContent += "</div>";
                for (var GACMAllowedVendorPurposes = [1, 2], googlePartnerPurposesList = [], w = 0; w < GACMAllowedVendorPurposes.length; w++) {
                    var googlePartnerPurposesString = dialog.getIAB2PurposeById(GACMAllowedVendorPurposes[w]);
                    googlePartnerPurposesList.push(googlePartnerPurposesString)
                }
                var googlePartnerPurposesHeader = dialog.IABResourceStrings.purpose;
                vendorContent += renderCardBulletPointList(dialog, googlePartnerPurposesHeader, googlePartnerPurposesList), vendorContent += "</div></div>"
            }
            vendorContent += "</div>"
        }
        var vendorCount = allowedVendors && allowedVendors.length || 0,
            googlePartnerCount = allowedGooglePartners && allowedGooglePartners.length || 0,
            partnerCount = vendorCount + googlePartnerCount;
        return {
            title: getContentNameWithCount(dialog, dialog.IABResourceStrings.partners, partnerCount),
            text: vendorIntro,
            content: vendorContent,
            count: partnerCount,
            sectionAriaLabel: dialog.IABResourceStrings.partners + " (" + partnerCount + ")"
        }
    }

    function getIABData(cookieConsent, iabCmp, dialog) {
        var inlineConfig = getInlineConfiguration(cookieConsent),
            allowedLists = getAllowedLists(inlineConfig, dialog, iabCmp),
            allowedPurposes = allowedLists.purposes,
            allowedSpecialPurposes = allowedLists.specialPurposes,
            allowedFeatures = allowedLists.features,
            allowedSpecialFeatures = allowedLists.specialFeatures;
        setTimeout((function() {
            if (0 === allowedPurposes.length) {
                var iabPurposesContainer = document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2TabPurposes");
                void 0 !== iabPurposesContainer && null != iabPurposesContainer && (hideElement(iabPurposesContainer.getElementsByClassName("CybotCookiebotDialogBodyLevelButtonIABHeader")[0]), hideElement(iabPurposesContainer.getElementsByClassName("CybotCookiebotDialogBodyIABIntroContainer")[0]), hideElement(iabPurposesContainer.getElementsByClassName("CybotCookiebotDialogBodyLevelButtonIABHeaderToggle")[0])), 0 === allowedSpecialPurposes.length && hideElement(document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2Purposes"))
            }
            0 === allowedSpecialFeatures.length && (hideElement(document.getElementById("CybotCookiebotDialogSpecialFeaturesText")), 0 === allowedFeatures.length && hideElement(document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2Features"))), 0 === allowedPurposes.length && 0 === allowedSpecialPurposes.length && 0 === allowedFeatures.length && 0 === allowedSpecialFeatures.length ? dialog.showCookieContainerIABv2DetailPane("partners") : 0 === allowedPurposes.length && 0 === allowedSpecialPurposes.length && dialog.showCookieContainerIABv2DetailPane("features")
        }), 1);
        var vendorSection = getIabVendorsSection(cookieConsent, dialog, allowedLists),
            vendorCounts = getPurposeCountsFromConsent(dialog, allowedLists);
        return {
            tabHeader: dialog.IABResourceStrings.tabHeader,
            sectionIntro: getIabIntroSection(dialog, vendorSection.count),
            sectionPurposes: getIabPurposesSection(dialog, vendorSection.count, vendorCounts, allowedLists),
            sectionFeatures: getIabFeaturesSection(dialog, allowedLists),
            sectionVendors: vendorSection
        }
    }

    function onNewTab(document, dialog) {
        for (var scrollAreas = document.querySelectorAll(".CybotCookiebotScrollArea, .CybotCookiebotScrollAreaSide"), i = 0; i < scrollAreas.length; i++) {
            var el = scrollAreas[i],
                eventElement = el.classList.contains("CybotCookiebotScrollAreaSide") ? el.querySelector("ul") : el;
            null !== eventElement.offsetParent && calcFadeState(eventElement, !0, dialog)
        }
    }

    function onHeightTriggerClick(e, document, dialog) {
        e.preventDefault();
        var el = document.querySelector(".CybotCookiebotScrollContainer.CybotCookiebotDialogActive .CybotCookiebotScrollArea");
        calcFadeState(el, !0, dialog)
    }

    function setFaderState(fader, isActive) {
        var scrollArea = fader && fader.parentElement;
        isActive && fader && !fader.classList.contains("CybotCookiebotDialogActive") ? (fader.classList.add("CybotCookiebotDialogActive"), !scrollArea || "CybotCookiebotDialogBodyContent" !== scrollArea.id && "CybotCookiebotDialogDetailBodyContentTextAbout" !== scrollArea.id || scrollArea.removeAttribute("tabindex")) : !isActive && fader && fader.classList.contains("CybotCookiebotDialogActive") && fader.classList.remove("CybotCookiebotDialogActive")
    }

    function calcFadeState(element, isFadeDisabled, dialog) {
        var parentNode = element.parentNode,
            isSideDirection = parentNode.classList.contains("CybotCookiebotScrollAreaSide"),
            fader = element.querySelector(".CybotCookiebotFader"),
            faderLeft = parentNode.querySelector(".CybotCookiebotFaderLeft"),
            faderRight = parentNode.querySelector(".CybotCookiebotFaderRight");
        if (isFadeDisabled && (dialog.setVisibility(fader, "hide"), dialog.setVisibility(faderLeft, "hide"), dialog.setVisibility(faderRight, "hide")), isSideDirection) {
            var scrolledToLeft = Math.round(element.scrollLeft) <= 0,
                scrolledToRight = element.scrollWidth - element.clientWidth - Math.round(element.scrollLeft) <= 5;
            setFaderState(faderLeft, !scrolledToLeft), setFaderState(faderRight, !scrolledToRight)
        } else {
            var scrolledToBottom = Math.round(element.scrollTop + 1) >= element.scrollHeight - element.offsetHeight;
            setFaderState(fader, !scrolledToBottom)
        }
        isFadeDisabled && (dialog.setVisibility(fader, "show"), dialog.setVisibility(faderLeft, "show"), dialog.setVisibility(faderRight, "show"))
    }

    function setEventListeners(window, document, dialog) {
        window.addEventListener("resize", (function() {
            onNewTab(document, dialog)
        }), !1);
        for (var scrollElements = document.querySelectorAll(".CybotCookiebotScrollArea, .CybotCookiebotScrollAreaSide ul"), _loop_1 = function(i) {
                var scrollElement = scrollElements[i];
                scrollElements[i].addEventListener("scroll", (function() {
                    calcFadeState(scrollElement, !1, dialog)
                }), !1)
            }, i = 0; i < scrollElements.length; i++) _loop_1(i);
        for (var navItemsArray = [".CybotCookiebotDialogNavItem", "#CybotCookiebotDialogBodyContentTextShowIABVendors", "#CybotCookiebotDialogBodyContentTextToggleDetails", "#CybotCookiebotDialogBodyEdgeMoreDetailsLink"], navItemsClasses = navItemsArray.join(","), navItems = document.querySelectorAll(navItemsClasses), j = 0; j < navItems.length; j++) navItems[j].addEventListener("click", (function() {
            onNewTab(document, dialog)
        }));
        for (var contentHeightTriggerClasesArray = ["#CybotCookiebotDialogBodyLevelButtonCustomize", ".CybotCookiebotDialogDetailBodyContentCookieContainerButton", ".CybotCookiebotDialogDetailBodyContentCookieProvider", ".CybotExpandLink", ".CybotCookiebotDialogDetailBodyContentIABv2Tab", "#CybotCookiebotDialogBodyEdgeMoreDetails"], contentHeightTriggersClasses = contentHeightTriggerClasesArray.join(","), contentHeightTriggers = document.querySelectorAll(contentHeightTriggersClasses), k = 0; k < contentHeightTriggers.length; k++) contentHeightTriggers[k].addEventListener("click", (function(e) {
            onHeightTriggerClick(e, document, dialog)
        }), !1)
    }

    function getFaderRgbaValue(hex, opacity) {
        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        if (result) {
            var values = {
                r: parseInt(result[1], 16),
                g: parseInt(result[2], 16),
                b: parseInt(result[3], 16)
            };
            return "rgba(" + values.r + "," + values.g + "," + values.b + ", " + opacity + ")"
        }
        return "rgba(255, 255, 255, 0.8)"
    }

    function setFaderColors(document, dialog) {
        for (var faders = document.getElementsByClassName("CybotCookiebotFader"), rgbTransitionColor = getFaderRgbaValue(dialog.customColors.background, "0.8"), transparentColor = getFaderRgbaValue(dialog.customColors.background, "0"), i = 0; i < faders.length; i++) {
            var currentFader = faders[i],
                direction = "to top";
            currentFader.classList.contains("CybotCookiebotFaderLeft") ? direction = "to right" : currentFader.classList.contains("CybotCookiebotFaderRight") && (direction = "to left"), currentFader.style.backgroundImage = "linear-gradient(" + direction + "," + dialog.customColors.background + "," + rgbTransitionColor + ", " + transparentColor + ")"
        }
    }

    function initContentFader(window, document, dialog) {
        setFaderColors(document, dialog), setEventListeners(window, document, dialog), onNewTab(document, dialog)
    }
    var IconChrome = '<svg xmlns="http://www.w3.org/2000/svg" width="27" height="28" viewBox="0 0 27 28" fill="none"><g clip-path="url(#clip0_107_20472)"><path d="M26.8332 14C26.8332 21.3626 20.8625 27.3333 13.4998 27.3333C6.13717 27.3333 0.166504 21.3626 0.166504 14C0.166504 6.63729 6.13717 0.666626 13.4998 0.666626C20.8625 0.666626 26.8332 6.63729 26.8332 14Z" fill="#4CAF50"/><path d="M13.5 0.666626V14L18.8333 16.6666L12.938 27.3333C13.1493 27.3333 13.2887 27.3333 13.5 27.3333C20.8687 27.3333 26.8333 21.3686 26.8333 14C26.8333 6.63129 20.8687 0.666626 13.5 0.666626Z" fill="#FFC107"/><path d="M26.8332 14C26.8332 21.3626 20.8625 27.3333 13.4998 27.3333C6.13717 27.3333 0.166504 21.3626 0.166504 14C0.166504 6.63729 6.13717 0.666626 13.4998 0.666626C20.8625 0.666626 26.8332 6.63729 26.8332 14Z" fill="#4CAF50"/><path d="M13.5 0.666626V14L18.8333 16.6666L12.938 27.3333C13.1493 27.3333 13.2887 27.3333 13.5 27.3333C20.8687 27.3333 26.8333 21.3686 26.8333 14C26.8333 6.63129 20.8687 0.666626 13.5 0.666626Z" fill="#FFC107"/><path d="M25.3931 7.99996H13.4998V16.6666L11.4998 16L2.2731 6.83996H2.25977C4.61977 3.12663 8.7731 0.666626 13.4998 0.666626C18.6998 0.666626 23.1998 3.65329 25.3931 7.99996Z" fill="#F44336"/><path d="M2.27197 6.84265L8.16731 16.7507L11.5 16L2.27197 6.84265Z" fill="#DD2C00"/><path d="M12.938 27.3333L18.894 16.6273L16.1667 14.6666L12.938 27.3333Z" fill="#558B2F"/><path d="M25.4099 8H13.4999L12.4473 11.0533L25.4099 8Z" fill="#F9A825"/><path d="M19.5 14C19.5 17.3127 16.8127 20 13.5 20C10.1873 20 7.5 17.3127 7.5 14C7.5 10.6873 10.1873 8 13.5 8C16.8127 8 19.5 10.6873 19.5 14Z" fill="white"/><path d="M18.1668 14C18.1668 16.578 16.0782 18.6667 13.5002 18.6667C10.9222 18.6667 8.8335 16.578 8.8335 14C8.8335 11.422 10.9222 9.33337 13.5002 9.33337C16.0782 9.33337 18.1668 11.422 18.1668 14Z" fill="#2196F3"/></g><defs><clipPath id="clip0_107_20472"><rect width="27" height="28" fill="white"/></clipPath></defs></svg>',
        IconFirefox = '<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M25.9003 9.47685C25.3213 8.08368 24.1468 6.57945 23.2271 6.10394C23.883 7.37399 24.3382 8.73794 24.5766 10.1473L24.579 10.1697C23.0724 6.4151 20.5185 4.89884 18.4315 1.60158C18.3259 1.43482 18.2204 1.26772 18.1175 1.09134C18.0588 0.990601 18.0116 0.899832 17.9707 0.816282C17.8842 0.648687 17.8175 0.471567 17.772 0.288513C17.7721 0.280066 17.769 0.271893 17.7634 0.265551C17.7579 0.25921 17.7501 0.255145 17.7417 0.254131C17.7335 0.251878 17.7249 0.251878 17.7167 0.254131C17.7149 0.254131 17.7122 0.257226 17.7101 0.257913C17.7081 0.258601 17.7036 0.261695 17.7005 0.263071L17.7056 0.254131C14.3585 2.21392 13.2222 5.84126 13.119 7.65665C11.7819 7.74832 10.5034 8.2409 9.45045 9.07011C9.34063 8.97709 9.22585 8.89009 9.10662 8.80949C8.80302 7.74671 8.79008 6.62194 9.06915 5.55245C7.83993 6.14788 6.74771 6.99202 5.86162 8.03142H5.85543C5.32732 7.36199 5.36445 5.15465 5.39471 4.69358C5.23847 4.75637 5.08933 4.83555 4.9498 4.92979C4.48358 5.26252 4.04775 5.63588 3.64739 6.04549C3.19117 6.50804 2.77449 7.00799 2.40172 7.54009V7.54216V7.53975C1.5451 8.754 0.937446 10.1259 0.61384 11.5762L0.595962 11.6643C0.570862 11.7815 0.480437 12.3687 0.464965 12.4963C0.464965 12.5063 0.462902 12.5156 0.46187 12.5255C0.345228 13.1318 0.272948 13.7458 0.245605 14.3626V14.4313C0.251495 17.7659 1.5073 20.9771 3.76511 23.4311C6.02291 25.885 9.11866 27.4033 12.4412 27.6863C15.7638 27.9693 19.0717 26.9964 21.712 24.9597C24.3523 22.9229 26.1331 19.9703 26.7028 16.6848C26.7252 16.5129 26.7434 16.3427 26.7633 16.169C27.0378 13.9004 26.7407 11.5992 25.899 9.47479L25.9003 9.47685ZM10.5417 19.9085C10.604 19.9384 10.6624 19.9707 10.7264 19.9992L10.7357 20.0051C10.671 19.9741 10.6064 19.9419 10.5417 19.9085ZM24.5794 10.1734V10.1607L24.5818 10.1748L24.5794 10.1734Z" fill="url(#paint0_linear_627_1132)"/><path d="M25.9003 9.47691C25.3213 8.08374 24.1468 6.57951 23.227 6.104C23.8829 7.37405 24.3381 8.738 24.5765 10.1474V10.1601L24.579 10.1742C25.6062 13.1136 25.4577 16.3362 24.1643 19.1686C22.637 22.4456 18.9416 25.8044 13.1551 25.6394C6.90437 25.4623 1.39632 20.8224 0.368285 14.747C0.180902 13.7888 0.368285 13.303 0.462493 12.5242C0.333989 13.1291 0.262277 13.7447 0.248291 14.363V14.4318C0.25418 17.7663 1.50998 20.9776 3.76779 23.4315C6.0256 25.8854 9.12134 27.4037 12.4439 27.6867C15.7665 27.9697 19.0744 26.9968 21.7147 24.9601C24.355 22.9233 26.1358 19.9707 26.7055 16.6852C26.7279 16.5133 26.7461 16.3431 26.766 16.1694C27.0405 13.9009 26.7434 11.5996 25.9016 9.47519L25.9003 9.47691Z" fill="url(#paint1_radial_627_1132)"/><path d="M25.9003 9.47691C25.3213 8.08374 24.1468 6.57951 23.227 6.104C23.8829 7.37405 24.3381 8.738 24.5765 10.1474V10.1601L24.579 10.1742C25.6062 13.1136 25.4577 16.3362 24.1643 19.1686C22.637 22.4456 18.9416 25.8044 13.1551 25.6394C6.90437 25.4623 1.39632 20.8224 0.368285 14.747C0.180902 13.7888 0.368285 13.303 0.462493 12.5242C0.333989 13.1291 0.262277 13.7447 0.248291 14.363V14.4318C0.25418 17.7663 1.50998 20.9776 3.76779 23.4315C6.0256 25.8854 9.12134 27.4037 12.4439 27.6867C15.7665 27.9697 19.0744 26.9968 21.7147 24.9601C24.355 22.9233 26.1358 19.9707 26.7055 16.6852C26.7279 16.5133 26.7461 16.3431 26.766 16.1694C27.0405 13.9009 26.7434 11.5996 25.9016 9.47519L25.9003 9.47691Z" fill="url(#paint2_radial_627_1132)"/><path d="M19.4226 11.0411C19.4515 11.0614 19.4783 11.0817 19.5055 11.102C19.1708 10.5084 18.7541 9.96502 18.2677 9.48774C14.1246 5.34467 17.1823 0.50707 17.6977 0.259517L17.7028 0.251953C14.3557 2.21175 13.2194 5.83908 13.1162 7.65447C13.2716 7.64381 13.4257 7.63075 13.5845 7.63075C14.772 7.63305 15.9377 7.94974 16.9632 8.54863C17.9886 9.14753 18.8372 10.0073 19.4226 11.0404V11.0411Z" fill="url(#paint3_radial_627_1132)"/><path d="M13.5914 11.8698C13.5694 12.2013 12.3983 13.3445 11.9889 13.3445C8.19992 13.3445 7.58447 15.6367 7.58447 15.6367C7.75226 17.567 9.0973 19.1575 10.7232 19.9964C10.7975 20.0349 10.8728 20.0697 10.9481 20.1037C11.0785 20.1615 11.2089 20.2149 11.3394 20.2639C11.8974 20.4614 12.4818 20.5741 13.0733 20.5985C19.7159 20.91 21.0018 12.6561 16.2086 10.2597C17.3393 10.1126 18.4843 10.3906 19.4216 11.0398C18.8362 10.0066 17.9876 9.14691 16.9622 8.54801C15.9367 7.94912 14.771 7.63242 13.5835 7.63013C13.4253 7.63013 13.2706 7.64319 13.1152 7.65385C11.7781 7.74552 10.4996 8.2381 9.44662 9.06731C9.64982 9.23922 9.87915 9.46889 10.3622 9.94509C11.2665 10.8359 13.5856 11.7588 13.5907 11.8671L13.5914 11.8698Z" fill="url(#paint4_radial_627_1132)"/><path d="M13.5914 11.8698C13.5694 12.2013 12.3983 13.3445 11.9889 13.3445C8.19992 13.3445 7.58447 15.6367 7.58447 15.6367C7.75226 17.567 9.0973 19.1575 10.7232 19.9964C10.7975 20.0349 10.8728 20.0697 10.9481 20.1037C11.0785 20.1615 11.2089 20.2149 11.3394 20.2639C11.8974 20.4614 12.4818 20.5741 13.0733 20.5985C19.7159 20.91 21.0018 12.6561 16.2086 10.2597C17.3393 10.1126 18.4843 10.3906 19.4216 11.0398C18.8362 10.0066 17.9876 9.14691 16.9622 8.54801C15.9367 7.94912 14.771 7.63242 13.5835 7.63013C13.4253 7.63013 13.2706 7.64319 13.1152 7.65385C11.7781 7.74552 10.4996 8.2381 9.44662 9.06731C9.64982 9.23922 9.87915 9.46889 10.3622 9.94509C11.2665 10.8359 13.5856 11.7588 13.5907 11.8671L13.5914 11.8698Z" fill="url(#paint5_radial_627_1132)"/><path d="M8.82615 8.62745C8.93411 8.69621 9.02316 8.75604 9.10121 8.81002C8.79761 7.74723 8.78466 6.62247 9.06373 5.55298C7.83451 6.14841 6.74229 6.99254 5.8562 8.03195C5.92118 8.03023 7.85416 7.9955 8.82615 8.62745Z" fill="url(#paint6_radial_627_1132)"/><path d="M0.36588 14.7477C1.39426 20.823 6.90196 25.4646 13.1527 25.64C18.9392 25.8036 22.6353 22.4445 24.1619 19.1692C25.4553 16.3368 25.6038 13.1142 24.5765 10.1748V10.1621C24.5765 10.1521 24.5745 10.1463 24.5765 10.1494L24.579 10.1717C25.0517 13.2582 23.4818 16.2471 21.0273 18.2722L21.0197 18.2894C16.2371 22.1849 11.6608 20.6391 10.7359 20.0085C10.6713 19.9776 10.6067 19.9454 10.542 19.9119C7.75396 18.5792 6.60181 16.0404 6.84936 13.8606C6.18753 13.8704 5.53708 13.688 4.97681 13.3356C4.41653 12.9831 3.97049 12.4758 3.69272 11.875C4.42465 11.4266 5.2592 11.1732 6.11685 11.1388C6.9745 11.1043 7.82669 11.2901 8.5922 11.6783C10.1701 12.3946 11.9656 12.4652 13.5948 11.875C13.5897 11.7667 11.2706 10.8435 10.3663 9.95304C9.88326 9.47684 9.65393 9.24751 9.45073 9.07526C9.34091 8.98224 9.22613 8.89524 9.1069 8.81464C9.02782 8.76066 8.93877 8.70221 8.83184 8.63207C7.85985 8.00012 5.92688 8.03485 5.86293 8.03657H5.85674C5.32863 7.36714 5.36576 5.1598 5.39602 4.69873C5.23978 4.76152 5.09065 4.8407 4.95111 4.93494C4.48489 5.26767 4.04906 5.64103 3.64871 6.05064C3.19085 6.51189 2.77244 7.01069 2.39788 7.54181C1.54125 8.75606 0.9336 10.1276 0.609994 11.578C0.603462 11.6051 0.130017 13.6749 0.363473 14.7483L0.36588 14.7477Z" fill="url(#paint7_radial_627_1132)"/><path d="M18.2673 9.48711C18.7538 9.96492 19.1705 10.5089 19.5051 11.1031C19.5783 11.1584 19.6468 11.2134 19.7049 11.2667C22.726 14.0517 21.1431 17.9885 21.0251 18.267C23.4794 16.245 25.0479 13.254 24.5768 10.1665C23.0695 6.40851 20.5128 4.89225 18.4293 1.59498C18.3237 1.42823 18.2182 1.26113 18.1154 1.08475C18.0566 0.984009 18.0095 0.89324 17.9686 0.809691C17.882 0.642095 17.8153 0.464975 17.7698 0.281922C17.7699 0.273475 17.7668 0.265301 17.7613 0.258959C17.7557 0.252618 17.748 0.248553 17.7396 0.247539C17.7314 0.245286 17.7227 0.245286 17.7145 0.247539C17.7128 0.247539 17.71 0.250634 17.7079 0.251321C17.7059 0.252009 17.7014 0.255103 17.6983 0.256479C17.1829 0.500937 14.126 5.34163 18.2691 9.48126L18.2673 9.48711Z" fill="url(#paint8_radial_627_1132)"/><path d="M19.7046 11.2682C19.6465 11.2149 19.5781 11.1599 19.5049 11.1046C19.4777 11.0843 19.4509 11.064 19.422 11.0437C18.4847 10.3945 17.3397 10.1164 16.209 10.2636C21.0019 12.66 19.716 20.9118 13.0737 20.6023C12.4822 20.578 11.8978 20.4653 11.3398 20.2678C11.2093 20.219 11.0789 20.1656 10.9485 20.1076C10.8732 20.0732 10.7979 20.0388 10.7236 20.0003L10.7329 20.0061C11.6592 20.6384 16.2341 22.1832 21.0167 18.287L21.0242 18.2698C21.1435 17.9913 22.7265 14.0546 19.704 11.2696L19.7046 11.2682Z" fill="url(#paint9_radial_627_1132)"/><path d="M7.58487 15.6347C7.58487 15.6347 8.19997 13.3424 11.9893 13.3424C12.3987 13.3424 13.5708 12.1992 13.5918 11.8677C11.9626 12.4579 10.1671 12.3873 8.58918 11.6711C7.82367 11.2828 6.97149 11.0971 6.11383 11.1315C5.25618 11.1659 4.42163 11.4194 3.6897 11.8677C3.96747 12.4685 4.41352 12.9759 4.97379 13.3283C5.53406 13.6807 6.18452 13.8631 6.84634 13.8533C6.59947 16.0321 7.75128 18.5706 10.539 19.9046C10.6012 19.9345 10.6597 19.9669 10.7236 19.9954C9.09632 19.1547 7.75266 17.5649 7.58487 15.6357V15.6347Z" fill="url(#paint10_radial_627_1132)"/><path d="M25.9004 9.47685C25.3214 8.08368 24.1469 6.57945 23.2272 6.10394C23.883 7.37399 24.3382 8.73794 24.5767 10.1473L24.5791 10.1697C23.0724 6.4151 20.5185 4.89884 18.4315 1.60158C18.3259 1.43482 18.2204 1.26772 18.1176 1.09134C18.0588 0.990601 18.0117 0.899832 17.9708 0.816282C17.8842 0.648687 17.8175 0.471567 17.772 0.288513C17.7721 0.280066 17.7691 0.271893 17.7635 0.265551C17.7579 0.25921 17.7502 0.255145 17.7418 0.254131C17.7336 0.251878 17.7249 0.251878 17.7167 0.254131C17.715 0.254131 17.7122 0.257226 17.7102 0.257913C17.7081 0.258601 17.7036 0.261695 17.7005 0.263071L17.7057 0.254131C14.3586 2.21392 13.2222 5.84126 13.1191 7.65665C13.2745 7.64599 13.4285 7.63293 13.5874 7.63293C14.7749 7.63522 15.9406 7.95192 16.9661 8.55081C17.9915 9.14971 18.8401 10.0094 19.4255 11.0426C18.4882 10.3934 17.3431 10.1154 16.2125 10.2625C21.0054 12.6589 19.7195 20.9107 13.0771 20.6013C12.4857 20.5769 11.9013 20.4642 11.3432 20.2667C11.2128 20.2179 11.0824 20.1645 10.952 20.1065C10.8767 20.0721 10.8014 20.0377 10.7271 19.9992L10.7364 20.0051C10.6718 19.9741 10.6071 19.9419 10.5425 19.9085C10.6047 19.9384 10.6632 19.9707 10.7271 19.9992C9.09979 19.1582 7.75613 17.5684 7.58834 15.6395C7.58834 15.6395 8.20344 13.3473 11.9927 13.3473C12.4022 13.3473 13.5743 12.2041 13.5953 11.8726C13.5901 11.7643 11.271 10.8411 10.3668 9.95064C9.88371 9.47444 9.65438 9.24511 9.45118 9.07286C9.34136 8.97984 9.22659 8.89284 9.10736 8.81224C8.80376 7.74946 8.79081 6.62469 9.06988 5.5552C7.84066 6.15063 6.74844 6.99477 5.86235 8.03417H5.85616C5.32805 7.36474 5.36518 5.1574 5.39544 4.69633C5.2392 4.75912 5.09007 4.8383 4.95053 4.93254C4.48432 5.26527 4.04848 5.63863 3.64813 6.04824C3.1919 6.51079 2.77522 7.01074 2.40245 7.54284C1.54583 8.7571 0.938178 10.1286 0.614573 11.579L0.596694 11.667C0.571595 11.7842 0.459165 12.3798 0.443005 12.5077C0.340168 13.1224 0.274493 13.7427 0.246338 14.3653V14.4341C0.252227 17.7687 1.50803 20.9799 3.76584 23.4338C6.02365 25.8878 9.11939 27.4061 12.442 27.6891C15.7645 27.9721 19.0724 26.9992 21.7127 24.9624C24.353 22.9257 26.1338 19.9731 26.7036 16.6875C26.7259 16.5156 26.7441 16.3454 26.7641 16.1718C27.0385 13.9032 26.7414 11.602 25.8997 9.47754L25.9004 9.47685Z" fill="url(#paint11_linear_627_1132)"/><defs><linearGradient id="paint0_linear_627_1132" x1="24.1365" y1="4.51064" x2="2.01389" y2="25.8552" gradientUnits="userSpaceOnUse"><stop offset="0.048" stop-color="#FFF44F"/><stop offset="0.111" stop-color="#FFE847"/><stop offset="0.225" stop-color="#FFC830"/><stop offset="0.368" stop-color="#FF980E"/><stop offset="0.401" stop-color="#FF8B16"/><stop offset="0.462" stop-color="#FF672A"/><stop offset="0.534" stop-color="#FF3647"/><stop offset="0.705" stop-color="#E31587"/></linearGradient><radialGradient id="paint1_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(23.2803 3.34654) scale(27.7809 27.7809)"><stop offset="0.129" stop-color="#FFBD4F"/><stop offset="0.186" stop-color="#FFAC31"/><stop offset="0.247" stop-color="#FF9D17"/><stop offset="0.283" stop-color="#FF980E"/><stop offset="0.403" stop-color="#FF563B"/><stop offset="0.467" stop-color="#FF3750"/><stop offset="0.71" stop-color="#F5156C"/><stop offset="0.782" stop-color="#EB0878"/><stop offset="0.86" stop-color="#E50080"/></radialGradient><radialGradient id="paint2_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(12.9656 14.6927) scale(27.7809 27.7809)"><stop offset="0.3" stop-color="#960E18"/><stop offset="0.351" stop-color="#B11927" stop-opacity="0.74"/><stop offset="0.435" stop-color="#DB293D" stop-opacity="0.343"/><stop offset="0.497" stop-color="#F5334B" stop-opacity="0.094"/><stop offset="0.53" stop-color="#FF3750" stop-opacity="0"/></radialGradient><radialGradient id="paint3_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(16.4039 -2.84246) scale(20.124 20.124)"><stop offset="0.132" stop-color="#FFF44F"/><stop offset="0.252" stop-color="#FFDC3E"/><stop offset="0.506" stop-color="#FF9D12"/><stop offset="0.526" stop-color="#FF980E"/></radialGradient><radialGradient id="paint4_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(9.87124 21.9129) scale(13.2269 13.2269)"><stop offset="0.353" stop-color="#3A8EE6"/><stop offset="0.472" stop-color="#5C79F0"/><stop offset="0.669" stop-color="#9059FF"/><stop offset="1" stop-color="#C139E6"/></radialGradient><radialGradient id="paint5_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(14.3093 12.3078) rotate(-13.5916) scale(7.01403 8.21168)"><stop offset="0.206" stop-color="#9059FF" stop-opacity="0"/><stop offset="0.278" stop-color="#8C4FF3" stop-opacity="0.064"/><stop offset="0.747" stop-color="#7716A8" stop-opacity="0.45"/><stop offset="0.975" stop-color="#6E008B" stop-opacity="0.6"/></radialGradient><radialGradient id="paint6_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(12.622 2.31485) scale(9.51703 9.51703)"><stop stop-color="#FFE226"/><stop offset="0.121" stop-color="#FFDB27"/><stop offset="0.295" stop-color="#FFC82A"/><stop offset="0.502" stop-color="#FFA930"/><stop offset="0.732" stop-color="#FF7E37"/><stop offset="0.792" stop-color="#FF7139"/></radialGradient><radialGradient id="paint7_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(20.1859 -3.87382) scale(40.6055 40.6055)"><stop offset="0.113" stop-color="#FFF44F"/><stop offset="0.456" stop-color="#FF980E"/><stop offset="0.622" stop-color="#FF5634"/><stop offset="0.716" stop-color="#FF3647"/><stop offset="0.904" stop-color="#E31587"/></radialGradient><radialGradient id="paint8_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(16.8109 -1.62252) rotate(83.976) scale(29.7563 19.5288)"><stop stop-color="#FFF44F"/><stop offset="0.06" stop-color="#FFE847"/><stop offset="0.168" stop-color="#FFC830"/><stop offset="0.304" stop-color="#FF980E"/><stop offset="0.356" stop-color="#FF8B16"/><stop offset="0.455" stop-color="#FF672A"/><stop offset="0.57" stop-color="#FF3647"/><stop offset="0.737" stop-color="#E31587"/></radialGradient><radialGradient id="paint9_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(12.6219 5.75329) scale(25.3467 25.3467)"><stop offset="0.137" stop-color="#FFF44F"/><stop offset="0.48" stop-color="#FF980E"/><stop offset="0.592" stop-color="#FF5634"/><stop offset="0.655" stop-color="#FF3647"/><stop offset="0.904" stop-color="#E31587"/></radialGradient><radialGradient id="paint10_radial_627_1132" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(19.1545 7.12849) scale(27.7431)"><stop offset="0.094" stop-color="#FFF44F"/><stop offset="0.231" stop-color="#FFE141"/><stop offset="0.509" stop-color="#FFAF1E"/><stop offset="0.626" stop-color="#FF980E"/></radialGradient><linearGradient id="paint11_linear_627_1132" x1="23.8684" y1="4.39717" x2="5.04749" y2="23.2215" gradientUnits="userSpaceOnUse"><stop offset="0.167" stop-color="#FFF44F" stop-opacity="0.8"/><stop offset="0.266" stop-color="#FFF44F" stop-opacity="0.634"/><stop offset="0.489" stop-color="#FFF44F" stop-opacity="0.217"/><stop offset="0.6" stop-color="#FFF44F" stop-opacity="0"/></linearGradient></defs></svg>',
        IconEdge = '<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_627_1125)"><path d="M25.2767 20.8359C24.9012 21.0311 24.514 21.2027 24.1173 21.35C22.8612 21.8175 21.531 22.0547 20.1907 22.05C15.0173 22.05 10.511 18.4953 10.511 13.9234C10.5178 13.3112 10.6875 12.7119 11.0028 12.1871C11.318 11.6623 11.7675 11.2309 12.3048 10.9375C7.62354 11.1344 6.42041 16.0125 6.42041 18.8672C6.42041 26.9609 13.8688 27.7703 15.4767 27.7703C16.3407 27.7703 17.6423 27.5188 18.4298 27.2672L18.572 27.2234C21.5857 26.1819 24.1549 24.1451 25.8563 21.4484C25.9058 21.3665 25.927 21.2706 25.9168 21.1755C25.9065 21.0803 25.8653 20.9911 25.7995 20.9216C25.7337 20.8521 25.647 20.8061 25.5525 20.7906C25.4581 20.7752 25.3612 20.7911 25.2767 20.8359Z" fill="url(#paint0_linear_627_1125)"/><path opacity="0.35" d="M25.2767 20.8359C24.9012 21.0311 24.514 21.2027 24.1173 21.35C22.8612 21.8175 21.531 22.0547 20.1907 22.05C15.0173 22.05 10.511 18.4953 10.511 13.9234C10.5178 13.3112 10.6875 12.7119 11.0028 12.1871C11.318 11.6623 11.7675 11.2309 12.3048 10.9375C7.62354 11.1344 6.42041 16.0125 6.42041 18.8672C6.42041 26.9609 13.8688 27.7703 15.4767 27.7703C16.3407 27.7703 17.6423 27.5188 18.4298 27.2672L18.572 27.2234C21.5857 26.1819 24.1549 24.1451 25.8563 21.4484C25.9058 21.3665 25.927 21.2706 25.9168 21.1755C25.9065 21.0803 25.8653 20.9911 25.7995 20.9216C25.7337 20.8521 25.647 20.8061 25.5525 20.7906C25.4581 20.7752 25.3612 20.7911 25.2767 20.8359Z" fill="url(#paint1_radial_627_1125)"/><path d="M11.5608 26.3922C10.5873 25.7876 9.74337 24.9957 9.07802 24.0625C8.31824 23.0226 7.79524 21.829 7.54574 20.5654C7.29623 19.3019 7.32627 17.9991 7.63373 16.7484C7.94119 15.4977 8.51863 14.3294 9.32553 13.3256C10.1324 12.3218 11.1492 11.5067 12.3046 10.9375C12.6546 10.7735 13.2343 10.4891 14.0108 10.5C14.5573 10.5043 15.0953 10.6348 15.583 10.8815C16.0706 11.1281 16.4946 11.4842 16.8218 11.9219C17.2619 12.5137 17.5031 13.2298 17.5108 13.9672C17.5108 13.9454 20.1905 5.26099 8.76083 5.26099C3.95927 5.26099 0.0108348 9.81099 0.0108348 13.8141C-0.00826372 15.9287 0.443826 18.021 1.33427 19.9391C2.79254 23.0443 5.34017 25.506 8.49356 26.8569C11.6469 28.2077 15.1866 28.3538 18.4405 27.2672C17.3005 27.6273 16.0959 27.7355 14.91 27.5844C13.7241 27.4334 12.5851 27.0266 11.5718 26.3922H11.5608Z" fill="url(#paint2_linear_627_1125)"/><path opacity="0.41" d="M11.5608 26.3922C10.5873 25.7876 9.74337 24.9957 9.07802 24.0625C8.31824 23.0226 7.79524 21.829 7.54574 20.5654C7.29623 19.3019 7.32627 17.9991 7.63373 16.7484C7.94119 15.4977 8.51863 14.3294 9.32553 13.3256C10.1324 12.3218 11.1492 11.5067 12.3046 10.9375C12.6546 10.7735 13.2343 10.4891 14.0108 10.5C14.5573 10.5043 15.0953 10.6348 15.583 10.8815C16.0706 11.1281 16.4946 11.4842 16.8218 11.9219C17.2619 12.5137 17.5031 13.2298 17.5108 13.9672C17.5108 13.9454 20.1905 5.26099 8.76083 5.26099C3.95927 5.26099 0.0108348 9.81099 0.0108348 13.8141C-0.00826372 15.9287 0.443826 18.021 1.33427 19.9391C2.79254 23.0443 5.34017 25.506 8.49356 26.8569C11.6469 28.2077 15.1866 28.3538 18.4405 27.2672C17.3005 27.6273 16.0959 27.7355 14.91 27.5844C13.7241 27.4334 12.5851 27.0266 11.5718 26.3922H11.5608Z" fill="url(#paint3_radial_627_1125)"/><path d="M16.6687 16.275C16.5703 16.3844 16.2969 16.5484 16.2969 16.8875C16.2969 17.1719 16.4828 17.4563 16.8219 17.6859C18.3859 18.7797 21.35 18.6266 21.3609 18.6266C22.5269 18.6258 23.6714 18.3123 24.675 17.7188C25.6854 17.1278 26.5238 16.2829 27.107 15.268C27.6903 14.2531 27.9981 13.1034 28 11.9328C28.0328 9.48281 27.125 7.85313 26.7641 7.13125C24.4344 2.60312 19.4359 6.8539e-08 14 6.8539e-08C10.3208 -0.000363734 6.78939 1.44758 4.16947 4.03066C1.54954 6.61374 0.0517383 10.1243 0 13.8031C0.0546875 9.81094 4.025 6.58437 8.75 6.58437C9.13281 6.58437 11.3203 6.61719 13.3438 7.67813C14.7653 8.38453 15.9425 9.50078 16.7234 10.8828C17.3906 12.0422 17.5109 13.5188 17.5109 14.1094C17.5109 14.7 17.2156 15.5641 16.6578 16.2859L16.6687 16.275Z" fill="url(#paint4_radial_627_1125)"/><path d="M16.6687 16.275C16.5703 16.3844 16.2969 16.5484 16.2969 16.8875C16.2969 17.1719 16.4828 17.4563 16.8219 17.6859C18.3859 18.7797 21.35 18.6266 21.3609 18.6266C22.5269 18.6258 23.6714 18.3123 24.675 17.7188C25.6854 17.1278 26.5238 16.2829 27.107 15.268C27.6903 14.2531 27.9981 13.1034 28 11.9328C28.0328 9.48281 27.125 7.85313 26.7641 7.13125C24.4344 2.60312 19.4359 6.8539e-08 14 6.8539e-08C10.3208 -0.000363734 6.78939 1.44758 4.16947 4.03066C1.54954 6.61374 0.0517383 10.1243 0 13.8031C0.0546875 9.81094 4.025 6.58437 8.75 6.58437C9.13281 6.58437 11.3203 6.61719 13.3438 7.67813C14.7653 8.38453 15.9425 9.50078 16.7234 10.8828C17.3906 12.0422 17.5109 13.5188 17.5109 14.1094C17.5109 14.7 17.2156 15.5641 16.6578 16.2859L16.6687 16.275Z" fill="url(#paint5_radial_627_1125)"/></g><defs><linearGradient id="paint0_linear_627_1125" x1="6.42041" y1="19.3594" x2="25.9329" y2="19.3594" gradientUnits="userSpaceOnUse"><stop stop-color="#0C59A4"/><stop offset="1" stop-color="#114A8B"/></linearGradient><radialGradient id="paint1_radial_627_1125" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(17.1938 19.5065) scale(10.4344 9.91266)"><stop offset="0.7" stop-opacity="0"/><stop offset="0.9" stop-opacity="0.5"/><stop offset="1"/></radialGradient><linearGradient id="paint2_linear_627_1125" x1="16.7015" y1="10.8938" x2="4.52802" y2="24.161" gradientUnits="userSpaceOnUse"><stop stop-color="#1B9DE2"/><stop offset="0.2" stop-color="#1595DF"/><stop offset="0.7" stop-color="#0680D7"/><stop offset="1" stop-color="#0078D4"/></linearGradient><radialGradient id="paint3_radial_627_1125" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(7.71685 21.7588) rotate(-81.3844) scale(15.6828 12.6702)"><stop offset="0.8" stop-opacity="0"/><stop offset="0.9" stop-opacity="0.5"/><stop offset="1"/></radialGradient><radialGradient id="paint4_radial_627_1125" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(2.83172 5.17519) rotate(92.2906) scale(22.1552 47.186)"><stop stop-color="#35C1F1"/><stop offset="0.1" stop-color="#34C1ED"/><stop offset="0.2" stop-color="#2FC2DF"/><stop offset="0.3" stop-color="#2BC3D2"/><stop offset="0.7" stop-color="#36C752"/></radialGradient><radialGradient id="paint5_radial_627_1125" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(26.2566 8.45469) rotate(73.7398) scale(10.6422 8.65423)"><stop stop-color="#66EB6E"/><stop offset="1" stop-color="#66EB6E" stop-opacity="0"/></radialGradient><clipPath id="clip0_627_1125"><rect width="28" height="28" fill="white"/></clipPath></defs></svg>',
        IconSafari = '<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_627_1242)"><path opacity="0.53" d="M26.7707 15.3658C26.7707 16.9807 26.4404 18.5797 25.7987 20.0716C25.1569 21.5635 24.2163 22.9191 23.0305 24.061C21.8447 25.2028 20.4369 26.1086 18.8876 26.7266C17.3383 27.3445 15.6777 27.6626 14.0007 27.6626C12.3237 27.6626 10.6632 27.3445 9.11384 26.7266C7.56452 26.1086 6.15676 25.2028 4.97096 24.061C3.78516 22.9191 2.84452 21.5635 2.20277 20.0716C1.56102 18.5797 1.23071 16.9807 1.23071 15.3658C1.23071 12.1045 2.57612 8.97682 4.97096 6.67073C7.3658 4.36464 10.6139 3.06909 14.0007 3.06909C15.6777 3.06909 17.3383 3.38716 18.8876 4.00513C20.4369 4.6231 21.8447 5.52887 23.0305 6.67073C24.2163 7.81259 25.1569 9.16817 25.7987 10.6601C26.4404 12.152 26.7707 13.751 26.7707 15.3658Z" fill="black"/><path d="M27.2562 14.2801C27.2562 16.0209 26.9133 17.7447 26.2472 19.353C25.581 20.9613 24.6045 22.4227 23.3736 23.6536C22.1426 24.8846 20.6813 25.861 19.073 26.5272C17.4647 27.1934 15.7409 27.5363 14.0001 27.5363C10.4843 27.5363 7.11255 26.1396 4.62653 23.6536C2.14052 21.1676 0.743896 17.7958 0.743896 14.2801C0.743896 10.7643 2.14052 7.39258 4.62653 4.90657C7.11255 2.42056 10.4843 1.02393 14.0001 1.02393C15.7409 1.02393 17.4647 1.36681 19.073 2.03299C20.6813 2.69918 22.1426 3.67562 23.3736 4.90657C24.6045 6.13752 25.581 7.59886 26.2472 9.20718C26.9133 10.8155 27.2562 12.5393 27.2562 14.2801Z" fill="url(#paint0_linear_627_1242)" stroke="#CDCDCD" stroke-width="0.351543" stroke-linecap="round" stroke-linejoin="round"/><path d="M26.2173 14.2802C26.2173 17.5204 24.9301 20.628 22.6389 22.9192C20.3477 25.2104 17.2402 26.4976 13.9999 26.4976C10.7596 26.4976 7.65208 25.2104 5.36087 22.9192C3.06966 20.628 1.78247 17.5204 1.78247 14.2802C1.78247 11.0399 3.06966 7.93236 5.36087 5.64114C7.65208 3.34993 10.7596 2.06274 13.9999 2.06274C17.2402 2.06274 20.3477 3.34993 22.6389 5.64114C24.9301 7.93236 26.2173 11.0399 26.2173 14.2802Z" fill="url(#paint1_radial_627_1242)"/><path d="M14 2.69971C13.9013 2.69971 13.8219 2.77915 13.8219 2.87783V4.93244C13.8219 5.03112 13.9013 5.11056 14 5.11056C14.0987 5.11056 14.1781 5.03112 14.1781 4.93244V2.87783C14.1781 2.77915 14.0987 2.69971 14 2.69971ZM12.8347 2.77336C12.8229 2.77209 12.8108 2.77209 12.7985 2.77351C12.7003 2.78375 12.6296 2.87101 12.6398 2.96916L12.7296 3.82872C12.7398 3.92687 12.8271 3.99764 12.9253 3.98739C13.0234 3.97715 13.0942 3.88989 13.0839 3.79174L12.9942 2.93218C12.9852 2.8463 12.9173 2.78138 12.8347 2.77336ZM15.1735 2.7742C15.0909 2.78216 15.0229 2.84708 15.0139 2.93295L14.9235 3.79244C14.9131 3.89058 14.9839 3.97792 15.0821 3.98824C15.1802 3.99857 15.2675 3.92786 15.2778 3.82972L15.3682 2.97016C15.3785 2.87202 15.3077 2.78475 15.2096 2.77443C15.1973 2.77316 15.1853 2.77315 15.1735 2.7742ZM11.6377 2.94695C11.6258 2.94704 11.6138 2.94821 11.6017 2.95075C11.5052 2.97119 11.4439 3.06539 11.4643 3.16193L11.8898 5.17195C11.9103 5.2685 12.0045 5.32977 12.101 5.30933C12.1975 5.28889 12.2588 5.19477 12.2384 5.09823L11.8129 3.08813C11.795 3.00366 11.7206 2.9463 11.6377 2.94695ZM16.3704 2.94864C16.2874 2.94779 16.2131 3.00532 16.1951 3.08978L15.7682 5.09956C15.7476 5.1961 15.8089 5.29032 15.9054 5.31082C16.0019 5.33135 16.0961 5.27011 16.1167 5.1736L16.5436 3.16381C16.5642 3.06728 16.5029 2.97306 16.4064 2.95255C16.3943 2.95001 16.3823 2.94864 16.3704 2.94864ZM10.4953 3.26906C10.4722 3.26694 10.4484 3.26948 10.4249 3.27727C10.3311 3.30778 10.28 3.40782 10.3105 3.50167L10.5776 4.32364C10.6081 4.41749 10.7082 4.46852 10.8021 4.43803C10.8959 4.40752 10.9469 4.3074 10.9164 4.21355L10.6493 3.39158C10.6265 3.32119 10.5645 3.27494 10.4953 3.26906ZM17.5064 3.26948C17.4372 3.27536 17.3752 3.32163 17.3523 3.39202L17.0851 4.21391C17.0546 4.30776 17.1056 4.40788 17.1994 4.43839C17.2932 4.4689 17.3934 4.41791 17.4239 4.32408L17.6911 3.50211C17.7216 3.40826 17.6706 3.30814 17.5768 3.27763C17.5533 3.27001 17.5294 3.26753 17.5064 3.26948ZM9.36557 3.68246C9.34242 3.68288 9.319 3.68796 9.29646 3.69799C9.20633 3.73807 9.16597 3.8429 9.20605 3.93308L10.0405 5.81056C10.0806 5.90074 10.1855 5.94106 10.2756 5.90097C10.3658 5.8609 10.4062 5.75606 10.3661 5.66588L9.53155 3.7884C9.5015 3.72076 9.43499 3.68111 9.36557 3.68246ZM18.6488 3.68877C18.5794 3.6875 18.5128 3.72689 18.4827 3.79447L17.6457 5.67081C17.6055 5.76093 17.6456 5.86584 17.7358 5.90605C17.8259 5.94625 17.9308 5.90607 17.971 5.81595L18.808 3.93962C18.8482 3.84949 18.8081 3.74458 18.7179 3.70437C18.6954 3.69434 18.672 3.68927 18.6488 3.68877ZM8.31697 4.23728C8.28278 4.23474 8.24754 4.24236 8.2155 4.2609C8.13003 4.31024 8.10096 4.41875 8.1503 4.50421L8.58243 5.25268C8.63177 5.33815 8.74028 5.36722 8.82574 5.31787C8.9112 5.26853 8.94028 5.16002 8.89094 5.07456L8.45881 4.32609C8.42796 4.27267 8.37397 4.24127 8.31697 4.23728ZM19.683 4.23728C19.626 4.24109 19.5721 4.27266 19.5413 4.32608L19.1091 5.07455C19.0597 5.16001 19.0889 5.26852 19.1744 5.31786C19.2598 5.3672 19.3683 5.33813 19.4177 5.25267L19.8498 4.5042C19.8991 4.41874 19.8701 4.31023 19.7846 4.26088C19.7526 4.24239 19.7172 4.23491 19.683 4.23728ZM7.29874 4.87236C7.26446 4.87363 7.23014 4.88463 7.20018 4.90634C7.12031 4.96429 7.10265 5.07524 7.16062 5.15512L8.36704 6.81819C8.42499 6.89807 8.53601 6.91573 8.61589 6.8578C8.69577 6.79985 8.71343 6.6889 8.65546 6.60902L7.44896 4.94595C7.41273 4.89602 7.35584 4.87041 7.29874 4.87236ZM20.714 4.88142C20.6569 4.8793 20.6 4.9049 20.5637 4.95476L19.355 6.61622C19.297 6.69602 19.3145 6.80701 19.3943 6.86507C19.4741 6.92312 19.5851 6.90565 19.6431 6.82588L20.8518 5.16442C20.9098 5.08462 20.8923 4.97363 20.8125 4.91557C20.7826 4.89382 20.7483 4.88264 20.714 4.88142ZM6.38859 5.63565C6.34313 5.63311 6.29673 5.64831 6.26006 5.68132C6.18671 5.74734 6.18082 5.85951 6.24685 5.93286L6.82512 6.57524C6.89114 6.64859 7.00332 6.65449 7.07666 6.58844C7.15001 6.52242 7.15591 6.41017 7.08986 6.33683L6.51168 5.69452C6.47867 5.65783 6.43407 5.63804 6.38859 5.63565ZM21.6127 5.63692C21.5673 5.63946 21.5227 5.65914 21.4896 5.69581L20.9114 6.33804C20.8453 6.41137 20.8512 6.52362 20.9245 6.58965C20.9979 6.65569 21.1101 6.64977 21.1761 6.57645L21.7544 5.93423C21.8205 5.86088 21.8145 5.74864 21.7412 5.68261C21.7045 5.6496 21.6582 5.63454 21.6127 5.63692ZM5.51628 6.47357C5.47081 6.47611 5.42628 6.49578 5.39327 6.53246C5.32725 6.6058 5.33315 6.71798 5.40648 6.784L6.93348 8.15863C7.00682 8.22466 7.119 8.21875 7.18502 8.14543C7.25105 8.07208 7.24522 7.95991 7.17186 7.89388L5.64478 6.51925C5.60809 6.48625 5.56175 6.47118 5.51628 6.47357ZM22.4893 6.47958C22.4438 6.47704 22.3974 6.49219 22.3607 6.52517L20.8327 7.89872C20.7593 7.96469 20.7533 8.07687 20.8193 8.15026C20.8853 8.22365 20.9975 8.22961 21.0709 8.16363L22.5989 6.79008C22.6723 6.72411 22.6782 6.61193 22.6123 6.53854C22.5793 6.50185 22.5347 6.482 22.4893 6.47958ZM4.79087 7.40633C4.73376 7.40421 4.67683 7.42994 4.64058 7.47982C4.58257 7.55966 4.60016 7.67059 4.68002 7.7286L5.37921 8.2366C5.45905 8.29461 5.56997 8.2771 5.62798 8.19724C5.68599 8.11741 5.66844 8.0064 5.58862 7.94839L4.88943 7.44039C4.85951 7.41864 4.82513 7.40756 4.79087 7.40633ZM23.214 7.41281C23.1797 7.41407 23.1454 7.42504 23.1154 7.44679L22.4159 7.95433C22.3361 8.01228 22.3184 8.1233 22.3763 8.20318C22.4343 8.28306 22.5452 8.30064 22.6251 8.24271L23.3247 7.73517C23.4046 7.67722 23.4221 7.56627 23.3642 7.48639C23.328 7.43647 23.2711 7.41085 23.214 7.41281ZM4.11297 8.40129C4.05597 8.4051 4.00205 8.43667 3.97121 8.49008C3.92187 8.57554 3.95094 8.68405 4.0364 8.73339L5.81571 9.7607C5.90117 9.81004 6.00968 9.78097 6.05903 9.69551C6.10837 9.61004 6.0793 9.50153 5.99384 9.45219L4.21452 8.42488C4.18249 8.40639 4.14717 8.39892 4.11297 8.40129ZM23.887 8.40129C23.8529 8.39875 23.8175 8.40637 23.7855 8.4249L22.0062 9.45221C21.9207 9.50155 21.8916 9.61006 21.941 9.69552C21.9903 9.78098 22.0988 9.81006 22.1843 9.76071L23.9637 8.73341C24.0492 8.68407 24.0782 8.57556 24.0289 8.4901C23.998 8.43668 23.944 8.40527 23.887 8.40129ZM3.60043 9.4618C3.53102 9.46011 3.46445 9.49984 3.4343 9.56743C3.3941 9.65755 3.43427 9.76247 3.5244 9.80267L4.31377 10.1548C4.4039 10.195 4.50882 10.1548 4.54901 10.0647C4.58922 9.97454 4.54896 9.86962 4.45884 9.82942L3.66955 9.47733C3.64703 9.46726 3.62357 9.46227 3.60043 9.4618ZM24.403 9.46912C24.3799 9.46954 24.3564 9.47462 24.3339 9.48465L23.5443 9.83613C23.4542 9.87629 23.4139 9.98114 23.454 10.0713C23.4942 10.1615 23.5991 10.2018 23.6892 10.1616L24.4788 9.81007C24.5689 9.76995 24.6092 9.66506 24.569 9.5749C24.5389 9.50729 24.4725 9.46774 24.403 9.46912ZM3.14363 10.5702C3.07445 10.576 3.01242 10.6222 2.98949 10.6926C2.95894 10.7864 3.0098 10.8866 3.10365 10.9172L5.05717 11.5537C5.15099 11.5843 5.25115 11.5334 5.28173 11.4395C5.31228 11.3457 5.26141 11.2456 5.16757 11.215L3.21405 10.5785C3.19061 10.5708 3.16669 10.5683 3.14363 10.5702ZM24.859 10.5778C24.8359 10.5757 24.8121 10.5783 24.7887 10.5861L22.8347 11.2212C22.7408 11.2517 22.6899 11.3518 22.7204 11.4457C22.7509 11.5395 22.851 11.5905 22.9448 11.56L24.8987 10.9249C24.9926 10.8943 25.0436 10.7942 25.0131 10.7004C24.9902 10.63 24.9282 10.5837 24.859 10.5778ZM2.85903 11.7338C2.77605 11.7329 2.70163 11.7905 2.68368 11.875C2.66315 11.9715 2.72439 12.0657 2.8209 12.0862L3.66632 12.2659C3.76284 12.2864 3.85705 12.2252 3.87757 12.1287C3.8981 12.0322 3.83686 11.9379 3.74035 11.9174L2.89501 11.7378C2.88295 11.7352 2.87088 11.7338 2.85903 11.7338ZM25.1414 11.7355C25.1295 11.7356 25.1175 11.7372 25.1055 11.7393L24.2601 11.9189C24.1635 11.9394 24.1023 12.0335 24.1228 12.13C24.1434 12.2266 24.2376 12.2878 24.3341 12.2673L25.1794 12.0878C25.276 12.0672 25.3372 11.973 25.3167 11.8765C25.2988 11.792 25.2243 11.7348 25.1414 11.7355ZM2.64362 12.9041C2.56102 12.9121 2.49303 12.9769 2.48395 13.0627C2.47359 13.1609 2.54418 13.2483 2.64232 13.2586L4.68555 13.4746C4.78368 13.485 4.87106 13.4143 4.88143 13.3162C4.8918 13.2181 4.82113 13.1307 4.72299 13.1203L2.67976 12.9043C2.66749 12.903 2.65543 12.903 2.64362 12.9041ZM25.3583 12.9195C25.3465 12.9182 25.3344 12.9182 25.3221 12.9197L23.2786 13.1329C23.1805 13.1431 23.1097 13.2304 23.12 13.3286C23.1302 13.4267 23.2175 13.4975 23.3156 13.4872L25.3591 13.274C25.4572 13.2637 25.528 13.1765 25.5177 13.0783C25.5088 12.9924 25.4409 12.9275 25.3583 12.9195ZM2.60903 14.1022C2.51034 14.1022 2.43091 14.1816 2.43091 14.2803C2.43091 14.379 2.51034 14.4584 2.60903 14.4584H3.47328C3.57196 14.4584 3.65148 14.379 3.65148 14.2803C3.65148 14.1816 3.57196 14.1022 3.47328 14.1022H2.60903ZM24.5267 14.1022C24.4281 14.1022 24.3486 14.1816 24.3486 14.2803C24.3486 14.379 24.4281 14.4584 24.5267 14.4584H25.391C25.4897 14.4584 25.5691 14.379 25.5691 14.2803C25.5691 14.1816 25.4897 14.1022 25.391 14.1022H24.5267ZM4.7206 15.0732C4.7088 15.0719 4.69674 15.0719 4.68446 15.0734L2.64092 15.2866C2.54277 15.2969 2.47202 15.3841 2.48225 15.4823C2.49249 15.5804 2.57975 15.6512 2.6779 15.6409L4.72144 15.4277C4.81959 15.4174 4.89035 15.3302 4.88011 15.232C4.87114 15.1461 4.8032 15.0812 4.7206 15.0732ZM23.2783 15.0858C23.1957 15.0937 23.1277 15.1585 23.1187 15.2444C23.1083 15.3426 23.1789 15.4299 23.277 15.4403L25.3203 15.6563C25.4184 15.6667 25.5058 15.596 25.5161 15.4979C25.5265 15.3997 25.4558 15.3124 25.3577 15.302L23.3145 15.086C23.3023 15.0847 23.2901 15.0847 23.2783 15.0858ZM3.70199 16.2892C3.69014 16.2893 3.67808 16.2904 3.66602 16.293L2.8206 16.4726C2.72407 16.4931 2.66288 16.5873 2.68338 16.6838C2.7039 16.7803 2.7981 16.8415 2.89464 16.821L3.74005 16.6415C3.83658 16.621 3.89777 16.5268 3.87727 16.4303C3.85933 16.3458 3.78497 16.2885 3.70199 16.2892ZM24.2978 16.2909C24.2148 16.29 24.1405 16.3475 24.1225 16.432C24.102 16.5285 24.1631 16.6228 24.2597 16.6433L25.1051 16.8229C25.2016 16.8435 25.2958 16.7823 25.3163 16.6858C25.3369 16.5893 25.2756 16.495 25.1791 16.4744L24.3338 16.2948C24.3217 16.2922 24.3096 16.2909 24.2978 16.2909ZM5.12559 16.9924C5.10252 16.9903 5.07871 16.9929 5.05525 17.0006L3.10127 17.6358C3.00742 17.6663 2.95645 17.7664 2.98696 17.8603C3.01747 17.9541 3.11758 18.0051 3.21144 17.9746L5.16534 17.3394C5.25919 17.3089 5.31024 17.2088 5.27973 17.115C5.25683 17.0446 5.19477 16.9983 5.12559 16.9924ZM22.8725 16.9987C22.8033 17.0045 22.7413 17.0508 22.7184 17.1211C22.6878 17.215 22.7387 17.3151 22.8325 17.3457L24.786 17.9822C24.8799 18.0128 24.98 17.9619 25.0106 17.8681C25.0412 17.7742 24.9903 17.6741 24.8964 17.6435L22.9429 17.007C22.9195 16.9993 22.8956 16.9968 22.8725 16.9987ZM4.37996 18.3836C4.35681 18.384 4.33339 18.389 4.31085 18.399L3.52125 18.7506C3.4311 18.7907 3.39086 18.8956 3.43099 18.9858C3.47115 19.0759 3.57601 19.1162 3.66616 19.076L4.45577 18.7245C4.54592 18.6844 4.58615 18.5795 4.54602 18.4894C4.51593 18.4218 4.44938 18.3822 4.37996 18.3836ZM23.6172 18.3904C23.5478 18.3887 23.4812 18.4284 23.4511 18.496C23.4109 18.5861 23.4511 18.691 23.5412 18.7312L24.3305 19.0833C24.4206 19.1235 24.5255 19.0834 24.5657 18.9932C24.6059 18.9031 24.5657 18.7982 24.4756 18.758L23.6863 18.4059C23.6638 18.3958 23.6404 18.3908 23.6172 18.3904ZM5.91727 18.7764C5.88307 18.7738 5.84776 18.7815 5.81571 18.8L4.0364 19.8273C3.95094 19.8766 3.92187 19.9851 3.97121 20.0706C4.02055 20.1561 4.12906 20.1851 4.21452 20.1358L5.99384 19.1086C6.0793 19.0592 6.10836 18.9506 6.05903 18.8652C6.02818 18.8118 5.97426 18.7804 5.91727 18.7764ZM22.0828 18.7764C22.0258 18.7802 21.9718 18.8117 21.941 18.8652C21.8916 18.9506 21.9207 19.0592 22.0062 19.1086L23.7855 20.1358C23.871 20.1851 23.9795 20.156 24.0289 20.0706C24.0782 19.9851 24.0492 19.8766 23.9637 19.8273L22.1843 18.8C22.1523 18.7815 22.117 18.774 22.0828 18.7764ZM5.47346 20.2839C5.43918 20.2852 5.40485 20.2962 5.3749 20.318L4.6754 20.8255C4.59552 20.8835 4.57786 20.9944 4.63579 21.0743C4.69374 21.1542 4.80469 21.1718 4.88456 21.1139L5.58414 20.6063C5.66402 20.5484 5.68169 20.4374 5.62375 20.3576C5.58752 20.3076 5.53056 20.282 5.47346 20.2839ZM22.5223 20.2899C22.4652 20.2878 22.4083 20.3135 22.372 20.3634C22.314 20.4433 22.3316 20.5543 22.4115 20.6123L23.1107 21.1203C23.1905 21.1783 23.3014 21.1607 23.3594 21.0808C23.4175 21.001 23.3999 20.8901 23.3201 20.8321L22.6209 20.3241C22.591 20.3023 22.5566 20.2912 22.5223 20.2899ZM7.05773 20.3514C7.01227 20.3489 6.96589 20.364 6.92919 20.397L5.40119 21.7706C5.32781 21.8365 5.32184 21.9487 5.38782 22.0221C5.45379 22.0955 5.56597 22.1015 5.63936 22.0355L7.16736 20.6619C7.24075 20.596 7.24671 20.4838 7.18073 20.4104C7.14777 20.3737 7.1032 20.3539 7.05773 20.3514ZM20.9381 20.3563C20.8926 20.3589 20.848 20.3786 20.815 20.4152C20.7489 20.4886 20.7549 20.6007 20.8282 20.6668L22.3552 22.0414C22.4285 22.1074 22.5408 22.1015 22.6068 22.0282C22.6728 21.9549 22.6669 21.8427 22.5936 21.7767L21.0665 20.402C21.0298 20.369 20.9835 20.354 20.9381 20.3563ZM8.50732 21.6612C8.45022 21.6591 8.39323 21.6847 8.35695 21.7346L7.14829 23.396C7.09024 23.4758 7.10771 23.5868 7.18748 23.6449C7.26728 23.7029 7.37828 23.6855 7.43633 23.6057L8.64499 21.9442C8.70304 21.8644 8.68557 21.7534 8.6058 21.6954C8.57588 21.6736 8.54158 21.6624 8.50732 21.6612ZM19.4828 21.6687C19.4485 21.67 19.4142 21.6809 19.3842 21.7027C19.3043 21.7606 19.2867 21.8716 19.3446 21.9515L20.551 23.6145C20.609 23.6944 20.7199 23.7121 20.7998 23.6541C20.8797 23.5962 20.8974 23.4852 20.8394 23.4054L19.633 21.7423C19.5968 21.6924 19.5399 21.6667 19.4828 21.6687ZM6.94703 21.9253C6.90156 21.9279 6.85697 21.9475 6.82395 21.9842L6.24568 22.6264C6.17964 22.6998 6.18549 22.812 6.25884 22.878C6.33218 22.9441 6.44435 22.9382 6.51038 22.8648L7.08872 22.2226C7.15476 22.1492 7.14884 22.037 7.07552 21.971C7.03883 21.9379 6.9925 21.9229 6.94703 21.9253ZM21.0519 21.9262C21.0064 21.9236 20.9601 21.9388 20.9235 21.9718C20.8501 22.0378 20.8442 22.15 20.9102 22.2234L21.4884 22.8657C21.5544 22.9391 21.6666 22.945 21.7399 22.8789C21.8133 22.8129 21.8192 22.7007 21.7531 22.6273L21.175 21.985C21.1419 21.9483 21.0974 21.9285 21.0519 21.9262ZM10.1951 22.6386C10.1257 22.637 10.0593 22.6767 10.0291 22.7443L9.19198 24.6206C9.15178 24.7107 9.19196 24.8156 9.28209 24.8559C9.37221 24.8961 9.47712 24.8559 9.51733 24.7658L10.3544 22.8894C10.3946 22.7993 10.3545 22.6944 10.2643 22.6542C10.2418 22.6441 10.2183 22.6391 10.1951 22.6386ZM17.7936 22.6438C17.7704 22.6442 17.7469 22.6492 17.7244 22.6593C17.6343 22.6993 17.5939 22.8042 17.634 22.8943L18.4685 24.7718C18.5085 24.862 18.6135 24.9023 18.7036 24.8622C18.7938 24.8222 18.8341 24.7173 18.794 24.6271L17.9595 22.7497C17.9295 22.6821 17.863 22.6425 17.7936 22.6438ZM8.72419 23.2188C8.66719 23.2226 8.61326 23.2541 8.58243 23.3076L8.1503 24.056C8.10096 24.1415 8.13003 24.25 8.2155 24.2993C8.30096 24.3487 8.40947 24.3196 8.45881 24.2342L8.89094 23.4857C8.94028 23.4002 8.91121 23.2917 8.82574 23.2424C8.79371 23.2239 8.75839 23.2164 8.72419 23.2188ZM19.2758 23.2188C19.2416 23.2162 19.2064 23.2239 19.1744 23.2424C19.0889 23.2917 19.0598 23.4002 19.1092 23.4857L19.5413 24.2342C19.5906 24.3196 19.6991 24.3487 19.7846 24.2994C19.8701 24.25 19.8991 24.1415 19.8498 24.056L19.4177 23.3076C19.3868 23.2542 19.3328 23.2228 19.2758 23.2188ZM12.0587 23.2456C11.9757 23.2448 11.9014 23.3023 11.8834 23.3867L11.4565 25.3965C11.4359 25.4931 11.4972 25.5873 11.5937 25.6078C11.6902 25.6283 11.7844 25.5671 11.8049 25.4706L12.2319 23.4608C12.2524 23.3643 12.1912 23.27 12.0947 23.2495C12.0826 23.247 12.0706 23.2456 12.0587 23.2456ZM15.935 23.2469C15.9231 23.247 15.9112 23.2481 15.8991 23.2507C15.8026 23.2711 15.7413 23.3652 15.7617 23.4618L16.1872 25.4719C16.2077 25.5684 16.3019 25.6297 16.3984 25.6093C16.495 25.5888 16.5562 25.4946 16.5358 25.3981L16.1102 23.3881C16.0923 23.3036 16.018 23.2462 15.935 23.2469ZM14 23.4496C13.9013 23.4496 13.8219 23.529 13.8219 23.6277V25.6823C13.8219 25.781 13.9013 25.8604 14 25.8604C14.0987 25.8604 14.1781 25.781 14.1781 25.6823V23.6277C14.1781 23.529 14.0987 23.4496 14 23.4496ZM10.7303 24.1135C10.6611 24.1194 10.599 24.1657 10.5762 24.236L10.309 25.058C10.2785 25.1519 10.3295 25.252 10.4233 25.2825C10.5172 25.313 10.6173 25.2619 10.6478 25.1681L10.9149 24.3462C10.9455 24.2524 10.8945 24.1522 10.8006 24.1217C10.7772 24.1141 10.7533 24.1116 10.7303 24.1135ZM17.2683 24.1139C17.2453 24.1118 17.2215 24.1143 17.198 24.1221C17.1042 24.1526 17.0531 24.2527 17.0836 24.3466L17.3507 25.1685C17.3812 25.2624 17.4813 25.3134 17.5752 25.2829C17.669 25.2523 17.72 25.1523 17.6896 25.0585L17.4224 24.2365C17.3995 24.1661 17.3375 24.1198 17.2683 24.1139ZM12.8819 24.5717C12.7993 24.5797 12.7313 24.6445 12.7222 24.7304L12.6319 25.59C12.6216 25.6881 12.6923 25.7754 12.7904 25.7857C12.8886 25.796 12.9759 25.7253 12.9862 25.6272L13.0766 24.7677C13.0869 24.6695 13.0162 24.5822 12.918 24.5719C12.9058 24.5706 12.8937 24.5706 12.8819 24.5717ZM15.111 24.5726C15.0991 24.5713 15.087 24.5713 15.0747 24.5727C14.9766 24.583 14.9058 24.6702 14.9161 24.7684L15.0058 25.628C15.0161 25.7262 15.1033 25.7969 15.2015 25.7866C15.2996 25.7764 15.3704 25.6891 15.3602 25.591L15.2705 24.7314C15.2615 24.6455 15.1936 24.5806 15.111 24.5726Z" fill="#F4F2F3"/><g opacity="0.409" filter="url(#filter0_f_627_1242)"><path d="M22.3484 7.15503L12.603 12.8172L6.44116 22.5176L15.4554 15.8409L22.3484 7.15503Z" fill="black"/></g><path d="M15.3967 15.7428L12.6033 12.8175L22.5125 6.15161L15.3967 15.7428Z" fill="#FF5150"/><path d="M15.3967 15.7427L12.6034 12.8174L5.48755 22.4086L15.3967 15.7427Z" fill="#F1F1F1"/><path opacity="0.243" d="M5.48755 22.4088L15.3967 15.7428L22.5126 6.15161L5.48755 22.4088Z" fill="black"/></g><defs><filter id="filter0_f_627_1242" x="3.89633" y="4.61019" width="20.9969" height="20.4522" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/><feGaussianBlur stdDeviation="1.27242" result="effect1_foregroundBlur_627_1242"/></filter><linearGradient id="paint0_linear_627_1242" x1="13.9996" y1="27.536" x2="13.9996" y2="1.02386" gradientUnits="userSpaceOnUse"><stop stop-color="#BDBDBD"/><stop offset="1" stop-color="white"/></linearGradient><radialGradient id="paint1_radial_627_1242" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(14.055 12.4987) scale(13.2561 13.2561)"><stop stop-color="#06C2E7"/><stop offset="0.25" stop-color="#0DB8EC"/><stop offset="0.5" stop-color="#12AEF1"/><stop offset="0.75" stop-color="#1F86F9"/><stop offset="1" stop-color="#107DDD"/></radialGradient><clipPath id="clip0_627_1242"><rect width="28" height="27.8468" fill="white"/></clipPath></defs></svg>';

    function canShowPromotionBanner(window, cookieConsent, dialog) {
        var userAgent = window.navigator.userAgent,
            userLanguage = cookieConsent.userCulture.split("-")[0].toLowerCase();
        return dialog.promotionBannerEnabled && 2 === dialog.version && ("de" === userLanguage || "en" === userLanguage) && (userAgent.indexOf("Chrome") > -1 || userAgent.indexOf("Edg") > -1 || userAgent.indexOf("Firefox") > -1 || userAgent.indexOf("Safari") > -1)
    }

    function getPromotionBannerData(window) {
        var userAgent = window.navigator.userAgent,
            url = "https://www.usercentrics-datashield.com/cookiebot/",
            icon = "";
        return userAgent.indexOf("Edg") > -1 ? icon = IconEdge : userAgent.indexOf("Firefox") > -1 ? icon = IconFirefox : userAgent.indexOf("Chrome") > -1 ? icon = IconChrome : userAgent.indexOf("Safari") > -1 && (icon = IconSafari), {
            url: url,
            icon: icon
        }
    }
    var hasFramework = function(cookieConsent) {
            return cookieConsent.hasFramework && !cookieConsent.frameworkBlocked && "tcfv2.2" === cookieConsent.framework.toLowerCase()
        },
        fetchJsonData = function(url, onSuccess, onError) {
            var xmlhttp = new XMLHttpRequest;
            xmlhttp.onreadystatechange = function() {
                if (4 === this.readyState && this.status >= 200 && this.status <= 299) {
                    if (204 === this.status) return void onSuccess({});
                    try {
                        var json = JSON.parse(this.responseText);
                        onSuccess(json)
                    } catch (e) {
                        onError && onError({
                            status: this.status,
                            message: "JSON.parse error: " + e.message
                        })
                    }
                } else 4 === this.readyState && onError && onError({
                    status: this.status,
                    message: this.responseText
                })
            }, xmlhttp.onerror = function() {
                onError && onError({
                    status: -1,
                    message: "onerror"
                })
            }, xmlhttp.open("GET", url, !0), xmlhttp.send()
        };

    function getCookieListFromObject(cookieObject) {
        return [cookieObject.CookieName, "", "", "", "", cookieObject.CookieStorageType.toString(), cookieObject.CookieNameRegex || ""]
    }

    function onSuccess(cookieConsent, shouldFetchCookies) {
        var logConsentJsonUrl = cookieConsent.host + cookieConsent.serial + "/" + cookieConsent.domain + "/cookies.json";
        shouldFetchCookies ? fetchJsonData(logConsentJsonUrl, (function(data) {
            var advertisingCookiesList = data.AdvertisingCookies.map((function(cookie) {
                    return getCookieListFromObject(cookie)
                })),
                preferenceCookiesList = data.PreferenceCookies.map((function(cookie) {
                    return getCookieListFromObject(cookie)
                })),
                statisticsCookiesList = data.StatisticCookies.map((function(cookie) {
                    return getCookieListFromObject(cookie)
                })),
                unclassifiedCookiesList = data.UnclassifiedCookies.map((function(cookie) {
                    return getCookieListFromObject(cookie)
                }));
            cookieConsent.cookieList = __assign(__assign({}, cookieConsent.cookieList), {
                cookieTableAdvertising: advertisingCookiesList,
                cookieTablePreference: preferenceCookiesList,
                cookieTableStatistics: statisticsCookiesList,
                cookieTableUnclassified: unclassifiedCookiesList
            }), cookieConsent.init(), cookieConsent.resetCookies()
        })) : (cookieConsent.init(), cookieConsent.resetCookies())
    }

    function logConsent(cookieConsent, consentURL, asyncLoad, shouldFetchCookies) {
        var truncatedLogConsentUrl = getTruncatedString(consentURL, 4096);
        window.CookieConsent.getScript(truncatedLogConsentUrl, asyncLoad, (function() {
            onSuccess(cookieConsent, shouldFetchCookies)
        }))
    }
    var poweredByUrls = {
        en: "https://www.cookiebot.com/en/what-is-behind-powered-by-cookiebot/",
        fr: "https://www.cookiebot.com/fr/powered-by-cookiebot-c-est-quoi-au-juste/",
        it: "https://www.cookiebot.com/it/cosa-significa-powered-by-cookiebot/",
        es: "https://www.cookiebot.com/es/que-significa-impulsada-por-cookiebot/",
        de: "https://www.cookiebot.com/de/was-steckt-hinter-powered-by-cookiebot/",
        da: "https://www.cookiebot.com/da/hvad-er-powered-by-cookiebot/"
    };

    function sortBannerButtons(dialog) {
        var isE2E = dialog.DOM.classList.contains("CybotEdge"),
            shouldShowRowDirection = isE2E ? window.matchMedia("(min-width: 601px) and (max-width: 1279px)").matches : window.matchMedia("(min-width: 601px)").matches,
            buttonsWrapper = document.getElementById("CybotCookiebotDialogBodyButtonsWrapper"),
            acceptButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonAccept") || document.getElementById("CybotCookiebotDialogBodyButtonAccept") || document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll"),
            customizeButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonCustomize"),
            allowSelectionButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection"),
            declineButton = document.getElementById("CybotCookiebotDialogBodyButtonDecline");
        shouldShowRowDirection && "column" === dialog.buttonsDirection ? (buttonsWrapper.innerHTML = "", buttonsWrapper.appendChild(declineButton), buttonsWrapper.appendChild(allowSelectionButton), buttonsWrapper.appendChild(customizeButton), buttonsWrapper.appendChild(acceptButton), dialog.buttonsDirection = "row") : shouldShowRowDirection || "row" !== dialog.buttonsDirection || (buttonsWrapper.innerHTML = "", buttonsWrapper.appendChild(acceptButton), buttonsWrapper.appendChild(customizeButton), buttonsWrapper.appendChild(allowSelectionButton), buttonsWrapper.appendChild(declineButton), dialog.buttonsDirection = "column")
    }
    var PromotionBannerHTMLTemplate = '<a href="[#PROMOTIONBANNER_URL#]" target="_blank" aria-label="[#PROMOTIONBANNER_ARIA_LABEL#]" rel="noopener nofollow" class="CybotCookiebotDialogPromotionBanner"><div><strong>[#PROMOTIONBANNER_TITLE#]</strong><p>[#PROMOTIONBANNER_BODY#]</p></div><div class="CybotCookiebotDialogPromotionBannerButtonsWrapper"><button class="CybotCookiebotDialogPromotionBannerInstallButton">[#PROMOTIONBANNER_ICON#] [#PROMOTIONBANNER_CTA#]</button> <button id="CybotCookiebotDialogPromotionBannerCloseButton"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><path d="M14 1.41L12.59 0L7 5.59L1.41 0L0 1.41L5.59 7L0 12.59L1.41 14L7 8.41L12.59 14L14 12.59L8.41 7L14 1.41Z"/></svg></button></div></a>';

    function getProviderInfo(dialog, providerName, providerLink) {
        var name = providerName,
            providerTitle = "",
            link = providerLink;
        if (dialog.privacyPolicies.length > 0)
            for (var i = 0; i < dialog.privacyPolicies.length; i++)
                if (dialog.privacyPolicies[i][0] === providerName) {
                    name = dialog.privacyPolicies[i][1], link = dialog.privacyPolicies[i][2], providerTitle = dialog.privacyPolicyText.replace("{0}", dialog.privacyPolicies[i][1]).replace("'", "'");
                    break
                }
        return link && -1 === link.indexOf("http") && (link = null), {
            providerName: name,
            providerLink: link,
            providerTitle: providerTitle
        }
    }

    function getCookieObjectFromArray(dialog, cookieListItem) {
        var providerInfoData = getProviderInfo(dialog, cookieListItem[7], cookieListItem[1]);
        return {
            name: cookieListItem[0],
            domain: cookieListItem[1],
            purpose: cookieListItem[2],
            expiry: cookieListItem[3],
            cookieType: cookieListItem[4],
            storageType: cookieListItem[5],
            nameRegex: cookieListItem[6],
            domains: cookieListItem[7],
            languageCode: cookieListItem[8],
            providerName: providerInfoData.providerName,
            providerLink: providerInfoData.providerLink,
            providerTitle: providerInfoData.providerTitle
        }
    }
    var latestTcData = null,
        PromotionBannerHTML = PromotionBannerHTMLTemplate;
    window.CookieControl.Dialog = function(cookieconsent, mode, title, text, acceptText, declineText, responseMode, ignoreSuppress, demomode, consentLevel, userLanguage, cookieIntroText, cookieIntroTypeNecessary, cookieIntroTypePreference, cookieIntroTypeStatistics, cookieIntroTypeAdvertising, cookieIntroTypeUnclassified, multiAcceptText, loiAllowAllText, loiAllowSelectionText, buttonMode, hideDetailsText, showDetailsText, customizeText, doNotSellOrShareText, promotionBannerEnabled) {
        var that = this;
        this.name = "CybotCookiebotDialog", this.mode = mode, this.template = "slidedown", this.theme = "dark", this.promotionBannerEnabled = promotionBannerEnabled, this.canShowPromotionBanner = !1, this.title = title, this.text = text, this.logo = null, this.logoAltText = "", this.logoCookiebotAltText = "", this.externalLinkIcon = "", this.externalLinkIconAltText = "", this.acceptText = acceptText, this.declineText = declineText, this.customizeText = customizeText, this.cookieIntroText = cookieIntroText, this.doNotSellOrShareText = doNotSellOrShareText, this.cookieIntroTypeNecessary = cookieIntroTypeNecessary, this.cookieIntroTypePreference = cookieIntroTypePreference, this.cookieIntroTypeStatistics = cookieIntroTypeStatistics, this.cookieIntroTypeAdvertising = cookieIntroTypeAdvertising, this.cookieIntroTypeUnclassified = cookieIntroTypeUnclassified, this.loiAllowAllText = "", this.loiAllowSelectionText = "", this.buttonMode = "ok", this.buttonsDirection = "row", this.ooiPersonalInformation = "", this.cookieHeaderTypeNecessary = "", this.cookieHeaderTypePreference = "", this.cookieHeaderTypeStatistics = "", this.cookieHeaderTypeAdvertising = "", this.cookieHeaderTypeUnclassified = "", this.cookieTableHeaderName = "", this.cookieTableHeaderProvider = "", this.cookieTableHeaderPurpose = "", this.cookieTableHeaderType = "", this.cookieTableHeaderExpiry = "", this.showDetailsText = showDetailsText, this.hideDetailsText = hideDetailsText, this.multiAcceptText = multiAcceptText, this.mandatoryText = "", this.noCookiesTypeText = "", this.aboutCookiesText = "", this.consentTitle = "", this.consentSelection = "", this.details = "", this.about = "", this.domainConsent = "", this.domainConsentList = "", this.cookiesOverviewText = "", this.lastUpdatedText = "", this.lastUpdatedDate = null, this.privacyPolicyText = "", this.providerLinkText = "", this.opensInNewWindowText = "", this.bulkconsentDomainsString = "", this.cookieTableNecessary = "", this.cookieTablePreference = "", this.cookieTableStatistics = "", this.cookieTableAdvertising = "", this.cookieTableUnclassified = "", this.googleCookieDescription = "", this.privacyPolicies = [], this.responseMode = responseMode, this.consentLevel = consentLevel, this.impliedConsentOnScroll = !0, this.impliedConsentOnRefresh = !1, this.userLanguage = userLanguage, this.userCountry = "", this.sliderPos = 0, this.faderPos = 100, this.detailsPos = 0, this.flashCount = 0, this.DOM = null, this.DOMid = "CybotCookiebotDialog", this.visible = !1, this.DOMoverlay = null, this.textDirection = "ltr", this.bodyOverflow = null, this.cookieconsent = cookieconsent, this.cookieconsent.dialog = this, this.demomode = demomode, this.viewport = new window.CookieControl.Viewport, this.initHeight = "", this.initWidth = "", this.pageHasLoaded = !1, this.scalefactor = 1, this.isScrolling = !1, this.isInternalAlias = !1, this.showLogo = !0, this.autoHideLogoWidth = 600, this.windowInitScrolltop = 0, this.bodyPaddingTopInit = 0, this.bannerFirstFocusElement = null, this.bannerLastFocusElement = null, this.bannerOpenFocusElement = null, this.templates = {
            top: "",
            bottom: "",
            slidedown: "",
            pushdown: "",
            slideup: "",
            overlay: "",
            popup: "",
            "top-v2": "",
            "bottom-v2": "",
            "slidedown-v2": "",
            "pushdown-v2": "",
            "slideup-v2": "",
            "overlay-v2": "",
            "popup-v2": "",
            custom: ""
        }, this.themes = {
            white: "",
            dark: "",
            customcolor: ""
        }, this.styles = {
            top: "",
            bottom: "",
            slidedown: "",
            pushdown: "",
            slideup: "",
            overlay: "",
            popup: "",
            custom: ""
        }, this.modes = {
            top_white: "",
            top_dark: "",
            top_customcolor: "",
            bottom_white: "",
            bottom_dark: "",
            bottom_customcolor: "",
            slidedown_white: "",
            slidedown_dark: "",
            slidedown_customcolor: "",
            pushdown_white: "",
            pushdown_dark: "",
            pushdown_customcolor: "",
            slideup_white: "",
            slideup_dark: "",
            slideup_customcolor: "",
            overlay_white: "",
            overlay_dark: "",
            overlay_customcolor: "",
            popup_white: "",
            popup_dark: "",
            popup_customcolor: "",
            custom_white: "",
            custom_dark: "",
            custom_customcolor: ""
        }, this.customColors = {
            background: "",
            text: "",
            acceptbutton: "",
            selectionbutton: "",
            declinebutton: "",
            buttontext: "",
            tab: "",
            border: "",
            logo: ""
        }, this.customImages = {
            showdetails: "",
            hidedetails: "",
            cbCheckedNofocus: "",
            cbCheckedFocus: "",
            cbCheckedDisabled: "",
            cbNotCheckedFocus: "",
            cbNotCheckedNoFocus: ""
        }, this.customTemplateDef = {
            HTML: "",
            CSS: "",
            Script: "",
            FunctionShowName: "",
            FunctionHideName: ""
        }, this.prechecked = {
            preferences: !0,
            statistics: !0,
            marketing: !0
        }, this.optionaloptinSettings = {
            displayConsentBanner: !1
        }, this.IABSettings = {
            purposes: [],
            specialpurposes: [],
            features: [],
            specialfeatures: [],
            stacks: [],
            vendors: [],
            version: "",
            lastupdated: ""
        }, this.IABGVL = null, this.IABSortedVendorList = null, this.IABResourceStrings = {
            tabHeader: "",
            deselectAll: "",
            feature: "",
            tabTitle: "",
            generalIntro: "",
            policyURL: "",
            purpose: "",
            purposeIntro: "",
            purposeLegitimateInterest: "",
            selectAll: "",
            thirdPartyVendors: "",
            vendorIntro: "",
            legitimateInterestHeader: "",
            legitimateInterestIntro: "",
            legitimateInterestPurposeIntro: "",
            legitimateInterestObjection: "",
            legitimateInterestVendorObjection: "",
            specialPurpose: "",
            specialFeature: "",
            purposeIntroShort: "",
            purposeIntroLong: "",
            purposeIntroPartly: "",
            globalConsent: "",
            withdrawConsent: "",
            preferencesIntro: "",
            consent: "",
            expand: "",
            collapse: "",
            saveAndExit: "",
            partners: "",
            partnersIntro: "",
            vendorsCan: "",
            settings: "",
            consentHandlingHeader: "",
            consentExpiry: "",
            trackingType: "",
            cookiesAndOther: "",
            cookiesOnly: "",
            showDetails: "",
            name: "",
            domain: "",
            expiry: "",
            expiryRefreshText: "",
            type: "",
            errorText: "",
            loadingText: "",
            trackingTypeCookie: "",
            trackingTypeWeb: "",
            trackingTypeApp: "",
            year: "",
            years: "",
            day: "",
            days: "",
            hour: "",
            hours: "",
            minute: "",
            minutes: "",
            second: "",
            seconds: "",
            session: "",
            googleIntro: "",
            googleHeader: ""
        }, this.googlePartners = {}, this.googlePartnersSortedIds = [], this.bannerCloseButtonEnabled = !1, this.bannerButtonDesign = null, this.bannerCloseText = "", null != loiAllowAllText && (this.loiAllowAllText = loiAllowAllText), null != loiAllowSelectionText && (this.loiAllowSelectionText = loiAllowSelectionText), null != buttonMode && (this.buttonMode = buttonMode)
    }, window.CookieControl.Dialog.prototype.getCookieTableSection = function(domId, cookieList, expiryLabel, typeLabel) {
        var cookieObjectList = [],
            cookieGroupCounters = {},
            group, cookieInfoWrapper;

        function getCookieGroupCounter(provider, count) {
            return cookieGroupCounters[provider] ? cookieGroupCounters[provider] += count : cookieGroupCounters[provider] = count, cookieGroupCounters[provider]
        }
        for (var i = 0; i < cookieList.length; i++) {
            var cookieObject = getCookieObjectFromArray(this, cookieList[i]);
            cookieObjectList.push(cookieObject)
        }

        function comparator(a, b) {
            return a.providerName < b.providerName ? -1 : a.providerName > b.providerName ? 1 : 0
        }
        cookieObjectList = cookieObjectList.sort(comparator);
        var container = document.createElement("ul");
        container.className = "CybotCookiebotDialogDetailBodyContentCookieTabContent", container.style.listStyleType = "none";
        var providerName = null,
            providerLink = null,
            providerLinkIcon = null,
            hasPostedDescription = !1;
        if (0 === cookieObjectList.length) {
            var categoryEmptyMessage = document.createElement("p");
            categoryEmptyMessage.className = "CybotCookiebotDialogDetailBodyEmptyCategoryMessage", categoryEmptyMessage.innerHTML = this.noCookiesTypeText, container.appendChild(categoryEmptyMessage)
        }
        for (var j = 0; j < cookieObjectList.length; j++) {
            var cookie = cookieObjectList[j],
                cookieName = cookie.name,
                cookieDomain = cookie.domain,
                cookiePurpose = cookie.purpose,
                cookieProvider = cookie.providerName,
                cookieProviderLink = cookie.providerLink,
                cookieLanguageCode = cookie.languageCode,
                cookieExpiry = "<b>" + expiryLabel + "</b>: " + cookie.expiry,
                cookieType = "<b>" + typeLabel + "</b>: " + cookie.cookieType,
                cookieProviderCounter, prevCookieProvider = "";
            if (j > 0 && (prevCookieProvider = cookieObjectList[j - 1].providerName), cookieProvider !== prevCookieProvider && (group = document.createElement("li"), group.className = "CybotCookiebotDialogDetailBodyContentCookieGroup", container.appendChild(group), providerName = document.createElement("a"), providerName.classList.add("CybotCookiebotDialogDetailBodyContentCookieProvider"), providerName.setAttribute("role", "button"), providerName.setAttribute("aria-expanded", "false"), providerName.classList.add("CybotCookiebotDialogCollapsed"), providerName.innerHTML = " ", providerName.href = "#", group.appendChild(providerName), cookieProviderCounter = document.createElement("div"), cookieProviderCounter.classList.add("CybotCookiebotDialogDetailBodyContentCookieInfoCount"), cookieProviderCounter.classList.add("CybotCookiebotDialogDetailBulkConsentCount"), providerName.appendChild(cookieProviderCounter), cookieProviderLink ? (providerLink = document.createElement("a"), providerLink.className = "CybotCookiebotDialogDetailBodyContentCookieLink", providerLink.innerHTML = this.providerLinkText, providerLink.target = "_blank", providerLink.rel = "noopener noreferrer nofollow", providerLink.ariaLabel = this.providerLinkText + " - " + this.opensInNewWindowText, providerLink.href = cookieDomain.split("<br/>")[0], providerLinkIcon = document.createElement("img"), providerLinkIcon.className = "CybotExternalLinkArrow", providerLinkIcon.src = this.externalLinkIcon, providerLinkIcon.alt = "", providerLink.appendChild(providerLinkIcon), group.appendChild(providerLink)) : providerLink = null, cookieInfoWrapper = document.createElement("div"), cookieInfoWrapper.classList.add("CybotCookiebotDialogDetailBodyContentCookieInfoWrapper"), cookieInfoWrapper.classList.add("CybotCookiebotDialogHide"), group.appendChild(cookieInfoWrapper)), "Google" === cookieProvider && !hasPostedDescription) {
                hasPostedDescription = !0;
                var text = document.createElement("p"),
                    googleDescription = this.googleCookieDescription && this.googleCookieDescription.length ? this.googleCookieDescription : "Some of the data collected by this provider is for the purposes of personalization and measuring advertising effectiveness.";
                text.classList.add("CybotCookiebotDialogDetailBodyContentCookieProviderDescription"), text.innerText = googleDescription, cookieInfoWrapper.appendChild(text)
            }
            var domainCount = cookieDomain.split("<br/>").length;
            domainCount > 1 && (cookieName += "&nbsp;[x" + domainCount + "]");
            var cookieInfo = document.createElement("div");
            cookieInfo.classList.add("CybotCookiebotDialogDetailBodyContentCookieInfo"), cookieInfoWrapper && cookieInfoWrapper.appendChild(cookieInfo);
            var cookieProviderName = document.createElement("strong");
            cookieProviderName.className = "CybotCookiebotDialogDetailBodyContentCookieInfoTitle", cookieProviderName.innerHTML = cookieName, cookieInfo.appendChild(cookieProviderName);
            var cookieProviderDescription = document.createElement("span");
            cookieProviderDescription.className = "CybotCookiebotDialogDetailBodyContentCookieInfoDescription", cookieProviderDescription.innerHTML = cookiePurpose, cookieLanguageCode && cookieLanguageCode !== this.userLanguage && (cookieProviderDescription.lang = cookieLanguageCode), cookieInfo.appendChild(cookieProviderDescription);
            var cookieFooter = document.createElement("div");
            cookieFooter.className = "CybotCookiebotDialogDetailBodyContentCookieInfoFooter", cookieInfo.appendChild(cookieFooter);
            var cookieProviderExpiry = document.createElement("span");
            cookieProviderExpiry.className = "CybotCookiebotDialogDetailBodyContentCookieInfoFooterContent", cookieProviderExpiry.innerHTML = cookieExpiry, cookieFooter.appendChild(cookieProviderExpiry);
            var cookieProviderType = document.createElement("span");
            if (cookieProviderType.className = "CybotCookiebotDialogDetailBodyContentCookieInfoFooterContent", cookieProviderType.innerHTML = cookieType, cookieFooter.appendChild(cookieProviderType), providerName) {
                var cookieDomains = cookieObjectList[j].domains.split("<br/>");
                if (cookieDomains.length > 1) {
                    for (var newList = "", newListHTML = document.createElement("div"), existingCompanies = [], n = 0; n < cookieDomains.length; n++) {
                        var companyName;
                        cookieObjectList[j].providerName && (companyName = cookieObjectList[j].providerName), -1 === existingCompanies.indexOf(companyName) && (existingCompanies.push(companyName), newList += companyName, n < cookieDomains.length - 1 && (newList += "<br/>"))
                    }
                    newListHTML.innerHTML = newList, providerName.replaceChild(newListHTML, providerName.firstChild), cookieProviderCounter.innerHTML = getCookieGroupCounter(cookieObjectList[j].providerName, domainCount)
                } else cookieObjectList[j].providerName && (providerName.firstChild.nodeValue = cookieObjectList[j].providerName, providerLink && (providerLink.href = cookieObjectList[j].providerLink, providerLink.title = cookieObjectList[j].providerTitle, providerLink.ariaLabel = cookieObjectList[j].providerTitle + " - " + this.opensInNewWindowText), cookieProviderCounter.innerHTML = getCookieGroupCounter(cookieObjectList[j].providerName, domainCount))
            }
        }
        return container.outerHTML
    }, window.CookieControl.Dialog.prototype.getCookieTableHTML = function(domId, cookieList, tableTemplateHTML, textDirection) {
        var cookieTableContainer = document.createElement("span");
        cookieTableContainer.innerHTML = tableTemplateHTML;
        for (var cookieTable = cookieTableContainer.firstChild, i = 0; i < cookieList.length; i++)
            for (var row = cookieTable.tBodies[0].insertRow(-1), j = 0; j <= 4; j++) {
                var newcell = row.insertCell(j);
                if (newcell.innerHTML = cookieList[i][j], 0 === j) {
                    var domaincount = cookieList[i][1].split("<br/>").length;
                    domaincount > 1 && (newcell.innerHTML += "&nbsp;[x" + domaincount + "]")
                } else if (1 === j) {
                    var cookieDomains = cookieList[i][j].split("<br/>");
                    if (cookieList[i].length > 7 && (cookieDomains = cookieList[i][7].split("<br/>")), cookieDomains.length > 1) {
                        for (var newList = "", existingCompanies = [], k = 0; k < cookieDomains.length; k++) {
                            var companyName = this.getDomainLabel(cookieDomains[k]); - 1 === existingCompanies.indexOf(companyName) && (existingCompanies.push(companyName), newList += companyName, k < cookieDomains.length - 1 && (newList += "<br/>"))
                        }
                        newcell.innerHTML = newList
                    } else cookieList[i].length > 7 ? newcell.innerHTML = this.getDomainLabel(cookieList[i][7]) : newcell.innerHTML = this.getDomainLabel(cookieList[i][j])
                }
                1 !== j && (newcell.title = cookieList[i][j].replace(/\<br\/\>/g, "\n"))
            }
        if (0 === cookieList.length) {
            for (; cookieTable.hasChildNodes();) cookieTable.removeChild(cookieTable.firstChild);
            var noentriesRow = cookieTable.insertRow(0),
                noentriesCell = noentriesRow.insertCell(0);
            noentriesCell.style.textAlignment = textDirection, noentriesCell.innerHTML = this.noCookiesTypeText, noentriesCell.className = "CybotCookiebotDialogDetailBodyContentCookieTypeTableEmpty"
        }
        return cookieTable.id = "CybotCookiebotDialogDetailTable" + domId, cookieTable.className = "CybotCookiebotDialogDetailBodyContentCookieTypeTable", cookieTable.outerHTML
    }, window.CookieControl.Dialog.prototype.initContentFader = function() {
        initContentFader(window, document, this)
    }, window.CookieControl.Dialog.prototype.getProviderInfo = function(providerName, providerLink) {
        return getProviderInfo(this, providerName, providerLink)
    }, window.CookieControl.Dialog.prototype.getDomainLabel = function(domainname) {
        var label = domainname;
        if (this.privacyPolicies.length > 0)
            for (var i = 0; i < this.privacyPolicies.length; i++)
                if (this.privacyPolicies[i][0] === domainname) {
                    var privacyPolicyName = this.privacyPolicies[i][1],
                        privacyPolicyLink = this.privacyPolicies[i][2],
                        labelTitle = this.privacyPolicyText.replace("{0}", privacyPolicyName).replace("'", "'");
                    label = '<a href="' + privacyPolicyLink + '"', label += ' target="_blank" rel="noopener noreferrer nofollow" title="' + labelTitle + '"', label += ">" + privacyPolicyName + "</a>";
                    break
                }
        return label
    }, window.CookieControl.Dialog.prototype.init = function() {
        if (hasFramework(this.cookieconsent) && window.__tcfapi("addEventListener", 2, ((tcData, success) => {
                success && (latestTcData = tcData)
            })), window.Cookiebot.handleCcpaOptinInFrontend && !window.Cookiebot.isRenewal && "optionaloptin" === this.responseMode && !this.optionaloptinSettings.displayConsentBanner) return navigator.globalPrivacyControl ? void window.Cookiebot.submitCustomConsent(!1, !1, !1, !0) : void window.Cookiebot.submitCustomConsent(!0, !0, !0, !0);
        !0 === navigator.globalPrivacyControl && (this.prechecked = {
            preferences: !1,
            statistics: !1,
            marketing: !1
        }), -1 !== this.mode.indexOf("v2") ? this.version = 2 : this.version = 1, "function" == typeof window.CookiebotCallback_OnDialogInit ? window.CookiebotCallback_OnDialogInit() : "function" == typeof window.CookieConsentCallback_OnDialogInit && window.CookieConsentCallback_OnDialogInit();
        var event = document.createEvent("Event"),
            dialogHTML;
        event.initEvent("CookiebotOnDialogInit", !0, !0), window.dispatchEvent(event), event = document.createEvent("Event"), event.initEvent("CookieConsentOnDialogInit", !0, !0), window.dispatchEvent(event), this.mode.indexOf("_") > 0 && (this.template = this.mode.split("_")[0], this.theme = this.mode.split("_")[1]), this.canShowPromotionBanner = canShowPromotionBanner(window, window.CookieConsent, this), this.clearDOM(), this.demomode ? this.loadDemoTemplates() : this.loadTemplates(), dialogHTML = "custom" === this.template ? this.customTemplateDef.HTML : this.templates[this.template];
        var showDoNotSellButton = "optionaloptin" === this.responseMode,
            tempParent = document.createElement("div");
        tempParent.innerHTML = dialogHTML.replace(/\[#TITLE#]/g, this.title).replace(/\[#TEXT#]/g, this.text.replace(/\n/g, "")).replace(/\[#ACCEPT#]/g, this.acceptText).replace(/\[#DECLINE#]/g, showDoNotSellButton ? this.doNotSellOrShareText : this.declineText).replace(/\[#CUSTOMIZE#]/g, this.customizeText).replace(/\[#DETAILS#\]/g, this.showDetailsText).replace(/\[#DETAILSHIDE#\]/g, this.hideDetailsText).replace(/\[#LOGO#]/g, this.logo || "data:,").replace(/\[#LOGOALT#]/g, this.logoAltText).replace(/\[#LOGOARIALABEL#]/g, this.logoCookiebotAltText + " - " + this.opensInNewWindowText).replace(/\[#BANNER_CLOSE#\]/g, this.bannerCloseText), "" !== this.bulkconsentDomainsString ? 2 === this.version ? (tempParent.innerHTML = tempParent.innerHTML.replace(/\[#BULK_CONSENT_DOMAINS#]/g, this.domainlist), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#BULK_CONSENT_DOMAINS_COUNT#]/g, this.domainlistCount), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#BULK_CONSENT_TITLE#]/g, this.bulkconsentDomainsString), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIESGENERALINTRO#]/g, this.cookieIntroText.replace(/\n/g, "") + "<br><br>").replace(/\[#COOKIETYPEINTRO_NECESSARY#]/g, this.cookieIntroTypeNecessary.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_PREFERENCE#]/g, this.cookieIntroTypePreference.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_STATISTICS#]/g, this.cookieIntroTypeStatistics.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_ADVERTISING#]/g, this.cookieIntroTypeAdvertising.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_UNCLASSIFIED#]/g, this.cookieIntroTypeUnclassified.replace(/\n/g, ""))) : tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIESGENERALINTRO#]/g, this.cookieIntroText.replace(/\n/g, "") + "<br><br>" + this.bulkconsentDomainsString + "<br><br>").replace(/\[#COOKIETYPEINTRO_NECESSARY#]/g, this.cookieIntroTypeNecessary.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_PREFERENCE#]/g, this.cookieIntroTypePreference.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_STATISTICS#]/g, this.cookieIntroTypeStatistics.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_ADVERTISING#]/g, this.cookieIntroTypeAdvertising.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_UNCLASSIFIED#]/g, this.cookieIntroTypeUnclassified.replace(/\n/g, "")) : tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIESGENERALINTRO#]/g, this.cookieIntroText.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_NECESSARY#]/g, this.cookieIntroTypeNecessary.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_PREFERENCE#]/g, this.cookieIntroTypePreference.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_STATISTICS#]/g, this.cookieIntroTypeStatistics.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_ADVERTISING#]/g, this.cookieIntroTypeAdvertising.replace(/\n/g, "")).replace(/\[#COOKIETYPEINTRO_UNCLASSIFIED#]/g, this.cookieIntroTypeUnclassified.replace(/\n/g, ""));
        var lastUpdatedTextLabel = this.lastUpdatedText;
        if (void 0 !== this.userCulture && null != this.userCulture && void 0 !== this.lastUpdatedDate && null != this.lastUpdatedDate) {
            var options = {
                    timeZone: "UTC",
                    dateStyle: "short"
                },
                localizedDateLabel = "",
                updateDateObject = new Date(this.lastUpdatedDate);
            try {
                localizedDateLabel = updateDateObject.toLocaleDateString(this.userCulture, options)
            } catch (e) {
                localizedDateLabel = updateDateObject.toLocaleDateString("en-GB", options)
            }
            lastUpdatedTextLabel = lastUpdatedTextLabel.replace(/\{0\}/g, localizedDateLabel)
        }
        var navigation = tempParent.querySelector("#CybotCookiebotDialogNavDeclaration");
        if (navigation && navigation.getElementsByTagName("h1").length)
            for (var navigationItems = tempParent.getElementsByClassName("CybotCookiebotDialogNavItemLink"), i = 0; i < navigationItems.length; i++) {
                var element = navigationItems[i];
                element.innerHTML = element.innerText
            }
        if (2 === this.version) {
            for (var h2Elements = tempParent.querySelectorAll("h2"), i = 0; i < h2Elements.length; i++) {
                var h2 = h2Elements[i],
                    div = document.createElement("div"),
                    attributes = h2.attributes;
                div.innerHTML = h2.innerHTML;
                for (var j = 0; j < attributes.length; j++) div.setAttribute(attributes[j].name, attributes[j].value);
                div.className = "CybotCookiebotDialogBodyContentHeading", div.setAttribute("role", "heading"), div.setAttribute("aria-level", "1"), h2.parentNode.replaceChild(div, h2)
            }

            function createSROnlyH1Element(name, parentElement) {
                if (parentElement && !parentElement.parentNode.querySelector(".CybotCookiebotDialogSROnly")) {
                    var div = document.createElement("div");
                    div.classList.add("CybotCookiebotDialogSROnly"), div.innerHTML = name, div.setAttribute("role", "heading"), div.setAttribute("aria-level", "1"), parentElement.insertBefore(div, parentElement.firstChild)
                }
            }
            var detailsTab = tempParent.querySelector("#CybotCookiebotDialogDetailBody"),
                aboutTabTab = tempParent.querySelector("#CybotCookiebotDialogDetailBodyContentTextAbout");
            createSROnlyH1Element(this.details, detailsTab), createSROnlyH1Element(this.about, aboutTabTab);
            var footer = tempParent.querySelector("#CybotCookiebotDialogFooter");
            footer && !footer.classList.contains("CybotCookiebotScrollContainer") && (footer.classList.add("CybotCookiebotScrollContainer"), footer.innerHTML = '<div class="CybotCookiebotScrollArea">' + footer.innerHTML + '<div class="CybotCookiebotScrollbarContainer"></div></div>')
        }
        if (tempParent.innerHTML = tempParent.innerHTML.replace(/\[#POWEREDBYURL#\]/g, poweredByUrls[this.userLanguage] || poweredByUrls.en).replace(/\[#ABOUTCOOKIES#\]/g, this.aboutCookiesText).replace(/\[#CONSENT#\]/g, this.consentTitle).replace(/\[#DETAILSTITLE#\]/g, this.details).replace(/\[#ABOUT#\]/g, this.about).replace(/\[#DOMAIN_CONSENT#\]/g, this.about).replace(/\[#CONSENT_SELECTION#\]/g, this.consentSelection).replace(/\[#BULK_CONSENT_HEADER#\]/g, this.domainConsent).replace(/\[#BULK_CONSENT_LIST#\]/g, this.domainConsentList).replace(/\[#COOKIESOVERVIEW#\]/g, this.cookiesOverviewText).replace(/\[#LASTUPDATED#\]/g, lastUpdatedTextLabel).replace(/\[#COOKIETYPE_NECESSARY#\]/g, this.cookieHeaderTypeNecessary.replace("{0}", this.cookieTableNecessaryCount)).replace(/\[#COOKIETYPE_NECESSARY_TITLE#\]/g, this.cookieHeaderTypeNecessary.replace("({0})", "")).replace(/\[#COOKIETYPE_NECESSARY_COUNT#\]/g, this.cookieTableNecessaryCount).replace(/\[#COOKIETYPE_PREFERENCE#\]/g, this.cookieHeaderTypePreference.replace("{0}", this.cookieTablePreferenceCount)).replace(/\[#COOKIETYPE_PREFERENCE_TITLE#\]/g, this.cookieHeaderTypePreference.replace("({0})", "")).replace(/\[#COOKIETYPE_PREFERENCE_COUNT#\]/g, this.cookieTablePreferenceCount).replace(/\[#COOKIETYPE_STATISTICS#\]/g, this.cookieHeaderTypeStatistics.replace("{0}", this.cookieTableStatisticsCount)).replace(/\[#COOKIETYPE_STATISTICS_TITLE#\]/g, this.cookieHeaderTypeStatistics.replace("({0})", "")).replace(/\[#COOKIETYPE_STATISTICS_COUNT#\]/g, this.cookieTableStatisticsCount).replace(/\[#COOKIETYPE_ADVERTISING#\]/g, this.cookieHeaderTypeAdvertising.replace("{0}", this.cookieTableAdvertisingCount)).replace(/\[#COOKIETYPE_ADVERTISING_TITLE#\]/g, this.cookieHeaderTypeAdvertising.replace("({0})", "")).replace(/\[#COOKIETYPE_ADVERTISING_COUNT#\]/g, this.cookieTableAdvertisingCount).replace(/\[#COOKIETYPE_UNCLASSIFIED#\]/g, this.cookieHeaderTypeUnclassified.replace("{0}", this.cookieTableUnclassifiedCount)).replace(/\[#COOKIETYPE_UNCLASSIFIED_TITLE#\]/g, this.cookieHeaderTypeUnclassified.replace("({0})", "")).replace(/\[#COOKIETYPE_UNCLASSIFIED_COUNT#\]/g, this.cookieTableUnclassifiedCount), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETYPE_NECESSARY_RAW#\]/g, this.cookieHeaderTypeNecessary.replace(" ({0})", "")).replace(/\[#COOKIETYPE_PREFERENCE_RAW#\]/g, this.cookieHeaderTypePreference.replace(" ({0})", "")).replace(/\[#COOKIETYPE_STATISTICS_RAW#\]/g, this.cookieHeaderTypeStatistics.replace(" ({0})", "")).replace(/\[#COOKIETYPE_ADVERTISING_RAW#\]/g, this.cookieHeaderTypeAdvertising.replace(" ({0})", "")).replace(/\[#COOKIETYPE_UNCLASSIFIED_RAW#\]/g, this.cookieHeaderTypeUnclassified.replace(" ({0})", "")), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#ACCEPTOK#\]/g, this.multiAcceptText), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#MULTIACCEPT#\]/g, this.multiAcceptText), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#LANGUAGE#\]/g, this.userLanguage), "" !== this.doNotSellOrShareText && (tempParent.innerHTML = tempParent.innerHTML.replace(/\[#OOI_PERSONAL_INFORMATION#\]/g, this.doNotSellOrShareText)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#LEVELOPTIN_ALLOWALL#\]/g, this.loiAllowAllText), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#LEVELOPTIN_ALLOW_SELECTION#\]/g, this.loiAllowSelectionText), hasFramework(this.cookieconsent)) {
            var iabContent = getIABData(window.CookieConsent, window.CookieConsentIABCMP, window.CookiebotDialog);
            tempParent.innerHTML = tempParent.innerHTML.replace("%VENDOR_COUNT%", iabContent.sectionVendors.count.toString());
            var currentContent = tempParent.innerHTML;
            currentContent = currentContent.replace(/\[#IABV2SETTINGS#\]/g, iabContent.tabHeader).replace(/\[#IABV2_TITLE#\]/g, iabContent.sectionIntro.title).replace(/\[#IABV2_BODY_INTRO#\]/g, iabContent.sectionIntro.text).replace(/\[#IABV2_BODY_LEGITIMATE_INTEREST_INTRO#\]/g, iabContent.sectionIntro.legitimateInterestText).replace(/\[#IABV2_BODY_PREFERENCE_INTRO#\]/g, iabContent.sectionIntro.preferenceText).replace(/\[#IABV2_LABEL_PURPOSES#\]/g, iabContent.sectionPurposes.title).replace(/\[#IABV2_LABEL_PURPOSES_ARIA_LABEL#\]/g, iabContent.sectionPurposes.sectionAriaLabel).replace(/\[#IABV2_BODY_PURPOSES_INTRO#\]/g, iabContent.sectionPurposes.text).replace(/\[#IABV2_BODY_PURPOSES#\]/g, iabContent.sectionPurposes.content).replace(/\[#IABV2_LABEL_FEATURES#\]/g, iabContent.sectionFeatures.title).replace(/\[#IABV2_LABEL_FEATURES_ARIA_LABEL#\]/g, iabContent.sectionFeatures.sectionAriaLabel).replace(/\[#IABV2_BODY_FEATURES_INTRO#\]/g, iabContent.sectionFeatures.text).replace(/\[#IABV2_BODY_FEATURES#\]/g, iabContent.sectionFeatures.content).replace(/\[#IABV2_LABEL_PARTNERS#\]/g, iabContent.sectionVendors.title).replace(/\[#IABV2_LABEL_PARTNERS_ARIA_LABEL#\]/g, iabContent.sectionVendors.sectionAriaLabel).replace(/\[#IABV2_BODY_PARTNERS_INTRO#\]/g, iabContent.sectionVendors.text).replace(/\[#IABV2_BODY_PARTNERS#\]/g, iabContent.sectionVendors.content), tempParent.innerHTML = currentContent
        }
        var RTLlanguages = ["ar", "he", "fa", "az", "ur", "pa", "ps", "ug", "yi"],
            isCurrentLanguageRtlLanguage = RTLlanguages.indexOf(this.userLanguage.toLowerCase()) >= 0,
            textAlignment = isCurrentLanguageRtlLanguage ? "right" : "left";
        if (this.textDirection = isCurrentLanguageRtlLanguage ? "rtl" : "ltr", tempParent.innerHTML = tempParent.innerHTML.replace(/\[#TEXTDIRECTION#\]/g, this.textDirection), 1 === this.version) {
            var HTMLTabelTemplate = '<table><thead><tr><th scope="col">' + this.cookieTableHeaderName + '</th><th scope="col">';
            HTMLTabelTemplate += this.cookieTableHeaderProvider + '</th><th scope="col">', HTMLTabelTemplate += this.cookieTableHeaderPurpose + '</th><th scope="col">', HTMLTabelTemplate += this.cookieTableHeaderExpiry + '</th><th scope="col">', HTMLTabelTemplate += this.cookieTableHeaderType + "</th></tr></thead><tbody></tbody></table>", tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_NECESSARY#]/g, this.getCookieTableHTML("Necessary", this.cookieTableNecessary, HTMLTabelTemplate, textAlignment)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_PREFERENCE#]/g, this.getCookieTableHTML("Preference", this.cookieTablePreference, HTMLTabelTemplate, textAlignment)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_STATISTICS#]/g, this.getCookieTableHTML("Statistics", this.cookieTableStatistics, HTMLTabelTemplate, textAlignment)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_ADVERTISING#]/g, this.getCookieTableHTML("Advertising", this.cookieTableAdvertising, HTMLTabelTemplate, textAlignment)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_UNCLASSIFIED#]/g, this.getCookieTableHTML("Unclassified", this.cookieTableUnclassified, HTMLTabelTemplate, textAlignment))
        } else {
            tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_NECESSARY#]/g, this.getCookieTableSection("Necessary", this.cookieTableNecessary, this.cookieTableHeaderExpiry, this.cookieTableHeaderType, textAlignment)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_PREFERENCE#]/g, this.getCookieTableSection("Preference", this.cookieTablePreference, this.cookieTableHeaderExpiry, this.cookieTableHeaderType, textAlignment)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_STATISTICS#]/g, this.getCookieTableSection("Statistics", this.cookieTableStatistics, this.cookieTableHeaderExpiry, this.cookieTableHeaderType, textAlignment)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_ADVERTISING#]/g, this.getCookieTableSection("Advertising", this.cookieTableAdvertising, this.cookieTableHeaderExpiry, this.cookieTableHeaderType, textAlignment)), tempParent.innerHTML = tempParent.innerHTML.replace(/\[#COOKIETABLE_UNCLASSIFIED#]/g, this.getCookieTableSection("Unclassified", this.cookieTableUnclassified, this.cookieTableHeaderExpiry, this.cookieTableHeaderType, textAlignment));
            var promotionBannerData = getPromotionBannerData(window);
            PromotionBannerHTML = PromotionBannerHTML.replace(/\[#PROMOTIONBANNER_TITLE#\]/g, this.ucDataShieldPromotionBannerTitle).replace(/\[#PROMOTIONBANNER_BODY#\]/g, this.ucDataShieldPromotionBannerBody).replace(/\[#PROMOTIONBANNER_CTA#\]/g, this.ucDataShieldPromotionBannerCTA).replace(/\[#PROMOTIONBANNER_URL#\]/g, promotionBannerData.url).replace(/\[#PROMOTIONBANNER_ICON#\]/g, promotionBannerData.icon).replace(/\[#PROMOTIONBANNER_ARIA_LABEL#\]/g, this.ucDataShieldPromotionBannerCTA + " - " + this.opensInNewWindowText)
        }
        if (!this.canShowPromotionBanner || -1 === this.template.indexOf("overlay") && -1 === this.template.indexOf("popup")) this.DOM = tempParent.firstChild;
        else {
            var wrapper = document.createElement("div");
            wrapper.id = "CybotCookiebotDialogWrapper", wrapper.innerHTML = PromotionBannerHTML + tempParent.innerHTML, this.DOM = wrapper.lastChild
        }
        if (!this.demomode && !this.cookieconsent.hasResponse)
            if ("implied" === this.consentLevel && void 0 === window.CookieDeclaration)
                if ("-2" === this.cookieconsent.consentID) {
                    var impliedReferer = window.location.protocol + "//" + window.location.hostname;
                    "optout" === this.responseMode && !0 === navigator.globalPrivacyControl ? (window.CookieConsent.submitCustomConsent(!1, !1, !1, !0), this.hide()) : this.submitConsent(!0, impliedReferer)
                } else {
                    var c = this.cookieconsent.getCookie(this.cookieconsent.name);
                    if (void 0 === c && this.impliedConsentOnRefresh)
                        if (this.cookieconsent.pathlist.length > 0)
                            for (var f = 0; f < this.cookieconsent.pathlist.length; f++) this.cookieconsent.setCookie("-2", null, this.cookieconsent.pathlist[f]);
                        else this.cookieconsent.setCookie("-2", null, "/");
                    this.impliedConsentOnScroll && this.setOnscrollEvent(), this.show()
                }
        else this.show()
    }, window.CookieControl.Dialog.prototype.detachOnscrollEvent = function() {
        this.isScrolling = !1, this.pageHasLoaded = !1;
        try {
            window.removeEventListener("scroll", this.onscrollfunction, !1)
        } catch (ex) {}
    }, window.CookieControl.Dialog.prototype.setOnscrollEvent = function() {
        window.CookieDialogInitScrollPosition = null, window.addEventListener("scroll", this.onscrollfunction, !1)
    }, window.CookieControl.Dialog.prototype.onscrollfunction = function(e) {
        if ("object" == typeof window.CookieConsentDialog)
            if (window.CookieConsentDialog.isScrolling) {
                e = e || window.event;
                var currentScrollPosition = window.pageYOffset;
                currentScrollPosition !== window.CookieConsentDialog.windowInitScrolltop && window.scrollTo(0, window.CookieConsentDialog.windowInitScrolltop), window.CookieConsentDialog.isScrolling = !1, e.preventDefault && e.preventDefault(), e.returnValue = !1
            } else if (window.CookieConsentDialog.pageHasLoaded && ("complete" === document.readyState || "interactive" === document.readyState)) {
            var currentCookiebotInitScrollPosition = window.pageYOffset;
            if (null == window.CookieDialogInitScrollPosition && (window.CookieDialogInitScrollPosition = currentCookiebotInitScrollPosition), "object" == typeof window.CookieConsent && !window.CookieConsent.hasResponse && window.CookieConsentDialog && !this.demomode && null != window.CookieDialogInitScrollPosition && Math.abs(currentCookiebotInitScrollPosition - window.CookieDialogInitScrollPosition) >= 150) {
                window.CookieDialogInitScrollPosition = null;
                var impliedReferer = window.location.protocol + "//" + window.location.hostname;
                "optout" === window.CookieConsent.responseMode && !0 === navigator.globalPrivacyControl ? (window.CookieConsent.submitCustomConsent(!1, !1, !1, !0), window.CookieConsentDialog.hide()) : window.CookieConsentDialog.submitConsent(!0, impliedReferer)
            }
        }
    }, window.CookieControl.Dialog.prototype.onKeydownfunction = function(e) {
        if ("object" == typeof window.CookieConsentDialog) {
            var isTabPressed = "Tab" === e.key || 9 === e.keyCode;
            if (!isTabPressed) return;
            if (e.shiftKey) window.CookieConsentDialog.bannerLastFocusElement && document.activeElement === window.CookieConsentDialog.bannerFirstFocusElement && (window.CookieConsentDialog.bannerLastFocusElement.focus(), e.preventDefault());
            else {
                var isLastTabIndex = window.CookieConsentDialog.bannerFirstFocusElement && document.activeElement === window.CookieConsentDialog.bannerLastFocusElement;
                ("CybotCookiebotDialog" === document.activeElement.id || isLastTabIndex) && (window.CookieConsentDialog.bannerFirstFocusElement.focus(), isLastTabIndex && e.preventDefault())
            }
        }
    }, window.CookieControl.Dialog.prototype.show = function() {
        var bodyObj = document.getElementsByTagName("body")[0],
            that = this;
        void 0 !== bodyObj ? that.displaydialog() : setTimeout((function() {
            that.show()
        }), 10)
    }, window.CookieControl.Dialog.prototype.displaydialog = function() {
        this.windowInitScrolltop = window.pageYOffset, this.visible = !0;
        var that = this,
            bodyObj = document.getElementsByTagName("body")[0];
        if (this.DOM.style.display = "none", "undefined" !== this.DOM.id && "" !== this.DOM.id && null !== this.DOM.id ? this.DOMid = this.DOM.id : this.DOM.id = this.DOMid, this.DOM.setAttribute("name", this.DOMid), this.name = this.DOMid, this.clearDOM(), bodyObj.firstChild ? !this.canShowPromotionBanner || -1 === this.template.indexOf("overlay") && -1 === this.template.indexOf("popup") ? this.DOM = bodyObj.insertBefore(this.DOM, bodyObj.firstChild) : this.DOM = bodyObj.insertBefore(this.DOM.parentElement, bodyObj.firstChild).lastChild : this.DOM = bodyObj.appendChild(this.DOM), this.appendStyle(this.template), 2 === this.version) {
            var logo = document.getElementById("CybotCookiebotDialogPoweredbyCybot");
            logo.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 458 121"><path d="M83.8673 1.30835V46.7911C83.8673 50.2873 84.9356 52.1186 87.5732 52.1186C90.3443 52.1186 91.2124 49.9876 91.2124 46.7911V1.30835H102.864V46.0586C102.864 56.6469 97.9899 61.8744 87.4063 61.8744C76.8226 61.8744 72.3154 56.8133 72.3154 45.9587V1.30835H83.9006H83.8673Z"/><path d="M119.057 42.5959V46.7247C119.057 50.6536 120.025 52.4849 122.663 52.4849C125.301 52.4849 125.935 49.7879 125.935 46.9577C125.935 41.3307 124.867 39.6991 118.757 34.5715C112.013 28.8778 108.54 25.5149 108.54 16.6914C108.54 7.86784 111.378 0.30957 122.73 0.30957C134.782 0.30957 136.552 8.50047 136.552 15.3262V18.7557H125.668V15.193C125.668 11.5637 125.067 9.76573 122.797 9.76573C120.66 9.76573 119.992 11.597 119.992 14.96C119.992 18.556 120.66 20.3207 125.601 24.183C134.415 31.0754 137.553 34.9711 137.553 44.7935C137.553 54.6159 134.348 61.8412 122.463 61.8412C110.577 61.8412 107.772 54.9822 107.772 46.1253V42.5293H119.057V42.5959Z"/><path d="M166.466 34.638H154.113V50.9199H168.57L167.201 61.0087H142.595V1.30835H167.134V11.4637H154.147V24.5492H166.5V34.638H166.466Z"/><path d="M184.195 35.0708V61.042H172.71V1.30835H187.667C197.717 1.30835 202.658 5.70347 202.658 16.1585V18.3228C202.658 26.8466 199.252 29.3772 196.682 30.5758C200.421 32.3738 202.157 35.1041 202.157 43.4282C202.157 49.1885 202.057 57.9121 202.558 61.042H191.407C190.672 58.345 190.705 50.5536 190.705 42.9288C190.705 36.2029 189.938 35.0708 185.564 35.0708H184.195ZM184.228 26.0142H185.664C189.504 26.0142 191.073 24.8156 191.073 19.2551V16.3583C191.073 12.3627 190.271 10.365 186.031 10.365H184.228V26.0142Z"/><path d="M237.513 41.5304V44.7601C237.513 52.2851 236.111 61.9078 222.389 61.9078C212.239 61.9078 207.832 56.5137 207.832 45.526V16.2585C207.832 5.87002 213.04 0.409424 222.622 0.409424C235.276 0.409424 237.313 8.70021 237.313 16.5249V20.2873H225.727V15.193C225.727 11.8967 225.026 10.2318 222.622 10.2318C220.219 10.2318 219.484 11.7968 219.484 15.193V46.7912C219.484 49.9877 220.018 52.1519 222.622 52.1519C225.227 52.1519 225.861 50.3206 225.861 46.5248V41.5637H237.513V41.5304Z"/><path d="M266.326 34.638H253.973V50.9199H268.429L267.06 61.0087H242.454V1.30835H266.993V11.4637H254.006V24.5492H266.359V34.638H266.326Z"/><path d="M272.569 61.0087V1.30835H285.323C287.226 8.60025 293.236 35.6369 293.703 38.2673H293.97C293.336 30.3095 292.935 19.4549 292.935 11.1308V1.30835H303.619V61.042H290.765C289.53 55.3483 282.986 24.4493 282.585 22.5514H282.285C282.719 29.5769 283.086 41.4637 283.086 50.8533V61.042H272.603L272.569 61.0087Z"/><path d="M316.34 11.4637H307.626V1.30835H336.639V11.4637H327.858V61.042H316.373V11.4637H316.34Z"/><path d="M352.197 35.0708V61.042H340.712V1.30835H355.669C365.719 1.30835 370.66 5.70347 370.66 16.1585V18.3228C370.66 26.8466 367.254 29.3772 364.684 30.5758C368.423 32.3738 370.159 35.1041 370.159 43.4282C370.159 49.1885 370.059 57.9121 370.56 61.042H359.409C358.674 58.345 358.707 50.5536 358.707 42.9288C358.707 36.2029 357.939 35.0708 353.566 35.0708H352.197ZM352.23 26.0142H353.666C357.505 26.0142 359.075 24.8156 359.075 19.2551V16.3583C359.075 12.3627 358.273 10.365 354.033 10.365H352.23V26.0142Z"/><path d="M388.388 1.30835V61.042H376.903V1.30835H388.388Z"/><path d="M424.346 41.5304V44.7601C424.346 52.2851 422.944 61.9078 409.222 61.9078C399.072 61.9078 394.665 56.5137 394.665 45.526V16.2585C394.665 5.87002 399.873 0.409424 409.455 0.409424C422.109 0.409424 424.146 8.70021 424.146 16.5249V20.2873H412.56V15.193C412.56 11.8967 411.859 10.2318 409.455 10.2318C407.052 10.2318 406.317 11.7968 406.317 15.193V46.7912C406.317 49.9877 406.851 52.1519 409.455 52.1519C412.06 52.1519 412.694 50.3206 412.694 46.5248V41.5637H424.346V41.5304Z"/><path d="M439.504 42.5959V46.7247C439.504 50.6536 440.472 52.4849 443.109 52.4849C445.747 52.4849 446.381 49.7879 446.381 46.9577C446.381 41.3307 445.313 39.6991 439.203 34.5715C432.459 28.8778 428.987 25.5149 428.987 16.6914C428.987 7.86784 431.825 0.30957 443.176 0.30957C455.229 0.30957 456.998 8.50047 456.998 15.3262V18.7557H446.114V15.193C446.114 11.5637 445.513 9.76573 443.243 9.76573C441.106 9.76573 440.438 11.597 440.438 14.96C440.438 18.556 441.106 20.3207 446.047 24.183C454.861 31.0754 458 34.9711 458 44.7935C458 54.6159 454.795 61.8412 442.909 61.8412C431.023 61.8412 428.219 54.9822 428.219 46.1253V42.5293H439.504V42.5959Z"/><path d="M0 1.27515V31.5415C0 48.223 13.6218 61.8079 30.3486 61.8079C47.0754 61.8079 60.6972 48.223 60.6972 31.5415V1.27515H0ZM51.7829 31.5415C51.7829 43.3284 42.1675 52.9178 30.3486 52.9178C18.5297 52.9178 8.91427 43.3284 8.91427 31.5415V10.1653H51.8163V31.5415H51.7829Z"/><path d="M24.1383 42.4295H24.1717H34.4548L34.4214 42.3962L46.2403 17.5571H35.9572L28.8124 32.5738L25.4404 26.5804H15.1572L24.1717 42.3962L24.1383 42.4295Z"/><path d="M25.1735 105.926H30.6823C30.5488 108.922 29.9478 111.486 28.8794 113.65C27.811 115.815 26.2752 117.479 24.2387 118.611C22.2021 119.777 19.6647 120.343 16.6265 120.343C14.4563 120.343 12.4865 119.91 10.717 119.044C8.9475 118.179 7.44509 116.947 6.20978 115.348C4.97447 113.75 4.00625 111.819 3.33852 109.555C2.67078 107.291 2.33691 104.76 2.33691 101.963V93.9056C2.33691 91.1087 2.67078 88.6115 3.33852 86.3473C4.00625 84.0832 4.97447 82.152 6.24317 80.5538C7.51187 78.9556 9.04766 77.7236 10.8839 76.8579C12.7202 75.9922 14.7902 75.5593 17.0939 75.5593C19.9318 75.5593 22.3356 76.1254 24.3054 77.2574C26.2752 78.3895 27.7777 80.021 28.846 82.1853C29.9144 84.3496 30.5154 86.98 30.6155 90.1098H25.1067C24.9732 87.8124 24.6059 85.9478 24.0383 84.516C23.4708 83.0843 22.6027 82.0188 21.4675 81.3196C20.3324 80.6204 18.8634 80.2874 17.0605 80.2874C15.4579 80.2874 14.0891 80.6204 12.9205 81.253C11.752 81.8856 10.7838 82.8179 10.0493 83.9833C9.31475 85.1487 8.74718 86.5804 8.37992 88.2452C8.01267 89.91 7.81235 91.7746 7.81235 93.8057V101.897C7.81235 103.795 7.97928 105.593 8.27976 107.257C8.58024 108.922 9.08105 110.354 9.78217 111.619C10.4833 112.851 11.3847 113.85 12.4865 114.549C13.6216 115.249 14.9571 115.582 16.5597 115.582C18.5629 115.582 20.1655 115.249 21.3674 114.583C22.5359 113.917 23.404 112.885 24.0049 111.453C24.6059 110.021 24.9398 108.156 25.1401 105.826L25.1735 105.926Z"/><path d="M36.291 105.126V102.063C36.291 99.566 36.6249 97.3351 37.2592 95.4372C37.8936 93.5393 38.795 91.9411 39.9302 90.6759C41.0653 89.4106 42.4008 88.445 43.9032 87.7791C45.4056 87.1131 47.0416 86.8135 48.7777 86.8135C50.5138 86.8135 52.2165 87.1464 53.7189 87.7791C55.2213 88.4117 56.5568 89.3773 57.7253 90.6759C58.8605 91.9411 59.7619 93.5393 60.3963 95.4372C61.0306 97.3351 61.3645 99.5327 61.3645 102.063V105.126C61.3645 107.624 61.0306 109.855 60.3963 111.752C59.7619 113.65 58.8605 115.249 57.7253 116.514C56.5902 117.779 55.2547 118.745 53.7523 119.377C52.2499 120.01 50.5806 120.343 48.8445 120.343C47.1083 120.343 45.439 120.01 43.9366 119.377C42.4342 118.745 41.0987 117.779 39.9302 116.514C38.795 115.249 37.8936 113.65 37.2592 111.752C36.6249 109.855 36.291 107.657 36.291 105.126ZM41.5995 102.063V105.126C41.5995 106.891 41.7664 108.456 42.1337 109.788C42.501 111.12 43.0018 112.252 43.6695 113.151C44.3372 114.05 45.1051 114.716 45.9732 115.182C46.8412 115.615 47.8095 115.848 48.8445 115.848C50.0464 115.848 51.0814 115.615 52.0162 115.182C52.9176 114.749 53.6855 114.05 54.2865 113.151C54.8875 112.252 55.3215 111.153 55.622 109.788C55.9224 108.456 56.056 106.891 56.056 105.126V102.063C56.056 100.298 55.8891 98.7336 55.5218 97.4017C55.1546 96.0699 54.6538 94.9711 53.986 94.0388C53.3183 93.1398 52.5504 92.4406 51.6489 92.0077C50.7475 91.5749 49.7793 91.3418 48.7443 91.3418C47.7093 91.3418 46.7745 91.5749 45.9064 92.0077C45.0384 92.4406 44.2705 93.1398 43.6027 94.0388C42.9684 94.9378 42.4342 96.0699 42.1003 97.4017C41.7331 98.7336 41.5661 100.265 41.5661 102.063H41.5995Z"/><path d="M67.1074 105.126V102.063C67.1074 99.566 67.4413 97.3351 68.0756 95.4372C68.71 93.5393 69.6114 91.9411 70.7466 90.6759C71.8817 89.4106 73.2172 88.445 74.7196 87.7791C76.222 87.1131 77.858 86.8135 79.5941 86.8135C81.3302 86.8135 83.0329 87.1464 84.5353 87.7791C86.0377 88.4117 87.3732 89.3773 88.5417 90.6759C89.6769 91.9411 90.5783 93.5393 91.2127 95.4372C91.847 97.3351 92.1809 99.5327 92.1809 102.063V105.126C92.1809 107.624 91.847 109.855 91.2127 111.752C90.5783 113.65 89.6769 115.249 88.5417 116.514C87.4066 117.779 86.0711 118.745 84.5687 119.377C83.0663 120.01 81.397 120.343 79.6609 120.343C77.9247 120.343 76.2554 120.01 74.753 119.377C73.2506 118.745 71.9151 117.779 70.7466 116.514C69.6114 115.249 68.71 113.65 68.0756 111.752C67.4413 109.855 67.1074 107.657 67.1074 105.126ZM72.4159 102.063V105.126C72.4159 106.891 72.5829 108.456 72.9501 109.788C73.3174 111.12 73.8182 112.252 74.4859 113.151C75.1536 114.05 75.9215 114.716 76.7896 115.182C77.6576 115.615 78.6259 115.848 79.6609 115.848C80.8628 115.848 81.8978 115.615 82.8326 115.182C83.734 114.749 84.5019 114.05 85.1029 113.151C85.7039 112.252 86.1379 111.153 86.4384 109.788C86.7389 108.456 86.8724 106.891 86.8724 105.126V102.063C86.8724 100.298 86.7055 98.7336 86.3382 97.4017C85.971 96.0699 85.4702 94.9711 84.8024 94.0388C84.1347 93.1398 83.3668 92.4406 82.4653 92.0077C81.5639 91.5749 80.5957 91.3418 79.5607 91.3418C78.5257 91.3418 77.5909 91.5749 76.7228 92.0077C75.8548 92.4406 75.0869 93.1398 74.4191 94.0388C73.7848 94.9378 73.2506 96.0699 72.9167 97.4017C72.5495 98.7336 72.3825 100.265 72.3825 102.063H72.4159Z"/><path d="M104.367 73.8279V119.744H99.0586V73.8279H104.367ZM120.793 87.4128L109.242 102.496L102.097 110.687L101.73 104.793L106.637 98.0343L114.383 87.3795H120.76L120.793 87.4128ZM115.952 119.744L106.838 104.327L109.575 99.3995L122.129 119.744H115.952Z"/><path d="M126.803 78.8224C126.803 77.9234 127.036 77.1576 127.537 76.5583C128.038 75.9256 128.773 75.626 129.774 75.626C130.776 75.626 131.51 75.9256 132.044 76.5583C132.545 77.1909 132.812 77.9234 132.812 78.8224C132.812 79.7214 132.545 80.4206 132.044 81.02C131.544 81.6193 130.776 81.919 129.774 81.919C128.773 81.919 128.038 81.6193 127.537 81.02C127.036 80.4206 126.803 79.6881 126.803 78.8224ZM132.378 87.4129V119.744H127.103V87.4129H132.378Z"/><path d="M152.377 120.343C150.44 120.343 148.704 120.043 147.135 119.477C145.566 118.911 144.264 118.012 143.162 116.847C142.06 115.648 141.226 114.15 140.658 112.352C140.091 110.554 139.79 108.39 139.79 105.926V102.263C139.79 99.3995 140.124 97.0022 140.792 95.0377C141.459 93.0732 142.361 91.475 143.496 90.2763C144.631 89.0776 145.933 88.1786 147.369 87.6459C148.804 87.1131 150.273 86.8135 151.809 86.8135C153.846 86.8135 155.582 87.1464 157.018 87.8124C158.453 88.4783 159.622 89.4439 160.523 90.7424C161.425 92.041 162.092 93.6392 162.526 95.5371C162.96 97.435 163.161 99.5993 163.161 102.096V105.16H142.895V100.631H157.852V99.8989C157.786 98.2341 157.552 96.7358 157.185 95.4705C156.817 94.2053 156.216 93.2064 155.382 92.4739C154.547 91.7413 153.345 91.3751 151.809 91.3751C150.841 91.3751 149.94 91.5416 149.105 91.8745C148.27 92.2075 147.569 92.7735 146.968 93.5726C146.367 94.3717 145.933 95.5038 145.599 96.9023C145.265 98.3007 145.099 100.099 145.099 102.296V105.959C145.099 107.69 145.265 109.189 145.599 110.421C145.933 111.653 146.434 112.685 147.068 113.484C147.703 114.283 148.504 114.882 149.472 115.282C150.407 115.681 151.509 115.881 152.711 115.881C154.48 115.881 155.949 115.548 157.118 114.849C158.286 114.15 159.288 113.284 160.156 112.219L162.96 115.548C162.393 116.381 161.625 117.146 160.69 117.879C159.755 118.611 158.62 119.244 157.285 119.71C155.949 120.176 154.313 120.409 152.444 120.409L152.377 120.343Z"/><path d="M169.538 73.8279H174.847V113.451L174.413 119.744H169.571V73.8279H169.538ZM193.042 102.13V105.16C193.042 107.724 192.809 109.921 192.341 111.852C191.874 113.75 191.173 115.348 190.271 116.614C189.336 117.879 188.235 118.811 186.899 119.444C185.564 120.076 184.061 120.376 182.359 120.376C180.656 120.376 179.22 120.043 178.018 119.344C176.783 118.678 175.781 117.679 174.947 116.414C174.112 115.149 173.478 113.584 173.01 111.786C172.543 109.988 172.209 107.923 172.042 105.659V101.63C172.209 99.3329 172.543 97.2685 173.01 95.4705C173.478 93.6392 174.112 92.1076 174.913 90.809C175.715 89.5105 176.75 88.5449 177.985 87.8789C179.187 87.213 180.656 86.8467 182.325 86.8467C183.995 86.8467 185.564 87.1464 186.899 87.7458C188.235 88.3451 189.336 89.2774 190.271 90.5093C191.173 91.7413 191.874 93.3395 192.341 95.2707C192.809 97.2019 193.042 99.4994 193.042 102.163V102.13ZM187.734 105.126V102.096C187.734 100.298 187.634 98.7335 187.4 97.4017C187.166 96.0698 186.799 94.9711 186.265 94.0721C185.731 93.2063 185.063 92.5404 184.195 92.1076C183.327 91.6747 182.258 91.4416 180.99 91.4416C179.921 91.4416 178.953 91.6747 178.152 92.1076C177.351 92.5404 176.649 93.1398 176.082 93.8723C175.514 94.6048 175.014 95.4705 174.646 96.4028C174.279 97.3351 173.979 98.334 173.812 99.3329V107.823C174.079 109.122 174.479 110.354 175.047 111.553C175.614 112.751 176.382 113.717 177.384 114.483C178.352 115.249 179.588 115.615 181.057 115.615C182.258 115.615 183.293 115.415 184.162 114.982C184.996 114.549 185.697 113.917 186.231 113.051C186.766 112.185 187.166 111.086 187.4 109.755C187.634 108.423 187.767 106.858 187.767 105.06L187.734 105.126Z"/><path d="M198.718 105.126V102.063C198.718 99.566 199.052 97.3351 199.686 95.4372C200.32 93.5393 201.222 91.9411 202.357 90.6759C203.492 89.4106 204.828 88.445 206.33 87.7791C207.832 87.1131 209.468 86.8135 211.204 86.8135C212.941 86.8135 214.643 87.1464 216.146 87.7791C217.648 88.4117 218.984 89.3773 220.152 90.6759C221.287 91.9411 222.189 93.5393 222.823 95.4372C223.457 97.3351 223.791 99.5327 223.791 102.063V105.126C223.791 107.624 223.457 109.855 222.823 111.752C222.189 113.65 221.287 115.249 220.152 116.514C219.017 117.779 217.681 118.745 216.179 119.377C214.677 120.01 213.007 120.343 211.271 120.343C209.535 120.343 207.866 120.01 206.363 119.377C204.861 118.745 203.525 117.779 202.357 116.514C201.222 115.249 200.32 113.65 199.686 111.752C199.052 109.855 198.718 107.657 198.718 105.126ZM204.026 102.063V105.126C204.026 106.891 204.193 108.456 204.56 109.788C204.928 111.12 205.429 112.252 206.096 113.151C206.764 114.05 207.532 114.716 208.4 115.182C209.268 115.615 210.236 115.848 211.271 115.848C212.473 115.848 213.508 115.615 214.443 115.182C215.344 114.749 216.112 114.05 216.713 113.151C217.314 112.252 217.748 111.153 218.049 109.788C218.349 108.456 218.483 106.891 218.483 105.126V102.063C218.483 100.298 218.316 98.7336 217.949 97.4017C217.581 96.0699 217.081 94.9711 216.413 94.0388C215.745 93.1398 214.977 92.4406 214.076 92.0077C213.174 91.5749 212.206 91.3418 211.171 91.3418C210.136 91.3418 209.201 91.5749 208.333 92.0077C207.465 92.4406 206.697 93.1398 206.029 94.0388C205.395 94.9378 204.861 96.0699 204.527 97.4017C204.16 98.7336 203.993 100.265 203.993 102.063H204.026Z"/><path d="M242.454 87.4129V91.6415H227.33V87.4129H242.454ZM232.271 79.5549H237.58V111.752C237.58 112.851 237.713 113.684 237.98 114.25C238.248 114.816 238.581 115.182 239.015 115.348C239.449 115.515 239.884 115.615 240.351 115.615C240.718 115.615 241.119 115.582 241.553 115.482C241.987 115.382 242.287 115.315 242.454 115.249V119.777C242.054 119.91 241.586 120.043 240.985 120.176C240.384 120.31 239.616 120.376 238.715 120.376C237.58 120.376 236.511 120.11 235.543 119.577C234.575 119.044 233.774 118.145 233.173 116.88C232.572 115.615 232.271 113.917 232.271 111.752V79.5882V79.5549Z"/></svg>'
        }
        var cookiesContainer = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerTypes");
        if (cookiesContainer && (cookiesContainer.style.listStyleType = "none"), this.canShowPromotionBanner && -1 === this.template.indexOf("overlay") && -1 === this.template.indexOf("popup")) {
            var promotionBannerContainer = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerTypes"),
                wrapper = document.createElement("div");
            wrapper.classList.add("CybotCookiebotDialogPromotionBannerWrapper"), wrapper.innerHTML = PromotionBannerHTML, promotionBannerContainer.prepend(wrapper)
        }
        if (2 === this.version && -1 === this.template.indexOf("overlay") && -1 === this.template.indexOf("popup") && ("pushdown-v2" === this.template && (this.bodyPaddingTopInit = this.TryParseInt(document.body.style.paddingTop.split("px")[0], 0)), window.CookieConsent.dialog.toggleEdgeDetails()), 2 === this.version && "leveloptin" === this.responseMode && this.DOMid) {
            var dom = document.getElementById(this.DOMid);
            dom && dom.classList.add("CybotMultilevel")
        }
        if (this.isInternalAlias) {
            var elChild = document.createElement("div");
            elChild.innerHTML = "TEST", elChild.style.position = "absolute", elChild.style.fontSize = "100px", elChild.style.opacity = "0.25", elChild.style.fontWeight = "bold", elChild.style.overflow = "visible", elChild.style.pointerEvents = "none", elChild.style.height = "0", elChild.style.width = "0", elChild.style.wordWrap = "normal", this.DOM.insertBefore(elChild, this.DOM.firstChild)
        }
        var preventEventBubbling = function(e) {
            that.isScrolling = !0
        };
        if (this.DOM.addEventListener("wheel", preventEventBubbling, !1), this.DOM.addEventListener("scroll", preventEventBubbling, !1), "custom" !== this.template && 1 === this.version) {
            if ("" === this.title && (document.getElementById("CybotCookiebotDialogBodyContentTitle").style.display = "none"), "" === this.text && (document.getElementById("CybotCookiebotDialogBodyContentText").style.display = "none"), !this.showLogo || this.viewport.winWidth() <= this.autoHideLogoWidth)
                if (document.getElementById("CybotCookiebotDialogPoweredbyLink").style.display = "none", "rtl" === this.textDirection) switch ("overlay" === this.template || "popup" === this.template ? (document.getElementById("CybotCookiebotDialogBodyContent").style.paddingRight = "16px", "leveloptin" === this.responseMode ? document.getElementById("CybotCookiebotDialogBodyLevelButtons").style.marginRight = "8px" : document.getElementById("CybotCookiebotDialogBodyButtons").style.paddingRight = "8px") : (document.getElementById("CybotCookiebotDialogBodyContent").style.paddingRight = "8px", "leveloptin" === this.responseMode ? document.getElementById("CybotCookiebotDialogBodyLevelButtons").style.marginRight = "8px" : document.getElementById("CybotCookiebotDialogBodyButtons").style.paddingRight = "0px"), "leveloptin" !== this.responseMode && (document.getElementById("CybotCookiebotDialogBodyButtons").firstChild.style.marginRight = "2px"), this.responseMode) {
                    case "leveloptin":
                    case "optin":
                    case "inlineoptin":
                        document.getElementById("CybotCookiebotDialogBodyButtonAccept").style.marginRight = "2px";
                        break;
                    case "optout":
                    case "optinout":
                        document.getElementById("CybotCookiebotDialogBodyButtonDecline").style.marginRight = "2px"
                } else switch ("overlay" === this.template || "popup" === this.template ? (document.getElementById("CybotCookiebotDialogBodyContent").style.paddingLeft = "16px", "leveloptin" === this.responseMode ? document.getElementById("CybotCookiebotDialogBodyLevelButtons").style.marginLeft = "8px" : document.getElementById("CybotCookiebotDialogBodyButtons").style.paddingLeft = "8px") : (document.getElementById("CybotCookiebotDialogBodyContent").style.paddingLeft = "8px", "leveloptin" === this.responseMode ? document.getElementById("CybotCookiebotDialogBodyLevelButtons").style.marginLeft = "8px" : document.getElementById("CybotCookiebotDialogBodyButtons").style.paddingLeft = "0px"), this.responseMode) {
                    case "leveloptin":
                    case "optin":
                    case "inlineoptin":
                        document.getElementById("CybotCookiebotDialogBodyButtonAccept").style.marginLeft = "2px";
                        break;
                    case "optout":
                    case "optinout":
                        document.getElementById("CybotCookiebotDialogBodyButtonDecline").style.marginLeft = "2px", document.getElementById("CybotCookiebotDialogBodyButtonDecline").style.marginRight = "12px", document.getElementById("CybotCookiebotDialogBodyButtonAccept").style.marginLeft = "2px";
                        break;
                    case "optionaloptin":
                        document.getElementById("CybotCookiebotDialogBodyContentControls").style.paddingLeft = "12px"
                }
            var iab2tab = document.getElementById("CybotCookiebotDialogDetailBodyContentTabsIABv2");
            iab2tab && (iab2tab.style.display = hasFramework(this.cookieconsent) ? "inline-block" : "none"), this.viewport.addResizeEvent((function() {
                that.resize()
            }));
            var optionaloptinControl = document.getElementById("CybotCookiebotDialogBodyContentControls"),
                declineButton, acceptButton, necInlineLabel;
            if (null != optionaloptinControl && (optionaloptinControl.style.display = "none"), "optin" === this.responseMode) declineButton = document.getElementById("CybotCookiebotDialogBodyButtonDecline"), declineButton.style.display = "none";
            else if ("optionaloptin" === this.responseMode) {
                var acceptButtonOptionaloptin = document.getElementById("CybotCookiebotDialogBodyButtonAccept"),
                    multiAcceptButtonOptionaloptin = document.getElementById("CybotCookiebotDialogBodyLevelButtonAccept");
                if (acceptButtonOptionaloptin.innerHTML = multiAcceptButtonOptionaloptin.innerHTML, "explicit" === window.CookieConsent.consent.method) {
                    var declineButtonOptionaloptin = document.getElementById("CybotCookiebotDialogBodyButtonDecline");
                    declineButtonOptionaloptin.style.display = "none", optionaloptinControl.style.display = "inline"
                }
            } else if ("optout" === this.responseMode) acceptButton = document.getElementById("CybotCookiebotDialogBodyButtonAccept"), acceptButton.style.display = "none";
            else if ("leveloptin" === this.responseMode) {
                var defaultButtons = document.getElementById("CybotCookiebotDialogBodyButtons");
                defaultButtons.style.display = "none", necInlineLabel = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerNecessary"), necInlineLabel.style.borderTop = "0";
                var levelButtons = document.getElementById("CybotCookiebotDialogBodyLevelWrapper");
                levelButtons.style.display = "block";
                var allowallSelectionButtons = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelectionWrapper"),
                    acceptButtons = document.getElementById("CybotCookiebotDialogBodyLevelButtonAcceptWrapper");
                "allowselectdecline" === this.buttonMode || "allowallorselection" === this.buttonMode ? (null != allowallSelectionButtons && (allowallSelectionButtons.style.display = "block"), null != acceptButtons && (acceptButtons.style.display = "none"), declineButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll"), null !== declineButton && (declineButton.style.display = "allowselectdecline" === this.buttonMode ? "" : "none")) : (null != allowallSelectionButtons && (allowallSelectionButtons.style.display = "none"), null != acceptButtons && (acceptButtons.style.display = "block")), setOptionTitles()
            } else if ("inlineoptin" === this.responseMode) {
                declineButton = document.getElementById("CybotCookiebotDialogBodyButtonDecline"), declineButton.style.display = "none", acceptButton = document.getElementById("CybotCookiebotDialogBodyButtonAccept");
                var multiAcceptButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonAccept");
                acceptButton.innerHTML = multiAcceptButton.innerHTML;
                var necCheckBox = document.getElementById("CybotCookiebotDialogBodyLevelButtonNecessary");
                necCheckBox.style.zIndex = 1e4, necCheckBox.style.position = "absolute", necInlineLabel = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerNecessary"), necInlineLabel.title = this.htmlDecode(this.mandatoryText), necInlineLabel.style.paddingTop = "7px", necInlineLabel.style.paddingBottom = "5px", necInlineLabel.style.position = "relative", necInlineLabel.style.zIndex = 1;
                var necLabel = necInlineLabel.firstChild;
                necLabel.htmlFor = necCheckBox.id, necLabel.style.display = "inline-block", necLabel.style.backgroundPositionY = "-1px", necInlineLabel.insertBefore(necCheckBox, necInlineLabel.firstChild), necCheckBox = document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences"), necCheckBox.style.zIndex = 1e4, necCheckBox.style.position = "absolute", necInlineLabel = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerPreference"), necInlineLabel.style.paddingTop = "7px", necInlineLabel.style.paddingBottom = "5px", necInlineLabel.style.position = "relative", necInlineLabel.style.zIndex = 1, necLabel = necInlineLabel.firstChild, necLabel.htmlFor = necCheckBox.id, necLabel.style.display = "inline-block", necLabel.style.backgroundPositionY = "-1px", necInlineLabel.insertBefore(necCheckBox, necInlineLabel.firstChild), necCheckBox = document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics"), necCheckBox.style.zIndex = 1e4, necCheckBox.style.position = "absolute", necInlineLabel = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerStatistics"), necInlineLabel.style.paddingTop = "7px", necInlineLabel.style.paddingBottom = "5px", necInlineLabel.style.position = "relative", necInlineLabel.style.zIndex = 1, necLabel = necInlineLabel.firstChild, necLabel.htmlFor = necCheckBox.id, necLabel.style.display = "inline-block", necLabel.style.backgroundPositionY = "-1px", necInlineLabel.insertBefore(necCheckBox, necInlineLabel.firstChild), necCheckBox = document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing"), necCheckBox.style.zIndex = 1e4, necCheckBox.style.position = "absolute", necInlineLabel = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerAdvertising"), necInlineLabel.style.paddingTop = "7px", necInlineLabel.style.paddingBottom = "5px", necInlineLabel.style.position = "relative", necInlineLabel.style.zIndex = 1, necLabel = necInlineLabel.firstChild, necLabel.htmlFor = necCheckBox.id, necLabel.style.display = "inline-block", necLabel.style.backgroundPositionY = "-1px", necInlineLabel.insertBefore(necCheckBox, necInlineLabel.firstChild), necInlineLabel = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerUnclassified"), necInlineLabel.style.paddingTop = "7px", necInlineLabel.style.paddingBottom = "7px", necInlineLabel.style.borderBottom = "0";
                var cookieTypeTabWrapper = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerTypes");
                cookieTypeTabWrapper.style.backgroundColor = this.customColors.background
            }
        } else if (2 === this.version) {
            var cybotCookiebotDialogPoweredbyImage = document.getElementById("CybotCookiebotDialogPoweredbyImage");
            if (cybotCookiebotDialogPoweredbyImage && (this.showLogo && cybotCookiebotDialogPoweredbyImage.getAttribute("src") || (cybotCookiebotDialogPoweredbyImage.style.display = "none")), !this.bulkconsentDomainsString || !this.domainlist) {
                var bulkConsentContainer = document.getElementById("CybotCookiebotDialogDetailBulkConsent");
                bulkConsentContainer && (bulkConsentContainer.style.display = "none")
            }
            var cybotCookiebotDialogBodyButtonDecline = document.getElementById("CybotCookiebotDialogBodyButtonDecline"),
                cybotCookiebotDialogBodyButtonAccept = document.getElementById("CybotCookiebotDialogBodyButtonAccept"),
                cybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection"),
                cybotCookiebotDialogBodyContentControls = document.getElementsByClassName("CybotCookiebotDialogBodyContentControlsWrapper")[0],
                cybotCookiebotDialogBodyLevelWrapper = document.getElementById("CybotCookiebotDialogBodyLevelWrapper");
            if ("leveloptin" === this.responseMode || 2 === this.version && "inlineoptin" === this.responseMode) {
                var isMultiButton = "ok" !== this.buttonMode;
                cybotCookiebotDialogBodyButtonAccept.id = isMultiButton ? "CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll" : "CybotCookiebotDialogBodyLevelButtonAccept"
            }

            function hideDetailsCheckboxes() {
                for (var consentToggles = document.querySelectorAll("#CybotCookiebotDialogTabContentDetails .CybotCookiebotDialogBodyLevelButtonSliderWrapper"), i = 0; i < consentToggles.length; i++) that.setVisibility(consentToggles[i], "hide")
            }
            "optout" === this.responseMode ? (this.setVisibility(cybotCookiebotDialogBodyButtonDecline, "show"), this.setVisibility(cybotCookiebotDialogBodyLevelWrapper, "hide"), hideDetailsCheckboxes()) : "optin" === this.responseMode ? (this.setVisibility(cybotCookiebotDialogBodyButtonAccept, "show"), this.setVisibility(cybotCookiebotDialogBodyLevelWrapper, "hide"), hideDetailsCheckboxes()) : "optinout" === this.responseMode ? (this.setVisibility(cybotCookiebotDialogBodyButtonAccept, "show"), this.setVisibility(cybotCookiebotDialogBodyButtonDecline, "show"), this.setVisibility(cybotCookiebotDialogBodyLevelWrapper, "hide"), hideDetailsCheckboxes()) : "leveloptin" === this.responseMode ? (this.setVisibility(cybotCookiebotDialogBodyButtonAccept, "show"), this.setVisibility(cybotCookiebotDialogBodyLevelWrapper, "show"), "allowselectdecline" === this.buttonMode ? (this.setVisibility(cybotCookiebotDialogBodyButtonDecline, "show"), this.setVisibility(cybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection, "show"), this.setVisibility(cybotCookiebotDialogBodyButtonAccept, "show"), cybotCookiebotDialogBodyButtonAccept.innerHTML = this.loiAllowAllText) : "allowallorselection" === this.buttonMode ? (this.setVisibility(cybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection, "show"), cybotCookiebotDialogBodyButtonAccept.innerHTML = this.loiAllowAllText) : cybotCookiebotDialogBodyButtonAccept.innerHTML = this.multiAcceptText) : "inlineoptin" === this.responseMode ? (cybotCookiebotDialogBodyButtonAccept.innerHTML = this.multiAcceptText, this.setVisibility(cybotCookiebotDialogBodyButtonAccept, "show"), this.setVisibility(cybotCookiebotDialogBodyLevelWrapper, "hide"), 2 === this.version && ("allowselectdecline" === this.buttonMode ? (this.setVisibility(cybotCookiebotDialogBodyButtonDecline, "show"), this.setVisibility(cybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection, "show"), this.setVisibility(cybotCookiebotDialogBodyButtonAccept, "show"), cybotCookiebotDialogBodyButtonAccept.innerHTML = this.loiAllowAllText) : "allowallorselection" === this.buttonMode && (this.setVisibility(cybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection, "show"), cybotCookiebotDialogBodyButtonAccept.innerHTML = this.loiAllowAllText), this.checkCustomizeButtonState())) : "optionaloptin" === this.responseMode && (this.setVisibility(cybotCookiebotDialogBodyButtonAccept, "show"), this.setVisibility(cybotCookiebotDialogBodyLevelWrapper, "hide"), hideDetailsCheckboxes(), cybotCookiebotDialogBodyButtonAccept.innerHTML = this.multiAcceptText, "explicit" === window.CookieConsent.consent.method ? this.setVisibility(cybotCookiebotDialogBodyContentControls, "show") : (cybotCookiebotDialogBodyButtonAccept.style.width = "100%", cybotCookiebotDialogBodyButtonDecline.style.width = "100%", this.setVisibility(cybotCookiebotDialogBodyButtonDecline, "show")));
            var iab2tabheader = document.getElementById("CybotCookiebotDialogNavItemAdSettings");
            iab2tabheader && hasFramework(this.cookieconsent) && this.setVisibility(iab2tabheader, "show")
        } else this.demomode && (this.DOM.style.zIndex = "100000");
        var isIABEnabled = hasFramework(this.cookieconsent);
        if ("custom" !== this.template && isIABEnabled) {
            var marketingCheckbox = document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing"),
                marketingCheckboxInline = document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline");

            function toggleIABSelections() {
                this.checked ? that.IABSelectAll() : that.IABDeselectAll(!0)
            }
            marketingCheckbox && marketingCheckbox.addEventListener("click", toggleIABSelections), marketingCheckboxInline && marketingCheckboxInline.addEventListener("click", toggleIABSelections)
        }
        if (this.demomode || "leveloptin" !== this.responseMode && "inlineoptin" !== this.responseMode && "custom" !== this.template && "optionaloptin" !== this.responseMode) !this.demomode || "leveloptin" !== this.responseMode && "inlineoptin" !== this.responseMode && "custom" !== this.template || (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences").checked = this.prechecked.preferences), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics").checked = this.prechecked.statistics), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing").checked = this.prechecked.marketing, 2 === this.version && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline").checked = this.prechecked.preferences), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline").checked = this.prechecked.statistics), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline").checked = this.prechecked.marketing)), hasFramework(this.cookieconsent) && (this.consented || this.declined ? this.consent.marketing ? this.IABSelectAll() : this.IABDeselectAll(!0) : this.prechecked.marketing ? this.IABSelectAll() : this.IABDeselectAll(!0))));
        else {
            var c = this.cookieconsent.getCookie(this.cookieconsent.name),
                piiCheckBox = document.getElementById("CybotCookiebotDialogBodyContentCheckboxPersonalInformation");
            if (void 0 !== c && window.CookieConsent && !window.CookieConsent.isNewVersion)
                if (0 === c.indexOf("{")) {
                    var consentJSON = c.replace(/%2c/g, ",").replace(/'/g, '"').replace(/([{\[,])\s*([a-zA-Z0-9_]+?):/g, '$1"$2":'),
                        consentObject = JSON.parse(consentJSON);
                    document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences").checked = consentObject.preferences), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics").checked = consentObject.statistics), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing").checked = consentObject.marketing), 2 === this.version && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline").checked = consentObject.preferences), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline").checked = consentObject.statistics), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline").checked = consentObject.marketing)), hasFramework(this.cookieconsent) && "object" == typeof window.CookieConsentIABCMP && window.CookieConsentIABCMP.updateBannerFromConsent(), "optionaloptin" === this.responseMode && piiCheckBox && (piiCheckBox.checked = navigator.globalPrivacyControl || !consentObject.preferences && !consentObject.statistics && !consentObject.marketing)
                } else "0" === c ? (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences").checked = !1), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics").checked = !1), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing").checked = !1, hasFramework(this.cookieconsent) && this.IABDeselectAll(!0)), 2 === this.version && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline").checked = !1), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline").checked = !1), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline").checked = !1))) : "-2" === c && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences").checked = this.prechecked.preferences), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics").checked = this.prechecked.statistics), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing").checked = this.prechecked.marketing, hasFramework(this.cookieconsent) && (this.consented || this.declined ? this.consent.marketing ? this.IABSelectAll() : this.IABDeselectAll(!0) : this.prechecked.marketing ? this.IABSelectAll() : this.IABDeselectAll(!0))), 2 === this.version && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline").checked = this.prechecked.preferences), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline").checked = this.prechecked.statistics), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline").checked = this.prechecked.marketing)));
            else document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences").checked = this.prechecked.preferences), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics").checked = this.prechecked.statistics), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing").checked = this.prechecked.marketing, hasFramework(this.cookieconsent) && (this.consented || this.declined ? this.consent.marketing ? this.IABSelectAll() : this.IABDeselectAll(!0) : this.prechecked.marketing ? this.IABSelectAll() : this.IABDeselectAll(!0))), window.CookieConsent && (window.CookieConsent.isNewVersion = !1), 2 === this.version && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferencesInline").checked = this.prechecked.preferences), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatisticsInline").checked = this.prechecked.statistics), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketingInline").checked = this.prechecked.marketing));
            "optionaloptin" === this.responseMode && piiCheckBox && hasFramework(this.cookieconsent) && piiCheckBox.addEventListener("click", (function() {
                this.checked ? window.CookieConsent.dialog.IABDeselectAll(!0) : window.CookieConsent.dialog.IABSelectAll()
            }))
        }
        hookupNavEvents(), hookupTabEvents("CybotCookiebotDialogDetailBodyContentIABv2Tab"), hookupCookieEvents("CybotCookiebotDialogDetailBodyContentCookieProvider", "CybotCookiebotDialogDetailBodyContentCookieInfoWrapper"), hookupCookieEvents("CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyIABButtonVendors", "CybotCookiebotDialogBodyLevelButtonIABDescription"), hookupTabEvents("CybotCookiebotDialogDetailBodyContentCookieContainerButton"), hookupButtonEvents(), hookupCheckboxEvents(), hookupTabEvents("CybotExpandLink"), handleClickById("CybotCookiebotDialogBodyEdgeMoreDetailsLink", (function(e) {
            e.preventDefault(), window.CookieConsent.dialog.toggleDetails(e);
            var scrollContainer = document.querySelector(".CybotCookiebotScrollContainer");
            scrollContainer.style.minHeight = null
        })), this.afterToggleStateChange(), 1 === this.version ? this.DOM.style.display = "block" : this.DOM.style.display = "flex", "function" == typeof window.CookiebotCallback_OnDialogDisplay ? window.CookiebotCallback_OnDialogDisplay() : "function" == typeof window.CookieConsentCallback_OnDialogDisplay && window.CookieConsentCallback_OnDialogDisplay();
        var event = document.createEvent("Event");
        if (event.initEvent("CookiebotOnDialogDisplay", !0, !0), window.dispatchEvent(event), event = document.createEvent("Event"), event.initEvent("CookieConsentOnDialogDisplay", !0, !0), window.dispatchEvent(event), 1 === this.version) switch (this.template) {
            case "top":
                this.showAtTop();
                break;
            case "bottom":
                this.showAtBottom();
                break;
            case "slidedown":
                this.slideDown();
                break;
            case "pushdown":
                document.body && document.body.style.paddingTop && (this.bodyPaddingTopInit = this.TryParseInt(document.body.style.paddingTop, 0)), this.pushDown();
                break;
            case "slideup":
                this.DOM.style.paddingBottom = "18px", this.slideUp();
                break;
            case "popup":
            case "overlay":
                this.DOM.style.marginLeft = "0px", this.DOM.style.marginTop = "0px", this.DOM.style.width = "auto", this.DOM.style.height = "auto";
                var DialogHeight = this.DOM.offsetHeight,
                    newTop = Math.round((this.viewport.winHeight() - DialogHeight) / 4);
                newTop < 0 && (newTop = 0), this.DOM.style.marginTop = newTop + "px";
                var DialogWidth = this.DOM.offsetWidth,
                    newLeft = Math.round((this.viewport.winWidth() - DialogWidth) / 2 - 10);
                if (newLeft < 0 && (newLeft = 0), this.DOM.style.marginLeft = newLeft + "px", "overlay" === this.template) {
                    var underlay = document.createElement("div");
                    underlay.id = "CybotCookiebotDialogBodyUnderlay", underlay.style.display = "none", underlay.style.width = "100%", underlay.style.height = "100%";
                    var bodyElement = document.getElementsByTagName("body")[0];
                    bodyElement.appendChild(underlay)
                }
                this.fadeIn();
                break;
            case "custom":
                this.runCustomScript(this.customTemplateDef.FunctionShowName, "show")
        } else {
            var activeTemplate = this.template.split("-")[0];
            this.DOM.setAttribute("data-template", activeTemplate);
            var dialogWrapper = !this.canShowPromotionBanner || -1 === this.template.indexOf("overlay") && -1 === this.template.indexOf("popup") ? this.DOM : this.DOM.parentNode;
            if ("overlay" === activeTemplate) {
                var overlay = document.createElement("div");
                overlay.id = "CybotCookiebotDialogBodyUnderlay", dialogWrapper.parentNode.insertBefore(overlay, dialogWrapper.nextSibling), document.body.style.overflow = "hidden"
            }
        }

        function hookupCheckboxEvents() {
            var checkboxes = document.getElementsByClassName("CybotCookiebotDialogBodyLevelConsentCheckbox");

            function onCheckboxClick(e) {
                var checkboxValue = e.target.checked,
                    target = e.target.getAttribute("data-target");
                if (target) {
                    var elem = document.getElementById(target);
                    elem && (elem.checked = checkboxValue)
                }
                that.afterToggleStateChange()
            }
            for (var i = 0; i < checkboxes.length; i++) checkboxes[i].addEventListener("click", onCheckboxClick, !1)
        }

        function hookupNavEvents() {
            var tabs = document.getElementsByClassName("CybotCookiebotDialogNavItemLink"),
                panels = document.getElementsByClassName("CybotCookiebotDialogTabPanel");

            function onTabClick(e) {
                e.preventDefault();
                for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove("CybotCookiebotDialogActive"), tabs[i].setAttribute("aria-selected", !1);
                for (var j = 0; j < panels.length; j++) {
                    var panel = panels[j];
                    that.setVisibility(panel, "hide"), panel.parentNode.classList.contains("CybotCookiebotScrollContainer") && (that.setVisibility(panel.parentNode, "hide"), panel.parentNode.classList.remove("CybotCookiebotDialogActive"))
                }
                e.currentTarget.classList.add("CybotCookiebotDialogActive"), e.currentTarget.setAttribute("aria-selected", !0);
                var id = e.currentTarget.getAttribute("data-target");
                if (id) {
                    var tab = document.getElementById(id);
                    that.setVisibility(tab, "show"), tab.parentNode.classList.contains("CybotCookiebotScrollContainer") && (that.setVisibility(tab.parentNode, "show"), tab.parentNode.classList.add("CybotCookiebotDialogActive"))
                }
                that.checkCustomizeButtonState()
            }
            for (var k = 0; k < tabs.length; k++) tabs[k].addEventListener("click", onTabClick, !1)
        }

        function hookupTabEvents(className) {
            var els = document.getElementsByClassName(className);

            function onElementClick(e) {
                e.preventDefault(), e.currentTarget.classList.toggle("CybotCookiebotDialogCollapsed");
                var panel = e.currentTarget.getAttribute("data-target");
                if (panel) {
                    var toggleClass = 1 === this.version ? "CybotCookiebotDialogShow" : "CybotCookiebotDialogHide",
                        target = document.getElementById(panel);
                    target.classList.toggle(toggleClass);
                    var isExpanded = null !== target.offsetParent;
                    e.currentTarget.setAttribute("aria-expanded", isExpanded)
                }
            }
            for (var k = 0; k < els.length; k++) els[k].addEventListener("click", onElementClick, !1)
        }

        function hookupCookieEvents(className, targetClassName) {
            var els = document.getElementsByClassName(className);

            function onElementClick(e) {
                var element = e.currentTarget;
                element.classList.toggle("CybotCookiebotDialogCollapsed"), element.parentNode.classList.toggle("open");
                var isExpandButton = element.classList.contains("CybotCookiebotDialogDetailBodyContentCookieProvider"),
                    parentNode = element.parentNode;
                if (parentNode) {
                    var panels = parentNode.getElementsByClassName(targetClassName),
                        btnPanelTriggers = document.getElementsByClassName(className);
                    if (panels)
                        for (var j = 0; j < panels.length; j++) {
                            var panel = panels[j];
                            if (panel.classList.toggle("CybotCookiebotDialogShow"), isExpandButton)
                                for (var isExpanded = null !== panel.offsetParent, b = 0; b < btnPanelTriggers.length; b++) {
                                    var btnPanelTrigger = btnPanelTriggers[b];
                                    btnPanelTrigger.setAttribute("aria-expanded", isExpanded)
                                }
                        }
                }
            }
            for (var k = 0; k < els.length; k++) els[k].addEventListener("click", onElementClick, !1)
        }

        function handleClickById(id, handler) {
            var el = document.getElementById(id);
            if (el) {
                var elHref = el.getAttribute("href");
                if (elHref) {
                    var substring = "javascript:";
                    0 !== elHref.toLowerCase().indexOf(substring) && el.addEventListener("click", (function(e) {
                        handler(e)
                    }))
                }
            }
        }

        function handleClickByClass(id, handler) {
            var els = document.getElementsByClassName(id);
            if (els)
                for (var i = 0; i < els.length; i++) {
                    var elHref = els[i].getAttribute("href");
                    if (elHref) {
                        var substring = "javascript:";
                        0 !== elHref.toLowerCase().indexOf(substring) && els[i].addEventListener("click", (function(e) {
                            handler(e)
                        }))
                    }
                }
        }

        function hookupButtonEvents() {
            var AcceptButton = document.getElementById("CybotCookiebotDialogBodyButtonAccept"),
                DeclineButton = document.getElementById("CybotCookiebotDialogBodyButtonDecline"),
                LevelAcceptButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonAccept"),
                AllowAllButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll"),
                AllowSelectionButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection"),
                DeclineAllButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll"),
                CustomizeButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonCustomize"),
                preferencesCheckBox = document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences"),
                statisticsCheckBox = document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics"),
                marketingCheckBox = document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing"),
                closePromotionBannerButton = document.getElementById("CybotCookiebotDialogPromotionBannerCloseButton"),
                isTemplate = "custom" === that.template;
            if (AcceptButton && ("optionaloptin" === that.responseMode ? AcceptButton.addEventListener("click", (function(e) {
                    if (e.preventDefault(), "explicit" === window.CookieConsent.consent.method) {
                        var acceptCookies = !0,
                            doNotSellMyPersonalInformationCheckbox = document.getElementById("CybotCookiebotDialogBodyContentCheckboxPersonalInformation");
                        doNotSellMyPersonalInformationCheckbox && doNotSellMyPersonalInformationCheckbox.checked && (acceptCookies = !1), setTimeout((function() {
                            acceptCookies ? that.submitConsent(!1) : that.submitDecline(e)
                        }), 0)
                    } else setTimeout((function() {
                        that.submitConsent(!1)
                    }), 0);
                    return !1
                }), !1) : AcceptButton.addEventListener("click", (function(e) {
                    return e.preventDefault(), setTimeout((function() {
                        that.submitConsent(!1)
                    }), 0), !1
                }), !1), AcceptButton.focus()), LevelAcceptButton && (LevelAcceptButton.addEventListener("click", (function(e) {
                    e.preventDefault(), setTimeout((function() {
                        that.submitConsent(!1)
                    }), 0)
                }), !1), LevelAcceptButton.focus()), AllowSelectionButton && (AllowSelectionButton.addEventListener("click", (function(e) {
                    e.preventDefault(), setTimeout((function() {
                        that.submitConsent(!1)
                    }), 0)
                }), !1), AllowSelectionButton.focus()), AllowAllButton && (AllowAllButton.addEventListener("click", (function(e) {
                    e.preventDefault(), preferencesCheckBox && (preferencesCheckBox.checked = !0), statisticsCheckBox && (statisticsCheckBox.checked = !0), marketingCheckBox && (marketingCheckBox.checked = !0), hasFramework(window.CookieConsent) && window.CookieConsent.dialog.IABSelectAll(!0), setTimeout((function() {
                        that.submitConsent(!1)
                    }), 0)
                }), !1), AllowAllButton.focus()), DeclineButton && (DeclineButton.addEventListener("click", (function(e) {
                    return "explicit" !== window.CookieConsent.consent.method && "optionaloptin" === that.responseMode && that.IABDeselectAll(!0), e.preventDefault(), setTimeout((function() {
                        that.submitDecline(e)
                    }), 0), !1
                }), !1), DeclineButton.focus()), DeclineAllButton && (DeclineAllButton.addEventListener("click", (function(e) {
                    return e.preventDefault(), setTimeout((function() {
                        that.submitDecline(e)
                    }), 0), !1
                }), !1), DeclineAllButton.focus()), CustomizeButton && CustomizeButton.addEventListener("click", (function(e) {
                    return e.preventDefault(), that.ShowNavigationTab("CybotCookiebotDialogNavDetails"), !1
                })), closePromotionBannerButton && closePromotionBannerButton.addEventListener("click", (function(e) {
                    e.preventDefault();
                    var bannerWrapper = document.querySelector(".CybotCookiebotDialogPromotionBanner");
                    return bannerWrapper && bannerWrapper.classList.remove("CybotCookiebotDialogActive"), !1
                })), "leveloptin" === that.responseMode || "inlineoptin" === that.responseMode) {
                var neceCheckBox = document.getElementById("CybotCookiebotDialogBodyLevelButtonNecessary"),
                    neceCheckBoxInline = document.getElementById("CybotCookiebotDialogBodyLevelButtonNecessaryInline");
                if (neceCheckBox) {
                    var clickTarget = 1 === that.version && "inlineoptin" === that.responseMode ? neceCheckBox.nextElementSibling : neceCheckBox.parentNode;
                    clickTarget && clickTarget.addEventListener("click", (function(e) {
                        alert(that.mandatoryText + " " + that.htmlDecode(that.cookieIntroTypeNecessary))
                    }), !1)
                }
                neceCheckBoxInline && 2 === that.version && neceCheckBoxInline.parentNode.addEventListener("click", (function(e) {
                    alert(that.mandatoryText + " " + that.htmlDecode(that.cookieIntroTypeNecessary))
                }), !1);
                var detailShowHideWrapper = document.getElementById("CybotCookiebotDialogBodyLevelDetailsWrapper");
                detailShowHideWrapper && detailShowHideWrapper.addEventListener("click", (function(e) {
                    return window.CookieConsent.dialog.toggleDetails(), !1
                }), !1), handleClickById("CybotCookiebotDialogBodyLevelDetailsButton", (function(e) {
                    e.preventDefault()
                }))
            }
            if (isTemplate || handleClickById("CybotCookiebotDialogBodyButtonDetails", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.toggleDetails()
                })), handleClickById("CybotCookiebotDialogBodyContentTextShowIABVendors", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.ShowIABVendors(e)
                })), handleClickById("CybotCookiebotDialogBodyContentTextToggleDetails", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.toggleDetails(e)
                })), handleClickById("CybotCookiebotDialogDetailBodyContentTabsOverview", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.showDetailPane("overview")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentTabsIABv2", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.showDetailPane("iabv2")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentTabsAbout", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.showDetailPane("about")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentCookieContainerNecessary", (function(e) {
                    "A" === e.target.tagName && e.preventDefault(), window.CookieConsent.dialog.showCookieContainerDetailPane("necessary")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentCookieContainerPreference", (function(e) {
                    "A" === e.target.tagName && e.preventDefault(), window.CookieConsent.dialog.showCookieContainerDetailPane("preference")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentCookieContainerStatistics", (function(e) {
                    "A" === e.target.tagName && e.preventDefault(), window.CookieConsent.dialog.showCookieContainerDetailPane("statistics")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentCookieContainerAdvertising", (function(e) {
                    "A" === e.target.tagName && e.preventDefault(), window.CookieConsent.dialog.showCookieContainerDetailPane("advertising")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentCookieContainerUnclassified", (function(e) {
                    "A" === e.target.tagName && e.preventDefault(), window.CookieConsent.dialog.showCookieContainerDetailPane("unclassified")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentIABv2Purposes", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.showCookieContainerIABv2DetailPane("purposes")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentIABv2Features", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.showCookieContainerIABv2DetailPane("features")
                })), handleClickById("CybotCookiebotDialogDetailBodyContentIABv2Partners", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.showCookieContainerIABv2DetailPane("partners")
                })), handleClickById("CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectAllLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABSelectPurposes()
                })), handleClickById("CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectAllLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABDeselectPurposes()
                })), handleClickById("CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.showCookieContainerIABv2DetailPane("partners")
                })), handleClickById("CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectAllPurposesLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABSelectPurposes()
                })), handleClickById("CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectAllPurposesLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABDeselectPurposes()
                })), handleClickById("CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectAllFeaturesLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABSelectFeatures()
                })), handleClickById("CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectAllFeaturesLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABDeselectFeatures()
                })), handleClickByClass("CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectVendorsLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABSelectVendors()
                })), handleClickByClass("CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectVendorsLink", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABDeselectVendors()
                })), handleClickByClass("CybotCookiebotDialogBodyLevelButtonIABShowDetails", (function(e) {
                    e.preventDefault(), window.CookieConsent.dialog.IABShowDetailedInformation.bind(window.CookieConsent.dialog)(e.currentTarget || e.srcElement)
                })), that.bannerCloseButtonEnabled && 2 === that.version) {
                that.DOM.classList.add("CybotCloseButtonEnabled");
                for (var buttons = document.querySelectorAll(".CybotCookiebotBannerCloseButton"), n = 0; n < buttons.length; n++) {
                    var button = buttons[n];
                    button.addEventListener("click", (function(e) {
                        setTimeout((function() {
                            that.submitDecline(e)
                        }))
                    }), !1)
                }
            }
            var els = document.getElementsByClassName("CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow");
            if (els)
                for (var i = 0; i < els.length; i++) ! function(index) {
                    var elIabVendorId = els[index].getAttribute("data-iabvendorid");
                    elIabVendorId && els[index].addEventListener("click", (function(e) {
                        e.preventDefault(), that.IABToggleContainer("CybotCookiebotDialogBodyLevelButtonIABVendorContainer" + elIabVendorId)
                    }));
                    var elGoogleVendorId = els[index].getAttribute("data-googlevendorid");
                    elGoogleVendorId && els[index].addEventListener("click", (function(e) {
                        e.preventDefault(), that.IABToggleContainer("CybotCookiebotDialogBodyLevelButtonGoogleVendorContainer" + elGoogleVendorId)
                    }))
                }(i)
        }

        function setOptionTitles() {
            var optionButNec = document.getElementById("CybotCookiebotDialogBodyLevelButtonNecessary");
            optionButNec && (optionButNec.parentNode.title = that.htmlDecode(that.mandatoryText) + " " + that.htmlDecode(that.cookieIntroTypeNecessary.replace(/<[^>]*>?/gm, "")));
            var optionButPref = document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences");
            optionButPref && (optionButPref.parentNode.title = that.htmlDecode(that.cookieIntroTypePreference.replace(/<[^>]*>?/gm, "")));
            var optionButStat = document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics");
            optionButStat && (optionButStat.parentNode.title = that.htmlDecode(that.cookieIntroTypeStatistics.replace(/<[^>]*>?/gm, "")));
            var optionButAdve = document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing");
            optionButAdve && (optionButAdve.parentNode.title = that.htmlDecode(that.cookieIntroTypeAdvertising.replace(/<[^>]*>?/gm, "")))
        }
        if (2 === this.version && (this.bannerOpenFocusElement = document.activeElement, this.updateVisibleFocusableElements(), this.trapBannerFocus()), 2 === this.version && "pushdown-v2" === this.template && (window.matchMedia("(min-width: 1280px)").matches && this.pushDown(), document.body && window.addEventListener("resize", (function() {
                var paddingTop = parseInt(document.body.style.paddingTop.split("px")[0]),
                    dialogHeight = parseInt(window.CookieConsent.dialog.DOM.offsetHeight);
                window.matchMedia("(min-width: 1280px)").matches ? document.body.style.paddingTop = dialogHeight + window.CookieConsent.dialog.bodyPaddingTopInit + "px" : paddingTop > 0 && (document.body.style.paddingTop = null)
            }))), setTimeout((function() {
                that.setButtonsSize(), that.setZoomLevel()
            }), 50), 2 === this.version) {
            this.initContentFader(), this.resize(), this.DOM.classList.add("CybotCookiebotDialogActive"), window.addEventListener("resize", this.resize);
            var wrapper = document.getElementById("CybotCookiebotDialogWrapper");
            !wrapper || -1 === this.template.indexOf("overlay") && -1 === this.template.indexOf("popup") || (wrapper.classList.add("CybotCookiebotDialogActive"), wrapper.firstChild.classList.add("CybotCookiebotDialogActive"))
        }
    }, window.CookieControl.Dialog.prototype.getVisibleFocusableElements = function() {
        this.DOM.id ? this.DOMid = this.DOM.id : this.DOM.id = this.DOMid;
        var focusableArray = [],
            dialogContainer = document.getElementById(this.DOMid);
        if (dialogContainer)
            for (var focusableEls = dialogContainer.querySelectorAll('a[href]:not([disabled]), button:not([disabled]), input[type="checkbox"]:not([disabled])'), i = 0; i < focusableEls.length; i++) null !== focusableEls[i].offsetParent && focusableArray.push(focusableEls[i]);
        return focusableArray
    }, window.CookieControl.Dialog.prototype.updateVisibleFocusableElements = function(setFocus) {
        if (!this.demomode && "custom" !== this.template) {
            var focusableEls = this.getVisibleFocusableElements();
            focusableEls.length > 0 && (this.bannerFirstFocusElement = focusableEls[0], this.bannerLastFocusElement = focusableEls[focusableEls.length - 1], null != this.bannerFirstFocusElement && setFocus && focusableEls[1].focus())
        }
    }, window.CookieControl.Dialog.prototype.trapBannerFocus = function() {
        if (!this.demomode && "custom" !== this.template) {
            var dialogContainer = document.getElementById(this.DOMid);
            dialogContainer && dialogContainer.addEventListener("keydown", this.onKeydownfunction, !1)
        }
    }, window.CookieControl.Dialog.prototype.releaseBannerFocus = function() {
        if (!this.demomode && "custom" !== this.template) {
            var dialogContainer = document.getElementById(this.DOMid);
            dialogContainer && dialogContainer.removeEventListener("keydown", this.onKeydownfunction), this.bannerOpenFocusElement && (this.bannerOpenFocusElement.focus(), this.bannerOpenFocusElement = null, this.bannerLastFocusElement = null)
        }
    }, window.CookieControl.Dialog.prototype.runCustomScript = function(funcName, txt) {
        this.createCustomScript();
        try {
            funcName = funcName.replace(/^window\./, "");
            for (var parts = funcName.split("."), fn = window, i = 0; i < parts.length; i++) fn = fn[parts[i]];
            "function" == typeof fn && fn()
        } catch (_) {
            console.log("Custom cookie banner %s function not found: %s - please check your custom script.", txt, funcName)
        }
    }, window.CookieControl.Dialog.prototype.createCustomScript = function() {
        if (!this.customScriptInitialized) {
            this.customScriptInitialized = !0;
            var src = this.customTemplateDef.Script;
            if (void 0 !== src && "" !== src)
                if (window.execScript) window.execScript(src);
                else {
                    var s = document.createElement("script");
                    s.type = "text/javascript", s.id = "CookiebotCustomScript";
                    try {
                        s.appendChild(document.createTextNode(src)), document.body.appendChild(s)
                    } catch (e) {
                        s.text = src, document.body.appendChild(s)
                    }
                }
        }
    }, window.CookieControl.Dialog.prototype.TryParseInt = function(str, defaultValue) {
        var retValue = defaultValue;
        return null !== str && str.length > 0 && (isNaN(str) || (retValue = parseInt(str))), retValue
    }, window.CookieControl.Dialog.prototype.resetZoomLevel = function() {
        if (1 === this.version) {
            var contentElement = this.DOM,
                supportsTransforms = "webkitTransform" in document.body.style || "MozTransform" in document.body.style || "msTransform" in document.body.style || "OTransform" in document.body.style || "transform" in document.body.style;
            null != contentElement && "custom" !== this.template && supportsTransforms && (contentElement.style.transform = "", contentElement.style.webkitTransform = "", contentElement.style.msTransform = "", contentElement.style.MozTransform = "", contentElement.style.OTransform = "", contentElement.style.transformOrigin = "", contentElement.style.webkitTransformOrigin = "", contentElement.style.msTransformOrigin = "", contentElement.style.MozTransformOrigin = "", contentElement.style.OTransformOrigin = "")
        }
    }, window.CookieControl.Dialog.prototype.setZoomLevel = function() {
        if (1 === this.version) {
            var scalefactor = 1,
                scalefactorX = 1,
                scalefactorY = 1,
                contentElement = this.DOM,
                supportsTransforms = "webkitTransform" in document.body.style || "MozTransform" in document.body.style || "msTransform" in document.body.style || "OTransform" in document.body.style || "transform" in document.body.style;
            if (null != contentElement && "custom" !== this.template && supportsTransforms) {
                this.resetZoomLevel(), contentElement.style.width = this.initWidth, contentElement.style.height = this.initHeight;
                var DialogHeight = contentElement.scrollHeight,
                    DialogWidth = contentElement.scrollWidth;
                "overlay" !== this.template && "popup" !== this.template || (DialogHeight += 36, DialogWidth += 36);
                var ViewportHeight = this.viewport.winHeight(),
                    ViewportWidth = this.viewport.winWidth();
                if ((DialogHeight > ViewportHeight || DialogWidth > ViewportWidth) && (scalefactorX = ViewportWidth / (DialogWidth + 0), scalefactorY = ViewportHeight / (DialogHeight + 0), scalefactor = Math.round(100 * Math.min(scalefactorY, scalefactorX)) / 100, scalefactorX > .1)) {
                    switch (this.template) {
                        case "top":
                        case "slidedown":
                        case "pushdown":
                            contentElement.style.transform = "scale(" + scalefactor + ")", contentElement.style.webkitTransform = "scale(" + scalefactor + ")", contentElement.style.msTransform = "scale(" + scalefactor + ")", contentElement.style.MozTransform = "scale(" + scalefactor + ")", contentElement.style.OTransform = "scale(" + scalefactor + ")", contentElement.style.transformOrigin = "0 0", contentElement.style.webkitTransformOrigin = "0 0", contentElement.style.msTransformOrigin = "0 0", contentElement.style.MozTransformOrigin = "0 0", contentElement.style.OTransformOrigin = "0 0", contentElement.style.width = Math.floor(ViewportWidth * (1 / scalefactor)) + "px", "pushdown" === this.template && document.body && (document.body.style.paddingTop = this.bodyPaddingTopInit + Math.floor(parseInt(this.DOM.offsetHeight) * scalefactor) + "px");
                            break;
                        case "bottom":
                        case "slideup":
                            contentElement.style.transform = "scale(" + scalefactor + ")", contentElement.style.webkitTransform = "scale(" + scalefactor + ")", contentElement.style.msTransform = "scale(" + scalefactor + ")", contentElement.style.MozTransform = "scale(" + scalefactor + ")", contentElement.style.OTransform = "scale(" + scalefactor + ")", contentElement.style.transformOrigin = "0px bottom", contentElement.style.webkitTransformOrigin = "0px bottom", contentElement.style.msTransformOrigin = "0px bottom", contentElement.style.MozTransformOrigin = "0px bottom", contentElement.style.OTransformOrigin = "0px bottom", contentElement.style.width = Math.floor(ViewportWidth * (1 / scalefactor)) + "px";
                            break;
                        case "overlay":
                        case "popup":
                            this.DOM.style.marginTop = "0", scalefactor = Math.round(100 * Math.min(ViewportHeight / (DialogHeight + 0), ViewportWidth / (DialogWidth + 0))) / 100, this.DOM.style.transform = "scale(" + scalefactor + ")", this.DOM.style.webkitTransform = "scale(" + scalefactor + ")", this.DOM.style.msTransform = "scale(" + scalefactor + ")", this.DOM.style.MozTransform = "scale(" + scalefactor + ")", this.DOM.style.OTransform = "scale(" + scalefactor + ")";
                            var transformOriginX = "center",
                                transformOriginY = "top";
                            DialogWidth > ViewportWidth && (transformOriginX = "0"), DialogHeight > ViewportHeight && (transformOriginY = "0"), this.DOM.style.transformOrigin = transformOriginX + " " + transformOriginY, this.DOM.style.webkitTransformOrigin = transformOriginX + " " + transformOriginY, this.DOM.style.msTransformOrigin = transformOriginX + " " + transformOriginY, this.DOM.style.MozTransformOrigin = transformOriginX + " " + transformOriginY, this.DOM.style.OTransformOrigin = transformOriginX + " " + transformOriginY
                    }
                    this.scalefactor = scalefactor
                }
            }
        }
    }, window.CookieControl.Dialog.prototype.setButtonsSize = function() {
        function setSidePadding(element, padding) {
            element.style.paddingLeft = padding, element.style.paddingRight = padding
        }
        if ("custom" !== this.template && 1 === this.version) {
            var AcceptButton = document.getElementById("CybotCookiebotDialogBodyButtonAccept"),
                DeclineButton = document.getElementById("CybotCookiebotDialogBodyButtonDecline"),
                buttonWidth = 0;
            switch (this.responseMode) {
                case "optionaloptin":
                    null !== AcceptButton.offsetParent && null !== DeclineButton.offsetParent ? (window.addEventListener("resize", (function() {
                        calculateDoNotSellButtonSizes(window.CookieConsent.dialog.version)
                    }), !1), calculateDoNotSellButtonSizes(this.version)) : AcceptButton && setSidePadding(AcceptButton, "12px");
                    break;
                case "optin":
                case "inlineoptin":
                    AcceptButton && setSidePadding(AcceptButton, "12px");
                    break;
                case "optout":
                    DeclineButton && (DeclineButton.style.paddingLeft = "12px", DeclineButton.style.paddingRight = "12px");
                    break;
                case "optinout":
                    if (AcceptButton && DeclineButton) {
                        var AcceptButtonWidth = AcceptButton.offsetWidth - 10,
                            DeclineButtonWidth = DeclineButton.offsetWidth - 10;
                        buttonWidth = Math.max(AcceptButtonWidth, DeclineButtonWidth), buttonWidth = Math.max(80, buttonWidth), buttonWidth > 0 && (AcceptButton.style.width = buttonWidth + "px", DeclineButton.style.width = buttonWidth + "px")
                    }
                    break;
                case "leveloptin":
                    var MultiAcceptButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonAccept"),
                        MultiDialogWrapper = document.getElementById("CybotCookiebotDialogBodyLevelWrapper"),
                        MultiDialogSelector = document.getElementById("CybotCookiebotDialogBodyLevelButtonsRow"),
                        multiDialogWidth = MultiDialogSelector && MultiDialogWrapper.offsetWidth,
                        multiMargin = MultiDialogSelector && 8,
                        inPopupMode = !1,
                        newMargin = 0,
                        AllowAllButtonWidth, AllowSelectionButtonWidth, levelButtonsTableWidth;
                    if (MultiDialogSelector) {
                        document.getElementById("CybotCookiebotDialogBodyLevelButtonsTable").style.width = "auto";
                        var multiButtonWidth = MultiAcceptButton.offsetWidth,
                            multiSelectorWidth = MultiDialogSelector.offsetWidth,
                            multiSpace = multiMargin + 4;
                        "overlay" !== this.template && "popup" !== this.template || (inPopupMode = !0, multiMargin = 24, multiSpace = 28);
                        var scaleLevelButtonsTableToFullWidth = multiSelectorWidth + multiButtonWidth + multiSpace > multiDialogWidth;
                        if (scaleLevelButtonsTableToFullWidth) document.getElementById("CybotCookiebotDialogBodyLevelButtonsTable").style.width = multiDialogWidth - multiMargin + "px";
                        else if (document.getElementById("CybotCookiebotDialogBodyLevelButtonsTable").style.width = "auto", "rtl" === this.textDirection ? document.getElementById("CybotCookiebotDialogBodyLevelButtons").style.float = "right" : document.getElementById("CybotCookiebotDialogBodyLevelButtons").style.float = "left", document.getElementById("CybotCookiebotDialogBodyLevelButtons").style.pointerEvents = "auto", !inPopupMode) {
                            var bodyTextContainer = document.getElementById("CybotCookiebotDialogBodyContentText");
                            if (bodyTextContainer) {
                                var bodyTextContainerWidth = bodyTextContainer.offsetWidth,
                                    LevelButtonsPanel = document.getElementById("CybotCookiebotDialogBodyLevelButtons");
                                LevelButtonsPanel && (multiSelectorWidth + multiButtonWidth + 4 <= bodyTextContainerWidth ? (newMargin = document.getElementById("CybotCookiebotDialogBodyContent").offsetWidth - bodyTextContainerWidth - 2, (!this.showLogo || this.viewport.winWidth() <= this.autoHideLogoWidth) && (newMargin += 2), "rtl" === this.textDirection ? (LevelButtonsPanel.style.marginLeft = "0px", LevelButtonsPanel.style.marginRight = newMargin + "px") : (LevelButtonsPanel.style.marginLeft = newMargin + "px", LevelButtonsPanel.style.marginRight = "0px")) : "rtl" === this.textDirection ? (LevelButtonsPanel.style.marginLeft = "0px", LevelButtonsPanel.style.marginRight = "8px") : (LevelButtonsPanel.style.marginLeft = "8px", LevelButtonsPanel.style.marginRight = "0px"))
                            }
                        }
                    }
                    var AllowAllButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll"),
                        AllowSelectionButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection"),
                        DeclineAllButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll"),
                        allowAllAndAllowSelectionButtonsExist = AllowAllButton && AllowSelectionButton,
                        handleAllowAllOrSelectionButtons = "allowallorselection" === this.buttonMode && allowAllAndAllowSelectionButtonsExist,
                        declineAllAndAllowAllAndAllowSelectionButtonsExist = AllowAllButton && AllowSelectionButton && DeclineAllButton,
                        handleDeclineAllAndAllowAllOrSelectionButtons = "allowselectdecline" === this.buttonMode && declineAllAndAllowAllAndAllowSelectionButtonsExist;
                    if (handleAllowAllOrSelectionButtons) AllowAllButtonWidth = AllowAllButton.offsetWidth - 10, AllowSelectionButtonWidth = AllowSelectionButton.offsetWidth - 10, buttonWidth = Math.max(AllowAllButtonWidth, AllowSelectionButtonWidth), buttonWidth = Math.max(80, buttonWidth), buttonWidth > 0 && (AllowAllButton.style.width = buttonWidth + "px", AllowSelectionButton.style.width = buttonWidth + "px"), levelButtonsTableWidth = inPopupMode ? multiDialogWidth - multiMargin : multiDialogWidth - newMargin, document.getElementById("CybotCookiebotDialogBodyLevelButtonsTable").style.width = levelButtonsTableWidth + "px";
                    else if (handleDeclineAllAndAllowAllOrSelectionButtons) {
                        AllowAllButtonWidth = AllowAllButton.offsetWidth - 10, AllowSelectionButtonWidth = AllowSelectionButton.offsetWidth - 10;
                        var DeclineAllButtonWidth = DeclineAllButton.offsetWidth - 10;
                        buttonWidth = Math.max(80, AllowAllButtonWidth, AllowSelectionButtonWidth, DeclineAllButtonWidth), buttonWidth > 0 && (AllowAllButton.style.width = buttonWidth + "px", AllowSelectionButton.style.width = buttonWidth + "px", DeclineAllButton.style.width = buttonWidth + "px"), levelButtonsTableWidth = inPopupMode ? multiDialogWidth - multiMargin : multiDialogWidth - newMargin, document.getElementById("CybotCookiebotDialogBodyLevelButtonsTable").style.width = levelButtonsTableWidth + "px";
                        var wrapper = document.getElementById("CybotCookiebotDialogBodyLevelWrapper"),
                            wrapperWidth = wrapper.offsetWidth - 2,
                            buttonsWidth = 3 * (22 + buttonWidth);

                        function rearrangeButtons(buttons, display) {
                            for (var i = 0; i < buttons.length; i++) buttons[i].style.display = display, buttons[i].parentElement.appendChild(buttons[i])
                        }
                        wrapperWidth < buttonsWidth ? rearrangeButtons([AllowAllButton, AllowSelectionButton, DeclineAllButton], "block") : rearrangeButtons([DeclineAllButton, AllowSelectionButton, AllowAllButton], "")
                    }
            }
        } else 2 === this.version && "optionaloptin" === this.responseMode && (window.addEventListener("resize", (function() {
            calculateDoNotSellButtonSizes(window.CookieConsent.dialog.version)
        }), !1), calculateDoNotSellButtonSizes(this.version))
    }, window.CookieControl.Dialog.prototype.hide = function(signalIAB) {
        this.visible = !1, document.getElementById(this.DOMid) && ("custom" === this.template ? this.runCustomScript(this.customTemplateDef.FunctionHideName, "hide") : (this.fadeOut(), "pushdown" !== this.template && "pushdown-v2" !== this.template || document.body && (document.body.style.paddingTop = this.bodyPaddingTopInit + "px"))), signalIAB && this.cookieconsent && hasFramework(this.cookieconsent) && "object" == typeof window.CookieConsentIABCMP && window.CookieConsentIABCMP.updateConsentFromBanner(), this.releaseBannerFocus()
    }, window.CookieControl.Dialog.prototype.setVisibility = function(element, value) {
        element && 2 === this.version && ("hide" === value ? element.classList.add("CybotCookiebotDialogHide") : element.classList.remove("CybotCookiebotDialogHide"))
    }, window.CookieControl.Dialog.prototype.afterToggleStateChange = function() {
        if (2 === this.version && "allowallorselection" === this.buttonMode) {
            var isDetailsTab = document.getElementById("CybotCookiebotDialogTabContent").children[1].classList.contains("CybotCookiebotDialogActive"),
                levelOptinCheck = "leveloptin" === this.responseMode,
                inlineOptinCheck = "inlineoptin" === this.responseMode && isDetailsTab;
            if (levelOptinCheck || inlineOptinCheck) {
                var denyButton = document.getElementById("CybotCookiebotDialogBodyButtonDecline"),
                    selectionButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection"),
                    isSelection = document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences").checked || document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics").checked || document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing").checked;
                this.setVisibility(denyButton, isSelection ? "hide" : "show"), this.setVisibility(selectionButton, isSelection ? "show" : "hide")
            }
        }
    }, window.CookieControl.Dialog.prototype.checkCustomizeButtonState = function() {
        if (2 === this.version && "ok" !== this.buttonMode && "inlineoptin" === this.responseMode) {
            var isDetailsTab = document.getElementById("CybotCookiebotDialogTabContent").children[1].classList.contains("CybotCookiebotDialogActive"),
                customizeButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonCustomize"),
                allowSelectionButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection"),
                denyButton = document.getElementById("CybotCookiebotDialogBodyButtonDecline");
            this.setVisibility(customizeButton, isDetailsTab ? "hide" : "show"), this.setVisibility(allowSelectionButton, isDetailsTab ? "show" : "hide"), !isDetailsTab && "allowallorselection" === this.buttonMode && this.setVisibility(denyButton, "hide"), this.afterToggleStateChange()
        }
    }, window.CookieControl.Dialog.prototype.resize = function() {
        if (1 === this.version) {
            var that = this,
                newTop;
            switch (this.template) {
                case "top":
                case "slidedown":
                    this.initHeight = "auto", this.initWidth = "100%";
                    break;
                case "pushdown":
                    this.initHeight = "auto", this.initWidth = "100%", document.body && (document.body.style.paddingTop = this.bodyPaddingTopInit + parseInt(this.DOM.firstChild.offsetHeight) + "px");
                    break;
                case "bottom":
                case "slideup":
                    this.initHeight = "auto", this.initWidth = "100%";
                    var dialogHeight = parseInt(this.DOM.scrollHeight);
                    newTop = this.viewport.winHeight() - dialogHeight, newTop < 0 && (newTop = 0), this.DOM.style.top = Math.round(newTop) + "px";
                    break;
                case "popup":
                case "overlay":
                    this.initHeight = "auto", this.initWidth = "auto", this.DOM.style.marginLeft = "0px", this.DOM.style.marginTop = "0px", this.DOM.style.width = "auto", this.DOM.style.height = "auto";
                    var DialogHeight = this.DOM.offsetHeight;
                    newTop = Math.round((this.viewport.winHeight() - DialogHeight) / 4), newTop < 0 && (newTop = 0), this.DOM.style.marginTop = newTop + "px", this.DOM.style.marginLeft = "0px";
                    var DialogWidth = this.DOM.offsetWidth,
                        newLeft = Math.round((this.viewport.winWidth() - DialogWidth) / 2 - 10);
                    newLeft < 0 && (newLeft = 0), this.DOM.style.marginLeft = newLeft + "px";
                    var underlay = document.getElementById("CybotCookiebotDialogBodyUnderlay");
                    underlay && (underlay.style.height = this.viewport.docHeight() + "px", underlay.style.width = this.viewport.docWidth() + "px")
            }
            setTimeout((function() {
                that.setButtonsSize(), that.setZoomLevel()
            }), 50)
        } else {
            if (-1 === window.CookieConsent.dialog.template.indexOf("overlay") && -1 === window.CookieConsent.dialog.template.indexOf("popup") && "leveloptin" === window.CookieConsent.dialog.responseMode) {
                var bottomWrapper = document.querySelector(".CybotCookiebotDialogBodyBottomWrapper"),
                    scrollContainer = document.querySelector(".CybotCookiebotScrollContainer");
                if ("none" !== window.getComputedStyle(bottomWrapper).borderStyle) {
                    var dialogFooter = document.getElementById("CybotCookiebotDialogFooter"),
                        footerHeight = dialogFooter.offsetHeight;
                    scrollContainer.style.minHeight = footerHeight + "px"
                } else scrollContainer.style.minHeight = null
            }
            sortBannerButtons(window.CookieConsent.dialog);
            var isHighDensityScreen = window.devicePixelRatio > 1,
                dpr = 100 * (isHighDensityScreen ? window.devicePixelRatio / 2 : window.devicePixelRatio);
            dpr >= 250 ? (window.CookieConsent.dialog.DOM.classList.remove("CybotCookiebotDialogZoomedLg"), window.CookieConsent.dialog.DOM.classList.add("CybotCookiebotDialogZoomedXl")) : dpr >= 200 ? (window.CookieConsent.dialog.DOM.classList.remove("CybotCookiebotDialogZoomedXl"), window.CookieConsent.dialog.DOM.classList.add("CybotCookiebotDialogZoomedLg")) : (window.CookieConsent.dialog.DOM.classList.remove("CybotCookiebotDialogZoomedLg"), window.CookieConsent.dialog.DOM.classList.remove("CybotCookiebotDialogZoomedXl"))
        }
    }, window.CookieControl.Dialog.prototype.slideDown = function() {
        this.DOM.style.opacity = 1, this.DOM.style.filter = "alpha(opacity=100)";
        var dialogHeight = parseInt(this.DOM.offsetHeight),
            that = this;
        this.DOM.style.top = this.sliderPos - dialogHeight + "px", this.sliderPos += 8, this.sliderPos < dialogHeight ? setTimeout((function() {
            that.slideDown()
        }), 5) : (this.sliderPos = 0, this.resize())
    }, window.CookieControl.Dialog.prototype.pushDown = function() {
        this.DOM.style.opacity = 1, this.DOM.style.filter = "alpha(opacity=100)";
        var dialogHeight = parseInt(this.DOM.offsetHeight),
            that = this;
        1 === this.version ? (this.DOM.style.top = this.sliderPos - dialogHeight + "px", document.body && (document.body.style.paddingTop = this.bodyPaddingTopInit + this.sliderPos + "px"), this.sliderPos += 8, this.sliderPos < dialogHeight ? setTimeout((function() {
            that.pushDown()
        }), 5) : (this.sliderPos = 0, document.body && (document.body.style.paddingTop = this.bodyPaddingTopInit + dialogHeight + "px"), this.resize())) : (document.body.style.transition = "padding ease .5s", document.body.style.paddingTop = this.bodyPaddingTopInit + dialogHeight + "px", setTimeout((function() {
            document.body.style.transition = null
        }), 500))
    }, window.CookieControl.Dialog.prototype.slideUp = function() {
        this.DOM.style.opacity = 1, this.DOM.style.filter = "alpha(opacity=100)";
        var dialogHeight = parseInt(this.DOM.scrollHeight),
            that = this;
        this.DOM.style.top = this.viewport.winHeight() - this.sliderPos + "px", this.sliderPos += 8, this.sliderPos < dialogHeight ? setTimeout((function() {
            that.slideUp()
        }), 5) : (this.sliderPos = 0, this.DOM.style.top = this.viewport.winHeight() - dialogHeight + "px", this.resize())
    }, window.CookieControl.Dialog.prototype.fadeIn = function() {
        var that = this,
            underlay = document.getElementById("CybotCookiebotDialogBodyUnderlay");
        if (underlay) {
            var underlayOpacity = 80;
            100 === this.faderPos && (null != document.body.style.overflow && void 0 !== document.body.style.overflow && "" !== document.body.style.overflow && (this.bodyOverflow = document.body.style.overflow), document.body.style.overflow = "hidden"), underlay.style.height = this.viewport.docHeight() + "px", underlay.style.width = this.viewport.docWidth() + "px", underlay.style.display = "block", underlay.style.opacity = (80 - this.faderPos) / 100, underlay.style.filter = "alpha(opacity=" + (80 - this.faderPos) + ")"
        }
        this.faderPos -= 5, this.DOM.style.opacity = (100 - this.faderPos) / 100, this.DOM.style.filter = "alpha(opacity=" + (100 - this.faderPos) + ")", this.faderPos < 0 && (this.faderPos = 0), this.faderPos > 0 ? setTimeout((function() {
            that.fadeIn()
        }), 1) : (this.faderPos = 100, this.resize())
    }, window.CookieControl.Dialog.prototype.fadeOut = function() {
        var that = this;
        if (1 === this.version) {
            this.faderPos < 0 && (this.faderPos = 0);
            var underlay = document.getElementById("CybotCookiebotDialogBodyUnderlay");
            underlay && (underlay.style.height = this.viewport.docHeight() + "px", underlay.style.display = "block", underlay.style.opacity = (this.faderPos - 20) / 100, underlay.style.filter = "alpha(opacity=" + (this.faderPos - 30) + ")"), this.DOM.style.opacity = this.faderPos / 100, this.DOM.style.filter = "alpha(opacity=" + this.faderPos + ")", this.faderPos -= 5, this.faderPos < 0 && (this.faderPos = 0), this.faderPos > 0 ? setTimeout((function() {
                that.fadeOut()
            }), 1) : (this.DOM.style.display = "none", underlay && (underlay.style.display = "none", null != this.bodyOverflow ? document.body.style.overflow = this.bodyOverflow : document.body.style.overflow = "auto"), this.faderPos = 100)
        } else {
            var dom = !this.canShowPromotionBanner || -1 === this.template.indexOf("overlay") && -1 === this.template.indexOf("popup") ? this.DOM : this.DOM.parentNode,
                transitionDuration = 200;
            dom.style.transitionDuration = "0.2s", dom.style.opacity = 0, setTimeout((function() {
                dom.style.display = "none", dom.style.transitionDuration = null, dom.classList.remove("CybotCookiebotDialogActive"), document.body.style.overflow = null
            }), 200)
        }
    }, window.CookieControl.Dialog.prototype.showAtTop = function() {
        this.DOM.style.opacity = 1, this.DOM.style.filter = "alpha(opacity=100)", this.DOM.style.top = "0px", this.resize()
    }, window.CookieControl.Dialog.prototype.showAtBottom = function() {
        var that = this;
        setTimeout((function() {
            that.DOM.style.opacity = 1, that.DOM.style.filter = "alpha(opacity=100)";
            var dialogHeight = parseInt(that.DOM.scrollHeight);
            that.DOM.style.top = that.viewport.winHeight() - dialogHeight + "px", that.resize()
        }), 100)
    }, window.CookieControl.Dialog.prototype.submitConsent = function(isImpliedConsent, consentURL, loadAsync) {
        var finalConsentURL = window.location.protocol + "//" + window.location.hostname;
        if (consentURL && 0 === consentURL.indexOf(location.protocol + "//" + location.host) && (finalConsentURL = consentURL), this.demomode || (this.cookieconsent.consented = !0, this.cookieconsent.declined = !1, this.cookieconsent.hasResponse = !0, this.impliedConsentOnScroll && this.detachOnscrollEvent(), this.cookieconsent.consent.preferences = !0, this.cookieconsent.consent.statistics = !0, this.cookieconsent.consent.marketing = !0, this.cookieconsent.consent.method = isImpliedConsent ? "implied" : "explicit", "leveloptin" !== this.responseMode && "inlineoptin" !== this.responseMode && "custom" !== this.template || ("object" == typeof window.CookieConsent.dialog.prechecked && "custom" !== this.template && (this.cookieconsent.consent.preferences = this.prechecked.preferences, this.cookieconsent.consent.statistics = this.prechecked.statistics, this.cookieconsent.consent.marketing = this.prechecked.marketing), document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences") ? document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences").checked ? this.cookieconsent.consent.preferences = !0 : this.cookieconsent.consent.preferences = !1 : document.getElementById("CookieConsentDialogBodyLevelButtonPreferences") && (document.getElementById("CookieConsentDialogBodyLevelButtonPreferences").checked ? this.cookieconsent.consent.preferences = !0 : this.cookieconsent.consent.preferences = !1), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics") ? document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics").checked ? this.cookieconsent.consent.statistics = !0 : this.cookieconsent.consent.statistics = !1 : document.getElementById("CookieConsentDialogBodyLevelButtonStatistics") && (document.getElementById("CookieConsentDialogBodyLevelButtonStatistics").checked ? this.cookieconsent.consent.statistics = !0 : this.cookieconsent.consent.statistics = !1), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing") ? document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing").checked ? this.cookieconsent.consent.marketing = !0 : this.cookieconsent.consent.marketing = !1 : document.getElementById("CookieConsentDialogBodyLevelButtonMarketing") && (document.getElementById("CookieConsentDialogBodyLevelButtonMarketing").checked ? this.cookieconsent.consent.marketing = !0 : this.cookieconsent.consent.marketing = !1), this.cookieconsent.responseMode = this.responseMode)), this.hide(!0), void 0 !== window.CookieDeclaration && "function" == typeof window.CookieDeclaration.SetUserStatusLabel && window.CookieDeclaration.SetUserStatusLabel(), !this.demomode) {
            var dnt = "false";
            this.cookieconsent.doNotTrack && (dnt = "true");
            var consentMethod = "strict";
            isImpliedConsent && (consentMethod = "implied");
            var asyncload = !0;
            void 0 !== loadAsync && (asyncload = loadAsync);
            var pathUrlString = "";
            this.cookieconsent.pathlist.length > 0 && (pathUrlString = "&path=" + encodeURIComponent(this.cookieconsent.pathlist.join(",")));
            var userCountryParameter = window.CookieConsent.userCountry ? "&usercountry=" + window.CookieConsent.userCountry : "";
            if (hasFramework(this.cookieconsent) && this.cookieconsent.frameworkLoaded) {
                latestTcData && (latestTcData.tcString ? window.CookieConsent.IABConsentString = latestTcData.tcString : window.CookieConsent.IABConsentString = "", "object" == typeof window.CookieConsentIABCMP && window.CookieConsentIABCMP.encodeGACMString && latestTcData.addtlConsent ? window.CookieConsent.GACMConsentString = window.CookieConsentIABCMP.encodeGACMString(latestTcData.addtlConsent) : window.CookieConsent.GACMConsentString = ""), pathUrlString += "&iab2=" + window.CookieConsent.IABConsentString + "&gacm=" + window.CookieConsent.GACMConsentString;
                var logConsentUrl = window.CookieConsent.host + "logconsent.ashx?action=accept&nocache=" + (new Date).getTime() + "&dnt=" + dnt + "&method=" + consentMethod + "&clp=" + window.CookieConsent.consent.preferences + "&cls=" + window.CookieConsent.consent.statistics + "&clm=" + window.CookieConsent.consent.marketing + "&cbid=" + window.CookieConsent.serial + pathUrlString + "&cbt=" + window.CookieConsent.responseMode + "&hasdata=true" + userCountryParameter + "&referer=" + encodeURIComponent(finalConsentURL) + "&rc=false";
                logConsent(window.CookieConsent, logConsentUrl, asyncload, !1)
            } else {
                var logConsentUrl = this.cookieconsent.host + "logconsent.ashx?action=accept&nocache=" + (new Date).getTime() + "&dnt=" + dnt + "&method=" + consentMethod + "&clp=" + this.cookieconsent.consent.preferences + "&cls=" + this.cookieconsent.consent.statistics + "&clm=" + this.cookieconsent.consent.marketing + "&cbid=" + this.cookieconsent.serial + pathUrlString + "&cbt=" + window.CookieConsent.responseMode + "&hasdata=true" + userCountryParameter + "&referer=" + encodeURIComponent(finalConsentURL) + "&rc=false";
                logConsent(window.CookieConsent, logConsentUrl, asyncload, !1)
            }
        }
    }, window.CookieControl.Dialog.prototype.submitDecline = function(e) {
        if (this.hide(), !this.demomode) {
            this.cookieconsent.consent.preferences = !1, this.cookieconsent.consent.statistics = !1, this.cookieconsent.consent.marketing = !1, this.cookieconsent.consent.method = "explicit", this.cookieconsent.declined = !0, this.cookieconsent.consented = !1, this.cookieconsent.hasResponse = !0;
            var pathUrlString = "";
            this.cookieconsent.pathlist.length > 0 && (pathUrlString = "&path=" + encodeURIComponent(this.cookieconsent.pathlist.join(",")));
            var userCountryParameter = window.CookieConsent.userCountry ? "&usercountry=" + window.CookieConsent.userCountry : "";
            if (hasFramework(this.cookieconsent) && this.cookieconsent.frameworkLoaded) {
                this.IABDeselectAll(!0), "object" == typeof window.CookieConsentIABCMP && window.CookieConsentIABCMP.updateConsentFromBanner(), latestTcData && (latestTcData.tcString ? window.CookieConsent.IABConsentString = latestTcData.tcString : window.CookieConsent.IABConsentString = "", "object" == typeof window.CookieConsentIABCMP && window.CookieConsentIABCMP.encodeGACMString && latestTcData.addtlConsent ? window.CookieConsent.GACMConsentString = window.CookieConsentIABCMP.encodeGACMString(latestTcData.addtlConsent) : window.CookieConsent.GACMConsentString = ""), pathUrlString += "&iab2=" + window.CookieConsent.IABConsentString + "&gacm=" + window.CookieConsent.GACMConsentString;
                var logConsentUrl = window.CookieConsent.host + "logconsent.ashx?action=decline&nocache=" + (new Date).getTime() + "&cbid=" + window.CookieConsent.serial + pathUrlString + "&cbt=" + window.CookieConsent.responseMode + "&method=strict&hasdata=true" + userCountryParameter + "&referer=" + encodeURIComponent(window.location.protocol + "//" + window.location.hostname) + "&rc=false";
                logConsent(window.CookieConsent, logConsentUrl, !1, !1)
            } else {
                var logConsentUrl = this.cookieconsent.host + "logconsent.ashx?action=decline&nocache=" + (new Date).getTime() + "&cbid=" + this.cookieconsent.serial + pathUrlString + "&cbt=" + window.CookieConsent.responseMode + "&method=strict&hasdata=true" + userCountryParameter + "&referer=" + encodeURIComponent(window.location.protocol + "//" + window.location.hostname) + "&rc=false";
                logConsent(window.CookieConsent, logConsentUrl, !1, !1)
            }
            this.cookieconsent.resetCookies()
        }
        void 0 !== window.CookieDeclaration && "function" == typeof window.CookieDeclaration.SetUserStatusLabel && window.CookieDeclaration.SetUserStatusLabel()
    }, window.CookieControl.Dialog.prototype.addStyle = function(templatename, css) {
        this.styles[templatename] = css
    }, window.CookieControl.Dialog.prototype.appendStyle = function(templatename) {
        generateStylesAndAppendStylesheet(document, this, templatename)
    }, window.CookieControl.Dialog.prototype.showDetails = function() {
        var detailsPane = document.getElementById("CybotCookiebotDialogDetail");
        detailsPane.style.display = "block", this.resize()
    }, window.CookieControl.Dialog.prototype.toggleEdgeDetails = function() {
        if (this.DOMid) {
            var dom = document.getElementById(this.DOMid);
            if (dom && (document.body && (document.body.style.paddingTop = this.bodyPaddingTopInit + "px"), dom.style.top = null, dom.setAttribute("data-template", "popup"), dom.classList.toggle("CybotEdge"), dom.classList.contains("CybotEdge"))) {
                var tab = document.getElementById("CybotCookiebotDialogNavDeclaration");
                tab.setAttribute("aria-selected", !1)
            }
        }
    }, window.CookieControl.Dialog.prototype.hideDetails = function() {
        var detailsPane = document.getElementById("CybotCookiebotDialogDetail");
        detailsPane.style.display = "none", this.resize()
    }, window.CookieControl.Dialog.prototype.toggleDetails = function(e) {
        if (2 === this.version) this.ShowNavigationTab("CybotCookiebotDialogNavDetails"), calculateDoNotSellButtonSizes(this.version);
        else {
            e && e.preventDefault(), this.DOM.style.height = this.initHeight, this.DOM.style.width = this.initWidth;
            var detailsPane = document.getElementById("CybotCookiebotDialogDetail"),
                toggleLink;
            toggleLink = "leveloptin" === this.responseMode ? document.getElementById("CybotCookiebotDialogBodyLevelDetailsButton") : document.getElementById("CybotCookiebotDialogBodyButtonDetails");
            var DetailsCSSElement = new window.CookieControl.CSS(toggleLink);
            if (detailsPane) {
                var AcceptButton;
                switch (this.template) {
                    case "top":
                    case "slidedown":
                    case "pushdown":
                    case "popup":
                    case "overlay":
                        "block" === detailsPane.style.display ? ("leveloptin" === this.responseMode ? (DetailsCSSElement.removeClass("CybotCookiebotDialogBodyLevelDetailsButtonExpanded"), AcceptButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonAccept")) : (DetailsCSSElement.removeClass("CybotCookiebotDialogBodyLinkExpanded"), AcceptButton = document.getElementById("CybotCookiebotDialogBodyButtonAccept")), this.hideDetails(), toggleLink.innerHTML = this.showDetailsText, AcceptButton.focus()) : (toggleLink.innerHTML = this.hideDetailsText, "leveloptin" === this.responseMode ? DetailsCSSElement.addClass("CybotCookiebotDialogBodyLevelDetailsButtonExpanded") : DetailsCSSElement.addClass("CybotCookiebotDialogBodyLinkExpanded"), this.showDetails(), toggleLink.blur());
                        break;
                    case "bottom":
                    case "slideup":
                        "block" === detailsPane.style.display ? ("leveloptin" === this.responseMode ? (DetailsCSSElement.removeClass("CybotCookiebotDialogBodyLevelDetailsButtonExpanded"), AcceptButton = document.getElementById("CybotCookiebotDialogBodyLevelButtonAccept")) : (DetailsCSSElement.removeClass("CybotCookiebotDialogBodyLinkExpanded"), AcceptButton = document.getElementById("CybotCookiebotDialogBodyButtonAccept")), this.hideDetails(), toggleLink.innerHTML = this.showDetailsText, AcceptButton.focus()) : (toggleLink.innerHTML = this.hideDetailsText, "leveloptin" === this.responseMode ? DetailsCSSElement.addClass("CybotCookiebotDialogBodyLevelDetailsButtonExpanded") : DetailsCSSElement.addClass("CybotCookiebotDialogBodyLinkExpanded"), this.showDetails(), toggleLink.blur());
                        var thisDOMElement = document.getElementById(this.name),
                            dialogHeight = parseInt(thisDOMElement.scrollHeight);
                        thisDOMElement.style.top = this.viewport.winHeight() - dialogHeight + "px"
                }
                if ("inlineoptin" === this.responseMode) {
                    if ("block" === detailsPane.style.display) {
                        var cookieTypeTabWrapper = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerTypes");
                        if (parseInt(cookieTypeTabWrapper.clientHeight) > 0) {
                            cookieTypeTabWrapper.style.paddingTop = "0px";
                            var wrapperheight = 170,
                                paddingsize = 170 - parseInt(cookieTypeTabWrapper.clientHeight);
                            cookieTypeTabWrapper.style.paddingTop = paddingsize + "px"
                        }
                    }
                } else if ("block" === detailsPane.style.display) {
                    var cookieTypeTabWrapperNecessary = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerNecessary");
                    cookieTypeTabWrapperNecessary.style.borderTop = "0px";
                    var IABv2FirstTabWrapper = document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2Intro");
                    IABv2FirstTabWrapper && (IABv2FirstTabWrapper.style.borderTop = "0px")
                }
            }
            this.resize()
        }
    }, window.CookieControl.Dialog.prototype.showDetailPane = function(paneID) {
        for (var paneIDs = ["CybotCookiebotDialogDetailBodyContentTextAbout", "CybotCookiebotDialogDetailBodyContentTextIABv2", "CybotCookiebotDialogDetailBodyContentTextOverview"], i = 0; i < paneIDs.length; i++) {
            var tempPane = document.getElementById(paneIDs[i]);
            tempPane && (tempPane.style.display = "none")
        }
        for (var tabIDs = ["CybotCookiebotDialogDetailBodyContentTabsAbout", "CybotCookiebotDialogDetailBodyContentTabsIABv2", "CybotCookiebotDialogDetailBodyContentTabsOverview"], j = 0, detailsTab, detailsPane; j < tabIDs.length; j++) {
            var tempTab = document.getElementById(tabIDs[j]);
            tempTab && (tempTab.className = "CybotCookiebotDialogDetailBodyContentTab CybotCookiebotDialogDetailBodyContentTabsItem")
        }
        switch (paneID.toLowerCase()) {
            case "overview":
                detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentTabsOverview"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentTextOverview");
                break;
            case "iabv2":
                detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentTabsIABv2"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentTextIABv2");
                break;
            default:
                detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentTabsAbout"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentTextAbout")
        }
        detailsTab && (detailsTab.className = "CybotCookiebotDialogDetailBodyContentTab CybotCookiebotDialogDetailBodyContentTabsItemSelected"), detailsPane && (detailsPane.style.display = "block")
    }, window.CookieControl.Dialog.prototype.htmlDecode = function(input) {
        var e = document.createElement("div");
        return e.innerHTML = input, 0 === e.childNodes.length ? "" : e.childNodes[0].nodeValue
    }, window.CookieControl.Dialog.prototype.showCookieContainerDetailPane = function(cookiePaneID) {
        for (var paneIDs = ["CybotCookiebotDialogDetailBodyContentCookieTabsNecessary", "CybotCookiebotDialogDetailBodyContentCookieTabsPreference", "CybotCookiebotDialogDetailBodyContentCookieTabsStatistics", "CybotCookiebotDialogDetailBodyContentCookieTabsAdvertising", "CybotCookiebotDialogDetailBodyContentCookieTabsUnclassified"], i = 0; i < paneIDs.length; i++) {
            var tempPane = document.getElementById(paneIDs[i]);
            tempPane.style.display = "none"
        }
        for (var tabIDs = ["CybotCookiebotDialogDetailBodyContentCookieContainerNecessary", "CybotCookiebotDialogDetailBodyContentCookieContainerPreference", "CybotCookiebotDialogDetailBodyContentCookieContainerStatistics", "CybotCookiebotDialogDetailBodyContentCookieContainerAdvertising", "CybotCookiebotDialogDetailBodyContentCookieContainerUnclassified"], j = 0, detailsTab, detailsPane; j < tabIDs.length; j++) {
            var tempTab = document.getElementById(tabIDs[j]);
            tempTab.className = "CybotCookiebotDialogDetailBodyContentCookieContainerTypes"
        }
        switch (cookiePaneID.toLowerCase()) {
            case "preference":
                detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerPreference"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieTabsPreference");
                break;
            case "statistics":
                detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerStatistics"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieTabsStatistics");
                break;
            case "advertising":
                detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerAdvertising"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieTabsAdvertising");
                break;
            case "unclassified":
                detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerUnclassified"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieTabsUnclassified");
                break;
            default:
                detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieContainerNecessary"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentCookieTabsNecessary")
        }
        detailsTab.className = "CybotCookiebotDialogDetailBodyContentCookieContainerTypesSelected", detailsPane.scrollIntoView(!0), detailsPane.style.display = "block"
    }, window.CookieControl.Dialog.prototype.showCookieContainerIABv2DetailPane = function(IABPaneID) {
        if (2 === this.version) this.ToggleIabTab("CybotCookiebotDialogDetailBodyContentIABv2Partners");
        else {
            for (var paneIDs = ["CybotCookiebotDialogDetailBodyContentIABv2TabPurposes", "CybotCookiebotDialogDetailBodyContentIABv2TabFeatures", "CybotCookiebotDialogDetailBodyContentIABv2TabPartners"], i = 0; i < paneIDs.length; i++) {
                var tempPane = document.getElementById(paneIDs[i]);
                tempPane && (tempPane.style.display = "none")
            }
            for (var tabIDs = ["CybotCookiebotDialogDetailBodyContentIABv2Purposes", "CybotCookiebotDialogDetailBodyContentIABv2Features", "CybotCookiebotDialogDetailBodyContentIABv2Partners"], j = 0, detailsTab, detailsPane; j < tabIDs.length; j++) {
                var tempTab = document.getElementById(tabIDs[j]);
                tempTab && (tempTab.className = "CybotCookiebotDialogDetailBodyContentCookieContainerTypes")
            }
            switch (IABPaneID.toLowerCase()) {
                case "features":
                    detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2Features"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2TabFeatures");
                    break;
                case "partners":
                    detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2Partners"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2TabPartners");
                    break;
                default:
                    detailsTab = document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2Purposes"), detailsPane = document.getElementById("CybotCookiebotDialogDetailBodyContentIABv2TabPurposes")
            }
            detailsTab && (detailsTab.className = "CybotCookiebotDialogDetailBodyContentIABv2TabSelected"), detailsPane && (detailsPane.scrollIntoView(!0), detailsPane.style.display = "block")
        }
    }, window.CookieControl.Dialog.prototype.setStateUnchecked = function() {
        setTimeout((function() {
            document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences").checked = !1), document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics").checked = !1), document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing") && (document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing").checked = !1), hasFramework(this.cookieconsent) && this.IABDeselectAll(!0)
        }), 100)
    }, window.CookieControl.Dialog.prototype.getIAB2PurposeById = function(PurposeID) {
        for (var k in this.IABGVL.purposes)
            if (this.IABGVL.purposes[k].id === PurposeID) return this.IABGVL.purposes[k].name;
        return ""
    }, window.CookieControl.Dialog.prototype.getIAB2SpecialPurposeById = function(SpecialPurposeID) {
        for (var k in this.IABGVL.specialPurposes)
            if (this.IABGVL.specialPurposes[k].id === SpecialPurposeID) return this.IABGVL.specialPurposes[k].name;
        return ""
    }, window.CookieControl.Dialog.prototype.getIAB2FeatureById = function(FeatureID) {
        for (var k in this.IABGVL.features)
            if (this.IABGVL.features[k].id === FeatureID) return this.IABGVL.features[k].name;
        return ""
    }, window.CookieControl.Dialog.prototype.getIAB2SpecialFeatureById = function(SpecialFeatureID) {
        for (var k in this.IABGVL.specialFeatures)
            if (this.IABGVL.specialFeatures[k].id === SpecialFeatureID) return this.IABGVL.specialFeatures[k].name;
        return ""
    }, window.CookieControl.Dialog.prototype.IABSelectPurposes = function() {
        for (var IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonPurposes"), i = 0; i < IABelements.length; i++) IABelements[i].checked = !0;
        IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonPurposesLegitimateInterestSelection");
        for (var j = 0; j < IABelements.length; j++) IABelements[j].checked = !0
    }, window.CookieControl.Dialog.prototype.IABDeselectPurposes = function(exemptLegInt) {
        for (var IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonPurposes"), i = 0; i < IABelements.length; i++) IABelements[i].checked = !1;
        IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonPurposesLegitimateInterestSelection");
        for (var j = 0; j < IABelements.length; j++) exemptLegInt || (IABelements[j].checked = !1)
    }, window.CookieControl.Dialog.prototype.IABSelectFeatures = function() {
        for (var IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonFeatures"), i = 0; i < IABelements.length; i++) IABelements[i].checked = !0
    }, window.CookieControl.Dialog.prototype.IABDeselectFeatures = function() {
        for (var IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonFeatures"), i = 0; i < IABelements.length; i++) IABelements[i].checked = !1
    }, window.CookieControl.Dialog.prototype.IABSelectVendors = function() {
        for (var IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonVendors"), i = 0; i < IABelements.length; i++) IABelements[i].checked = !0;
        IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonVendorsLegitimateInterestSelection");
        for (var j = 0; j < IABelements.length; j++) IABelements[j].checked = !0
    }, window.CookieControl.Dialog.prototype.IABDeselectVendors = function(exemptLegInt) {
        for (var IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonVendors"), i = 0; i < IABelements.length; i++) IABelements[i].checked = !1;
        IABelements = document.getElementsByClassName("CybotCookiebotDialogBodyIABButtonVendorsLegitimateInterestSelection");
        for (var j = 0; j < IABelements.length; j++) exemptLegInt || (IABelements[j].checked = !1)
    }, window.CookieControl.Dialog.prototype.IABSelectAll = function() {
        this.IABSelectPurposes(), this.IABSelectFeatures(), this.IABSelectVendors()
    }, window.CookieControl.Dialog.prototype.ShowNavigationTab = function(domId) {
        2 === this.version && (this.DOM.classList.contains("CybotEdge") && this.toggleEdgeDetails(), sortBannerButtons(window.CookieConsent.dialog));
        for (var tabs = document.getElementsByClassName("CybotCookiebotDialogNavItemLink"), panels = document.getElementsByClassName("CybotCookiebotDialogTabPanel"), i = 0; i < tabs.length; i++) tabs[i].classList.remove("CybotCookiebotDialogActive"), tabs[i].setAttribute("aria-selected", !1);
        for (var j = 0; j < panels.length; j++) {
            var panel = panels[j];
            this.setVisibility(panel, "hide"), panel.parentNode.classList.contains("CybotCookiebotScrollContainer") && (this.setVisibility(panel.parentNode, "hide"), panel.parentNode.classList.remove("CybotCookiebotDialogActive"))
        }
        var el = document.getElementById(domId);
        if (el) {
            el.focus(), el.setAttribute("aria-selected", !0), el.classList.add("CybotCookiebotDialogActive");
            var id = el.getAttribute("data-target");
            if (id) {
                var panelToShow = document.getElementById(id);
                this.setVisibility(panelToShow, "show"), panelToShow.parentNode.classList.contains("CybotCookiebotScrollContainer") && (this.setVisibility(panelToShow.parentNode, "show"), panelToShow.parentNode.classList.add("CybotCookiebotDialogActive"))
            }
        }
        this.checkCustomizeButtonState()
    }, window.CookieControl.Dialog.prototype.ToggleIabTab = function(domId) {
        var el = document.getElementById(domId);
        el.classList.toggle("CybotCookiebotDialogCollapsed");
        var id = el.getAttribute("data-target");
        if (id) {
            var target = document.getElementById(id);
            target && (target.classList.remove("CybotCookiebotDialogHide"), target.setAttribute("aria-expanded", "true"), target.scrollIntoView(!0))
        }
    }, window.CookieControl.Dialog.prototype.ShowIABVendors = function(e) {
        e && e.preventDefault(), 2 === this.version ? (this.ShowNavigationTab("CybotCookiebotDialogNavAdSettings"), this.ToggleIabTab("CybotCookiebotDialogDetailBodyContentIABv2Partners")) : (document.getElementById("CybotCookiebotDialogDetail") && "block" !== document.getElementById("CybotCookiebotDialogDetail").style.display && this.toggleDetails(), this.showDetailPane("iabv2"), this.showCookieContainerIABv2DetailPane("partners"))
    }, window.CookieControl.Dialog.prototype.IABDeselectAll = function(excemptLegInt) {
        this.IABDeselectPurposes(excemptLegInt), this.IABDeselectFeatures(), this.IABDeselectVendors(excemptLegInt)
    }, window.CookieControl.Dialog.prototype.IABToggleContainer = function(toggleElementContainer) {
        var toggleElementContainerNode = document.getElementById(toggleElementContainer);
        if (toggleElementContainerNode) {
            var DetailsCSSElement = new window.CookieControl.CSS(toggleElementContainerNode);
            DetailsCSSElement.toggleClass("CybotCookiebotDialogBodyLevelButtonIABContainer", "CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed");
            var targetElement = 2 === this.version ? toggleElementContainerNode.querySelector(".CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow") || toggleElementContainerNode.querySelector(".CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide") : toggleElementContainerNode.firstChild;
            if (targetElement) {
                var DetailsCSSToggleElement = new window.CookieControl.CSS(targetElement);
                DetailsCSSToggleElement.toggleClass("CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow", "CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide"), DetailsCSSToggleElement.hasClass("CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow") ? targetElement.title = this.IABResourceStrings.expand : targetElement.title = this.IABResourceStrings.collapse
            }
            if (2 === this.version) {
                var target = toggleElementContainerNode.querySelector(".CybotCookiebotDialogBodyLevelButtonIABDescription"),
                    isExpanded = null !== target.offsetParent;
                toggleElementContainerNode.setAttribute("aria-expanded", isExpanded)
            }
        }
    }, window.CookieControl.Dialog.prototype.IABShowDetailedInformation = function(caller) {
        var vendorId = caller.dataset.iabvendorid,
            vendor = this.IABGVL.vendors[vendorId],
            container = document.getElementById("CybotCookiebotDialogBodyLevelButtonIABVendorContainer" + vendorId),
            detailsContainer = container.getElementsByClassName("CybotCookiebotDialogBodyIABDetails")[0];
        detailsContainer.innerHTML = this.IABResourceStrings.loadingText;
        var successCallback = this.IABCreateStorageDeviceDisclosure.bind(this),
            errorCallback = this.IABStorageDeviceDisclosureFailure.bind(this),
            xhr = new XMLHttpRequest;
        xhr.open("GET", vendor.deviceStorageDisclosureUrl, !0), xhr.onload = function(e) {
            4 === xhr.readyState && (200 === xhr.status ? successCallback(detailsContainer, caller, vendor, xhr.responseText) : errorCallback(detailsContainer, xhr.statusText))
        }, xhr.onerror = function(e) {
            errorCallback(detailsContainer, xhr.statusText)
        }, xhr.send(null)
    }, window.CookieControl.Dialog.prototype.IABStorageDeviceDisclosureFailure = function(detailsContainer, statusText) {
        detailsContainer.innerHTML = this.IABResourceStrings.errorText
    }, window.CookieControl.Dialog.prototype.IABCreateStorageDeviceDisclosure = function(detailsContainer, caller, vendor, text) {
        var trackerList;
        try {
            var disclosureInformation = JSON.parse(text);
            trackerList = disclosureInformation.disclosures
        } catch (exception) {
            return void this.IABStorageDeviceDisclosureFailure(vendor, exception.message)
        }
        var newVendorContent = '<table class="CybotCookiebotDialogDetailBodyContentCookieTypeTable">';
        newVendorContent += "<thead><tr>", newVendorContent += '<th scope="col">' + this.IABResourceStrings.name + "</th>", newVendorContent += '<th scope="col">' + this.IABResourceStrings.domain + "</th>", newVendorContent += '<th scope="col">' + this.IABResourceStrings.purpose + "</th>", newVendorContent += '<th scope="col">' + this.IABResourceStrings.expiry + "</th>", newVendorContent += '<th scope="col">' + this.IABResourceStrings.type + "</th>", newVendorContent += "</thead></tr>", newVendorContent += "<tbody>";
        for (var z = 0; z < trackerList.length; z++) {
            var tracker = trackerList[z];
            newVendorContent += "<tr>", newVendorContent += "<td>" + tracker.identifier + "</td>", newVendorContent += "<td>", tracker.domain && (newVendorContent += tracker.domain), newVendorContent += "</td>", newVendorContent += '<td><ul class="CybotCookiebotDialogBodyLevelButtonIABBullet">';
            for (var trackerX = 0; trackerX < tracker.purposes.length; trackerX++) newVendorContent += "<li>" + this.getIAB2PurposeById(tracker.purposes[trackerX]) + "</li>";
            if (newVendorContent += "</ul></td>", newVendorContent += "<td>", tracker.maxAgeSeconds) {
                var refreshMessage = tracker.cookieRefresh ? "<br /><i>" + this.IABResourceStrings.expiryRefreshText + "</i>" : "";
                newVendorContent += this.CalculateHumanDuration(tracker.maxAgeSeconds, this.IABResourceStrings) + refreshMessage
            }
            newVendorContent += "</td>";
            var trackingTypeStr = null;
            switch (tracker.type) {
                case "app":
                    trackingTypeStr = this.IABResourceStrings.trackingTypeApp;
                    break;
                case "cookie":
                    trackingTypeStr = this.IABResourceStrings.trackingTypeCookie;
                    break;
                default:
                    trackingTypeStr = this.IABResourceStrings.trackingTypeWeb
            }
            newVendorContent += "<td>" + trackingTypeStr + "</td>", newVendorContent += "</tr>"
        }
        newVendorContent += "</tbody></table>", detailsContainer.innerHTML = newVendorContent, caller.parentElement.style.display = "none"
    }, window.CookieControl.Dialog.prototype.CalculateHumanDuration = function(seconds, iabStrings) {
        if (seconds <= 0) return iabStrings.session;
        for (var levels = [
                [Math.floor(seconds / 31536e3), [iabStrings.year, iabStrings.years]],
                [Math.floor(seconds % 31536e3 / 86400), [iabStrings.day, iabStrings.days]],
                [Math.floor(seconds % 31536e3 % 86400 / 3600), [iabStrings.hour, iabStrings.hours]],
                [Math.floor(seconds % 31536e3 % 86400 % 3600 / 60), [iabStrings.minutes, iabStrings.minutes]],
                [seconds % 31536e3 % 86400 % 3600 % 60, [iabStrings.second, iabStrings.seconds]]
            ], returntext = "", i = 0, max = levels.length; i < max; i++) 0 !== levels[i][0] && (returntext += " " + levels[i][0] + " " + (1 === levels[i][0] ? levels[i][1][0] : levels[i][1][1]));
        return returntext.trim()
    }, window.CookieControl.Viewport = function() {
        this.docHeight = function() {
            var w = window,
                d = document,
                e = d.documentElement,
                g = d.getElementsByTagName("body")[0];
            return Math.max(Math.max(d.body.scrollHeight, d.documentElement.scrollHeight), Math.max(d.body.offsetHeight, d.documentElement.offsetHeight), Math.max(d.body.clientHeight, d.documentElement.clientHeight), w.innerHeight || e.clientHeight || g.clientHeight)
        }, this.docWidth = function() {
            var w = window,
                d = document,
                e = d.documentElement,
                g = d.getElementsByTagName("body")[0];
            return Math.max(Math.max(d.body.scrollWidth, d.documentElement.scrollWidth), Math.max(d.body.offsetWidth, d.documentElement.offsetWidth), Math.max(d.body.clientWidth, d.documentElement.clientWidth), w.innerWidth || e.clientWidth || g.clientWidth)
        }, this.winHeight = function() {
            var w = window,
                d = document,
                e = d.documentElement,
                g = d.getElementsByTagName("body")[0];
            return w.innerHeight || e.clientHeight || g.clientHeight
        }, this.winWidth = function() {
            var w = window,
                d = document,
                e = d.documentElement,
                g = d.getElementsByTagName("body")[0];
            return w.innerWidth || e.clientWidth || g.clientWidth
        }, this.findPos = function(obj) {
            var curtop = 0,
                curleft = 0;
            if (obj.offsetParent)
                do {
                    curleft += obj.offsetLeft, curtop += obj.offsetTop
                } while (obj = obj.offsetParent);
            return [curleft, curtop]
        }, this.getPageScroll = function() {
            var xScroll, yScroll;
            return self.pageYOffset ? (yScroll = self.pageYOffset, xScroll = self.pageXOffset) : document.documentElement && document.documentElement.scrollTop ? (yScroll = document.documentElement.scrollTop, xScroll = document.documentElement.scrollLeft) : document.body && (yScroll = document.body.scrollTop, xScroll = document.body.scrollLeft), [xScroll, yScroll]
        }, this.findPosRelativeToViewport = function(obj) {
            var objPos = this.findPos(obj),
                scroll = this.getPageScroll();
            return [objPos[0] - scroll[0], objPos[1] - scroll[1]]
        }, this.addResizeEvent = function(func) {
            window.addEventListener("resize", (function() {
                func()
            }), !1), window.addEventListener("orientationchange", (function() {
                func()
            }), !1)
        }
    }, window.CookieControl.Viewport.prototype.isIE = function() {
        var myNav = navigator.userAgent.toLowerCase();
        return -1 !== myNav.indexOf("msie") ? parseInt(myNav.split("msie")[1]) : 0
    }, window.CookieControl.Dialog.prototype.clearDOM = function() {
        var dialogs = document.getElementsByName(this.DOMid);
        if (dialogs.length > 0)
            for (var i = 0; i < dialogs.length; i++) {
                var dialog = !this.canShowPromotionBanner || -1 === this.template.indexOf("overlay") && -1 === this.template.indexOf("popup") ? dialogs[i] : dialogs[i].parentElement;
                dialog.parentNode.removeChild(dialog)
            }
        var dialogstyle = document.getElementById("CookiebotDialogStyle");
        dialogstyle && dialogstyle.parentNode.removeChild(dialogstyle);
        var overlay = document.getElementById("CybotCookiebotDialogBodyUnderlay");
        overlay && overlay.parentNode.removeChild(overlay), this.buttonsDirection = "row"
    }, window.CookieControl.CSS = function(ele) {
        this.HTMLElement = ele
    }, window.CookieControl.CSS.prototype.hasClass = function(cls) {
        return this.HTMLElement.className && this.HTMLElement.className.match(new RegExp("(\\s|^)" + cls + "(\\s|$)"))
    }, window.CookieControl.CSS.prototype.addClass = function(cls) {
        this.hasClass(cls) || (this.HTMLElement.className += " " + cls)
    }, window.CookieControl.CSS.prototype.removeClass = function(cls) {
        if (this.hasClass(cls)) {
            var reg = new RegExp("(\\s|^)" + cls + "(\\s|$)");
            this.HTMLElement.className = this.HTMLElement.className.replace(reg, " ")
        }
    }, window.CookieControl.CSS.prototype.replaceClass = function(oldClass, newClass) {
        this.hasClass(oldClass) && (this.removeClass(oldClass), this.addClass(newClass))
    }, window.CookieControl.CSS.prototype.toggleClass = function(cls1, cls2) {
        this.hasClass(cls1) ? this.replaceClass(cls1, cls2) : this.hasClass(cls2) ? this.replaceClass(cls2, cls1) : this.addClass(cls1)
    }
}();

CookieConsent.consentLifetime = 12;
CookieConsent.responseMode = 'leveloptin';
CookieControl.Dialog.prototype.loadTemplates = function() {
    this.templates['bottom-v2'] = '<div id="CybotCookiebotDialog" name="CybotCookiebotDialog" role="dialog" aria-modal="true" aria-labelledby="CybotCookiebotDialogBodyContentTitle" tabindex="-1" lang="[#LANGUAGE#]" dir="[#TEXTDIRECTION#]" ng-non-bindable=""><div class="CybotCookiebotDialogContentWrapper"><div id="CybotCookiebotDialogHeader"><div id="CybotCookiebotDialogHeaderLogosWrapper"><div id="CybotCookiebotDialogPoweredbyLink"><img id="CybotCookiebotDialogPoweredbyImage" src="[#LOGO#]" alt="[#LOGOALT#]"></div><a href="[#POWEREDBYURL#]" rel="noopener nofollow" target="_blank" id="CybotCookiebotDialogPoweredbyCybot" aria-label="[#LOGOARIALABEL#]"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 458 121"><path d="M83.8673 1.30835V46.7911C83.8673 50.2873 84.9356 52.1186 87.5732 52.1186C90.3443 52.1186 91.2124 49.9876 91.2124 46.7911V1.30835H102.864V46.0586C102.864 56.6469 97.9899 61.8744 87.4063 61.8744C76.8226 61.8744 72.3154 56.8133 72.3154 45.9587V1.30835H83.9006H83.8673Z"></path><path d="M119.057 42.5959V46.7247C119.057 50.6536 120.025 52.4849 122.663 52.4849C125.301 52.4849 125.935 49.7879 125.935 46.9577C125.935 41.3307 124.867 39.6991 118.757 34.5715C112.013 28.8778 108.54 25.5149 108.54 16.6914C108.54 7.86784 111.378 0.30957 122.73 0.30957C134.782 0.30957 136.552 8.50047 136.552 15.3262V18.7557H125.668V15.193C125.668 11.5637 125.067 9.76573 122.797 9.76573C120.66 9.76573 119.992 11.597 119.992 14.96C119.992 18.556 120.66 20.3207 125.601 24.183C134.415 31.0754 137.553 34.9711 137.553 44.7935C137.553 54.6159 134.348 61.8412 122.463 61.8412C110.577 61.8412 107.772 54.9822 107.772 46.1253V42.5293H119.057V42.5959Z"></path><path d="M166.466 34.638H154.113V50.9199H168.57L167.201 61.0087H142.595V1.30835H167.134V11.4637H154.147V24.5492H166.5V34.638H166.466Z"></path><path d="M184.195 35.0708V61.042H172.71V1.30835H187.667C197.717 1.30835 202.658 5.70347 202.658 16.1585V18.3228C202.658 26.8466 199.252 29.3772 196.682 30.5758C200.421 32.3738 202.157 35.1041 202.157 43.4282C202.157 49.1885 202.057 57.9121 202.558 61.042H191.407C190.672 58.345 190.705 50.5536 190.705 42.9288C190.705 36.2029 189.938 35.0708 185.564 35.0708H184.195ZM184.228 26.0142H185.664C189.504 26.0142 191.073 24.8156 191.073 19.2551V16.3583C191.073 12.3627 190.271 10.365 186.031 10.365H184.228V26.0142Z"></path><path d="M237.513 41.5304V44.7601C237.513 52.2851 236.111 61.9078 222.389 61.9078C212.239 61.9078 207.832 56.5137 207.832 45.526V16.2585C207.832 5.87002 213.04 0.409424 222.622 0.409424C235.276 0.409424 237.313 8.70021 237.313 16.5249V20.2873H225.727V15.193C225.727 11.8967 225.026 10.2318 222.622 10.2318C220.219 10.2318 219.484 11.7968 219.484 15.193V46.7912C219.484 49.9877 220.018 52.1519 222.622 52.1519C225.227 52.1519 225.861 50.3206 225.861 46.5248V41.5637H237.513V41.5304Z"></path><path d="M266.326 34.638H253.973V50.9199H268.429L267.06 61.0087H242.454V1.30835H266.993V11.4637H254.006V24.5492H266.359V34.638H266.326Z"></path><path d="M272.569 61.0087V1.30835H285.323C287.226 8.60025 293.236 35.6369 293.703 38.2673H293.97C293.336 30.3095 292.935 19.4549 292.935 11.1308V1.30835H303.619V61.042H290.765C289.53 55.3483 282.986 24.4493 282.585 22.5514H282.285C282.719 29.5769 283.086 41.4637 283.086 50.8533V61.042H272.603L272.569 61.0087Z"></path><path d="M316.34 11.4637H307.626V1.30835H336.639V11.4637H327.858V61.042H316.373V11.4637H316.34Z"></path><path d="M352.197 35.0708V61.042H340.712V1.30835H355.669C365.719 1.30835 370.66 5.70347 370.66 16.1585V18.3228C370.66 26.8466 367.254 29.3772 364.684 30.5758C368.423 32.3738 370.159 35.1041 370.159 43.4282C370.159 49.1885 370.059 57.9121 370.56 61.042H359.409C358.674 58.345 358.707 50.5536 358.707 42.9288C358.707 36.2029 357.939 35.0708 353.566 35.0708H352.197ZM352.23 26.0142H353.666C357.505 26.0142 359.075 24.8156 359.075 19.2551V16.3583C359.075 12.3627 358.273 10.365 354.033 10.365H352.23V26.0142Z"></path><path d="M388.388 1.30835V61.042H376.903V1.30835H388.388Z"></path><path d="M424.346 41.5304V44.7601C424.346 52.2851 422.944 61.9078 409.222 61.9078C399.072 61.9078 394.665 56.5137 394.665 45.526V16.2585C394.665 5.87002 399.873 0.409424 409.455 0.409424C422.109 0.409424 424.146 8.70021 424.146 16.5249V20.2873H412.56V15.193C412.56 11.8967 411.859 10.2318 409.455 10.2318C407.052 10.2318 406.317 11.7968 406.317 15.193V46.7912C406.317 49.9877 406.851 52.1519 409.455 52.1519C412.06 52.1519 412.694 50.3206 412.694 46.5248V41.5637H424.346V41.5304Z"></path><path d="M439.504 42.5959V46.7247C439.504 50.6536 440.472 52.4849 443.109 52.4849C445.747 52.4849 446.381 49.7879 446.381 46.9577C446.381 41.3307 445.313 39.6991 439.203 34.5715C432.459 28.8778 428.987 25.5149 428.987 16.6914C428.987 7.86784 431.825 0.30957 443.176 0.30957C455.229 0.30957 456.998 8.50047 456.998 15.3262V18.7557H446.114V15.193C446.114 11.5637 445.513 9.76573 443.243 9.76573C441.106 9.76573 440.438 11.597 440.438 14.96C440.438 18.556 441.106 20.3207 446.047 24.183C454.861 31.0754 458 34.9711 458 44.7935C458 54.6159 454.795 61.8412 442.909 61.8412C431.023 61.8412 428.219 54.9822 428.219 46.1253V42.5293H439.504V42.5959Z"></path><path d="M0 1.27515V31.5415C0 48.223 13.6218 61.8079 30.3486 61.8079C47.0754 61.8079 60.6972 48.223 60.6972 31.5415V1.27515H0ZM51.7829 31.5415C51.7829 43.3284 42.1675 52.9178 30.3486 52.9178C18.5297 52.9178 8.91427 43.3284 8.91427 31.5415V10.1653H51.8163V31.5415H51.7829Z"></path><path d="M24.1383 42.4295H24.1717H34.4548L34.4214 42.3962L46.2403 17.5571H35.9572L28.8124 32.5738L25.4404 26.5804H15.1572L24.1717 42.3962L24.1383 42.4295Z"></path><path d="M25.1735 105.926H30.6823C30.5488 108.922 29.9478 111.486 28.8794 113.65C27.811 115.815 26.2752 117.479 24.2387 118.611C22.2021 119.777 19.6647 120.343 16.6265 120.343C14.4563 120.343 12.4865 119.91 10.717 119.044C8.9475 118.179 7.44509 116.947 6.20978 115.348C4.97447 113.75 4.00625 111.819 3.33852 109.555C2.67078 107.291 2.33691 104.76 2.33691 101.963V93.9056C2.33691 91.1087 2.67078 88.6115 3.33852 86.3473C4.00625 84.0832 4.97447 82.152 6.24317 80.5538C7.51187 78.9556 9.04766 77.7236 10.8839 76.8579C12.7202 75.9922 14.7902 75.5593 17.0939 75.5593C19.9318 75.5593 22.3356 76.1254 24.3054 77.2574C26.2752 78.3895 27.7777 80.021 28.846 82.1853C29.9144 84.3496 30.5154 86.98 30.6155 90.1098H25.1067C24.9732 87.8124 24.6059 85.9478 24.0383 84.516C23.4708 83.0843 22.6027 82.0188 21.4675 81.3196C20.3324 80.6204 18.8634 80.2874 17.0605 80.2874C15.4579 80.2874 14.0891 80.6204 12.9205 81.253C11.752 81.8856 10.7838 82.8179 10.0493 83.9833C9.31475 85.1487 8.74718 86.5804 8.37992 88.2452C8.01267 89.91 7.81235 91.7746 7.81235 93.8057V101.897C7.81235 103.795 7.97928 105.593 8.27976 107.257C8.58024 108.922 9.08105 110.354 9.78217 111.619C10.4833 112.851 11.3847 113.85 12.4865 114.549C13.6216 115.249 14.9571 115.582 16.5597 115.582C18.5629 115.582 20.1655 115.249 21.3674 114.583C22.5359 113.917 23.404 112.885 24.0049 111.453C24.6059 110.021 24.9398 108.156 25.1401 105.826L25.1735 105.926Z"></path><path d="M36.291 105.126V102.063C36.291 99.566 36.6249 97.3351 37.2592 95.4372C37.8936 93.5393 38.795 91.9411 39.9302 90.6759C41.0653 89.4106 42.4008 88.445 43.9032 87.7791C45.4056 87.1131 47.0416 86.8135 48.7777 86.8135C50.5138 86.8135 52.2165 87.1464 53.7189 87.7791C55.2213 88.4117 56.5568 89.3773 57.7253 90.6759C58.8605 91.9411 59.7619 93.5393 60.3963 95.4372C61.0306 97.3351 61.3645 99.5327 61.3645 102.063V105.126C61.3645 107.624 61.0306 109.855 60.3963 111.752C59.7619 113.65 58.8605 115.249 57.7253 116.514C56.5902 117.779 55.2547 118.745 53.7523 119.377C52.2499 120.01 50.5806 120.343 48.8445 120.343C47.1083 120.343 45.439 120.01 43.9366 119.377C42.4342 118.745 41.0987 117.779 39.9302 116.514C38.795 115.249 37.8936 113.65 37.2592 111.752C36.6249 109.855 36.291 107.657 36.291 105.126ZM41.5995 102.063V105.126C41.5995 106.891 41.7664 108.456 42.1337 109.788C42.501 111.12 43.0018 112.252 43.6695 113.151C44.3372 114.05 45.1051 114.716 45.9732 115.182C46.8412 115.615 47.8095 115.848 48.8445 115.848C50.0464 115.848 51.0814 115.615 52.0162 115.182C52.9176 114.749 53.6855 114.05 54.2865 113.151C54.8875 112.252 55.3215 111.153 55.622 109.788C55.9224 108.456 56.056 106.891 56.056 105.126V102.063C56.056 100.298 55.8891 98.7336 55.5218 97.4017C55.1546 96.0699 54.6538 94.9711 53.986 94.0388C53.3183 93.1398 52.5504 92.4406 51.6489 92.0077C50.7475 91.5749 49.7793 91.3418 48.7443 91.3418C47.7093 91.3418 46.7745 91.5749 45.9064 92.0077C45.0384 92.4406 44.2705 93.1398 43.6027 94.0388C42.9684 94.9378 42.4342 96.0699 42.1003 97.4017C41.7331 98.7336 41.5661 100.265 41.5661 102.063H41.5995Z"></path><path d="M67.1074 105.126V102.063C67.1074 99.566 67.4413 97.3351 68.0756 95.4372C68.71 93.5393 69.6114 91.9411 70.7466 90.6759C71.8817 89.4106 73.2172 88.445 74.7196 87.7791C76.222 87.1131 77.858 86.8135 79.5941 86.8135C81.3302 86.8135 83.0329 87.1464 84.5353 87.7791C86.0377 88.4117 87.3732 89.3773 88.5417 90.6759C89.6769 91.9411 90.5783 93.5393 91.2127 95.4372C91.847 97.3351 92.1809 99.5327 92.1809 102.063V105.126C92.1809 107.624 91.847 109.855 91.2127 111.752C90.5783 113.65 89.6769 115.249 88.5417 116.514C87.4066 117.779 86.0711 118.745 84.5687 119.377C83.0663 120.01 81.397 120.343 79.6609 120.343C77.9247 120.343 76.2554 120.01 74.753 119.377C73.2506 118.745 71.9151 117.779 70.7466 116.514C69.6114 115.249 68.71 113.65 68.0756 111.752C67.4413 109.855 67.1074 107.657 67.1074 105.126ZM72.4159 102.063V105.126C72.4159 106.891 72.5829 108.456 72.9501 109.788C73.3174 111.12 73.8182 112.252 74.4859 113.151C75.1536 114.05 75.9215 114.716 76.7896 115.182C77.6576 115.615 78.6259 115.848 79.6609 115.848C80.8628 115.848 81.8978 115.615 82.8326 115.182C83.734 114.749 84.5019 114.05 85.1029 113.151C85.7039 112.252 86.1379 111.153 86.4384 109.788C86.7389 108.456 86.8724 106.891 86.8724 105.126V102.063C86.8724 100.298 86.7055 98.7336 86.3382 97.4017C85.971 96.0699 85.4702 94.9711 84.8024 94.0388C84.1347 93.1398 83.3668 92.4406 82.4653 92.0077C81.5639 91.5749 80.5957 91.3418 79.5607 91.3418C78.5257 91.3418 77.5909 91.5749 76.7228 92.0077C75.8548 92.4406 75.0869 93.1398 74.4191 94.0388C73.7848 94.9378 73.2506 96.0699 72.9167 97.4017C72.5495 98.7336 72.3825 100.265 72.3825 102.063H72.4159Z"></path><path d="M104.367 73.8279V119.744H99.0586V73.8279H104.367ZM120.793 87.4128L109.242 102.496L102.097 110.687L101.73 104.793L106.637 98.0343L114.383 87.3795H120.76L120.793 87.4128ZM115.952 119.744L106.838 104.327L109.575 99.3995L122.129 119.744H115.952Z"></path><path d="M126.803 78.8224C126.803 77.9234 127.036 77.1576 127.537 76.5583C128.038 75.9256 128.773 75.626 129.774 75.626C130.776 75.626 131.51 75.9256 132.044 76.5583C132.545 77.1909 132.812 77.9234 132.812 78.8224C132.812 79.7214 132.545 80.4206 132.044 81.02C131.544 81.6193 130.776 81.919 129.774 81.919C128.773 81.919 128.038 81.6193 127.537 81.02C127.036 80.4206 126.803 79.6881 126.803 78.8224ZM132.378 87.4129V119.744H127.103V87.4129H132.378Z"></path><path d="M152.377 120.343C150.44 120.343 148.704 120.043 147.135 119.477C145.566 118.911 144.264 118.012 143.162 116.847C142.06 115.648 141.226 114.15 140.658 112.352C140.091 110.554 139.79 108.39 139.79 105.926V102.263C139.79 99.3995 140.124 97.0022 140.792 95.0377C141.459 93.0732 142.361 91.475 143.496 90.2763C144.631 89.0776 145.933 88.1786 147.369 87.6459C148.804 87.1131 150.273 86.8135 151.809 86.8135C153.846 86.8135 155.582 87.1464 157.018 87.8124C158.453 88.4783 159.622 89.4439 160.523 90.7424C161.425 92.041 162.092 93.6392 162.526 95.5371C162.96 97.435 163.161 99.5993 163.161 102.096V105.16H142.895V100.631H157.852V99.8989C157.786 98.2341 157.552 96.7358 157.185 95.4705C156.817 94.2053 156.216 93.2064 155.382 92.4739C154.547 91.7413 153.345 91.3751 151.809 91.3751C150.841 91.3751 149.94 91.5416 149.105 91.8745C148.27 92.2075 147.569 92.7735 146.968 93.5726C146.367 94.3717 145.933 95.5038 145.599 96.9023C145.265 98.3007 145.099 100.099 145.099 102.296V105.959C145.099 107.69 145.265 109.189 145.599 110.421C145.933 111.653 146.434 112.685 147.068 113.484C147.703 114.283 148.504 114.882 149.472 115.282C150.407 115.681 151.509 115.881 152.711 115.881C154.48 115.881 155.949 115.548 157.118 114.849C158.286 114.15 159.288 113.284 160.156 112.219L162.96 115.548C162.393 116.381 161.625 117.146 160.69 117.879C159.755 118.611 158.62 119.244 157.285 119.71C155.949 120.176 154.313 120.409 152.444 120.409L152.377 120.343Z"></path><path d="M169.538 73.8279H174.847V113.451L174.413 119.744H169.571V73.8279H169.538ZM193.042 102.13V105.16C193.042 107.724 192.809 109.921 192.341 111.852C191.874 113.75 191.173 115.348 190.271 116.614C189.336 117.879 188.235 118.811 186.899 119.444C185.564 120.076 184.061 120.376 182.359 120.376C180.656 120.376 179.22 120.043 178.018 119.344C176.783 118.678 175.781 117.679 174.947 116.414C174.112 115.149 173.478 113.584 173.01 111.786C172.543 109.988 172.209 107.923 172.042 105.659V101.63C172.209 99.3329 172.543 97.2685 173.01 95.4705C173.478 93.6392 174.112 92.1076 174.913 90.809C175.715 89.5105 176.75 88.5449 177.985 87.8789C179.187 87.213 180.656 86.8467 182.325 86.8467C183.995 86.8467 185.564 87.1464 186.899 87.7458C188.235 88.3451 189.336 89.2774 190.271 90.5093C191.173 91.7413 191.874 93.3395 192.341 95.2707C192.809 97.2019 193.042 99.4994 193.042 102.163V102.13ZM187.734 105.126V102.096C187.734 100.298 187.634 98.7335 187.4 97.4017C187.166 96.0698 186.799 94.9711 186.265 94.0721C185.731 93.2063 185.063 92.5404 184.195 92.1076C183.327 91.6747 182.258 91.4416 180.99 91.4416C179.921 91.4416 178.953 91.6747 178.152 92.1076C177.351 92.5404 176.649 93.1398 176.082 93.8723C175.514 94.6048 175.014 95.4705 174.646 96.4028C174.279 97.3351 173.979 98.334 173.812 99.3329V107.823C174.079 109.122 174.479 110.354 175.047 111.553C175.614 112.751 176.382 113.717 177.384 114.483C178.352 115.249 179.588 115.615 181.057 115.615C182.258 115.615 183.293 115.415 184.162 114.982C184.996 114.549 185.697 113.917 186.231 113.051C186.766 112.185 187.166 111.086 187.4 109.755C187.634 108.423 187.767 106.858 187.767 105.06L187.734 105.126Z"></path><path d="M198.718 105.126V102.063C198.718 99.566 199.052 97.3351 199.686 95.4372C200.32 93.5393 201.222 91.9411 202.357 90.6759C203.492 89.4106 204.828 88.445 206.33 87.7791C207.832 87.1131 209.468 86.8135 211.204 86.8135C212.941 86.8135 214.643 87.1464 216.146 87.7791C217.648 88.4117 218.984 89.3773 220.152 90.6759C221.287 91.9411 222.189 93.5393 222.823 95.4372C223.457 97.3351 223.791 99.5327 223.791 102.063V105.126C223.791 107.624 223.457 109.855 222.823 111.752C222.189 113.65 221.287 115.249 220.152 116.514C219.017 117.779 217.681 118.745 216.179 119.377C214.677 120.01 213.007 120.343 211.271 120.343C209.535 120.343 207.866 120.01 206.363 119.377C204.861 118.745 203.525 117.779 202.357 116.514C201.222 115.249 200.32 113.65 199.686 111.752C199.052 109.855 198.718 107.657 198.718 105.126ZM204.026 102.063V105.126C204.026 106.891 204.193 108.456 204.56 109.788C204.928 111.12 205.429 112.252 206.096 113.151C206.764 114.05 207.532 114.716 208.4 115.182C209.268 115.615 210.236 115.848 211.271 115.848C212.473 115.848 213.508 115.615 214.443 115.182C215.344 114.749 216.112 114.05 216.713 113.151C217.314 112.252 217.748 111.153 218.049 109.788C218.349 108.456 218.483 106.891 218.483 105.126V102.063C218.483 100.298 218.316 98.7336 217.949 97.4017C217.581 96.0699 217.081 94.9711 216.413 94.0388C215.745 93.1398 214.977 92.4406 214.076 92.0077C213.174 91.5749 212.206 91.3418 211.171 91.3418C210.136 91.3418 209.201 91.5749 208.333 92.0077C207.465 92.4406 206.697 93.1398 206.029 94.0388C205.395 94.9378 204.861 96.0699 204.527 97.4017C204.16 98.7336 203.993 100.265 203.993 102.063H204.026Z"></path><path d="M242.454 87.4129V91.6415H227.33V87.4129H242.454ZM232.271 79.5549H237.58V111.752C237.58 112.851 237.713 113.684 237.98 114.25C238.248 114.816 238.581 115.182 239.015 115.348C239.449 115.515 239.884 115.615 240.351 115.615C240.718 115.615 241.119 115.582 241.553 115.482C241.987 115.382 242.287 115.315 242.454 115.249V119.777C242.054 119.91 241.586 120.043 240.985 120.176C240.384 120.31 239.616 120.376 238.715 120.376C237.58 120.376 236.511 120.11 235.543 119.577C234.575 119.044 233.774 118.145 233.173 116.88C232.572 115.615 232.271 113.917 232.271 111.752V79.5882V79.5549Z"></path></svg></a></div><button class="CybotCookiebotBannerCloseButton" aria-label="[#BANNER_CLOSE#]"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><path d="M14 1.41L12.59 0L7 5.59L1.41 0L0 1.41L5.59 7L0 12.59L1.41 14L7 8.41L12.59 14L14 12.59L8.41 7L14 1.41Z"></path></svg></button></div><div id="CybotCookiebotDialogNav" class="CybotCookiebotScrollAreaSide"><div class="CybotCookiebotFader CybotCookiebotFaderLeft"></div><div class="CybotCookiebotFader CybotCookiebotFaderRight"></div><ul id="CybotCookiebotDialogNavList" class="CybotCookiebotDialogNavItems" role="tablist"><li class="CybotCookiebotDialogNavItem" role="presentation"><a id="CybotCookiebotDialogNavDeclaration" class="CybotCookiebotDialogNavItemLink CybotCookiebotDialogActive" href="#" data-target="CybotCookiebotDialogBody" tabindex="0" role="tab" aria-selected="true" lang="[#LANGUAGE#]">[#CONSENT#]</a></li><li class="CybotCookiebotDialogNavItem" role="presentation"><a id="CybotCookiebotDialogNavDetails" class="CybotCookiebotDialogNavItemLink" href="#" data-target="CybotCookiebotDialogTabContentDetails" tabindex="0" role="tab" aria-selected="false" lang="[#LANGUAGE#]">[#DETAILSTITLE#]</a></li><li id="CybotCookiebotDialogNavItemAdSettings" class="CybotCookiebotDialogNavItem CybotCookiebotDialogHide" role="presentation"><a id="CybotCookiebotDialogNavAdSettings" class="CybotCookiebotDialogNavItemLink" href="#" data-target="CybotCookiebotDialogDetailBodyContentTextIABv2" tabindex="0" role="tab" aria-selected="false" lang="[#LANGUAGE#]">[#IABV2SETTINGS#]</a></li><li class="CybotCookiebotDialogNavItem" role="presentation"><a id="CybotCookiebotDialogNavAbout" class="CybotCookiebotDialogNavItemLink" href="#" data-target="CybotCookiebotDialogDetailBodyContentTextAbout" tabindex="0" role="tab" aria-selected="false" lang="[#LANGUAGE#]">[#ABOUTCOOKIES#]</a></li></ul></div><div id="CybotCookiebotDialogTabContent"><div id="CybotCookiebotDialogBody" class="CybotCookiebotDialogTabPanel" role="tabpanel" aria-labelledby="CybotCookiebotDialogNavDeclaration" lang="[#LANGUAGE#]"><div class="CybotCookiebotScrollContainer"><div id="CybotCookiebotDialogBodyContent" class="CybotCookiebotScrollArea"><div class="CybotCookiebotFader"></div><div id="CybotCookiebotDialogBodyContentTitle" class="CybotCookiebotDialogBodyContentHeading" lang="[#LANGUAGE#]" role="heading" aria-level="1">[#TITLE#]</div><div id="CybotCookiebotDialogBodyContentText" lang="[#LANGUAGE#]">[#TEXT#]</div></div><div class="CybotCookiebotScrollbarContainer"></div></div><div class="CybotCookiebotDialogBodyBottomWrapper"><div id="CybotCookiebotDialogBodyLevelWrapper"><div id="CybotCookiebotDialogBodyLevelButtons"><div id="CybotCookiebotDialogBodyLevelButtonsTable"><div id="CybotCookiebotDialogBodyLevelButtonsRow"><div id="CybotCookiebotDialogBodyLevelButtonsSelectPane"><form><fieldset><legend class="visuallyhidden">[#CONSENT_SELECTION#]</legend><div id="CybotCookiebotDialogBodyFieldsetInnerContainer"><div class="CybotCookiebotDialogBodyLevelButtonWrapper"><label class="CybotCookiebotDialogBodyLevelButtonLabel" for="CybotCookiebotDialogBodyLevelButtonNecessary"><strong class="CybotCookiebotDialogBodyLevelButtonDescription">[#COOKIETYPE_NECESSARY_RAW#]</strong></label><div class="CybotCookiebotDialogBodyLevelButtonSliderWrapper CybotCookiebotDialogBodyLevelButtonSliderWrapperDisabled"><input type="checkbox" id="CybotCookiebotDialogBodyLevelButtonNecessary" class="CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyLevelButtonDisabled" disabled="disabled" checked="checked"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></div></div><div class="CybotCookiebotDialogBodyLevelButtonWrapper"><label class="CybotCookiebotDialogBodyLevelButtonLabel" for="CybotCookiebotDialogBodyLevelButtonPreferences"><strong class="CybotCookiebotDialogBodyLevelButtonDescription">[#COOKIETYPE_PREFERENCE_RAW#]</strong></label><div class="CybotCookiebotDialogBodyLevelButtonSliderWrapper"><input type="checkbox" id="CybotCookiebotDialogBodyLevelButtonPreferences" class="CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyLevelConsentCheckbox" data-target="CybotCookiebotDialogBodyLevelButtonPreferencesInline" checked="checked" tabindex="0"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></div></div><div class="CybotCookiebotDialogBodyLevelButtonWrapper"><label class="CybotCookiebotDialogBodyLevelButtonLabel" for="CybotCookiebotDialogBodyLevelButtonStatistics"><strong class="CybotCookiebotDialogBodyLevelButtonDescription">[#COOKIETYPE_STATISTICS_RAW#]</strong></label><div class="CybotCookiebotDialogBodyLevelButtonSliderWrapper"><input type="checkbox" id="CybotCookiebotDialogBodyLevelButtonStatistics" class="CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyLevelConsentCheckbox" data-target="CybotCookiebotDialogBodyLevelButtonStatisticsInline" checked="checked" tabindex="0"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></div></div><div class="CybotCookiebotDialogBodyLevelButtonWrapper"><label class="CybotCookiebotDialogBodyLevelButtonLabel" for="CybotCookiebotDialogBodyLevelButtonMarketing"><strong class="CybotCookiebotDialogBodyLevelButtonDescription">[#COOKIETYPE_ADVERTISING_RAW#]</strong></label><div class="CybotCookiebotDialogBodyLevelButtonSliderWrapper"><input type="checkbox" id="CybotCookiebotDialogBodyLevelButtonMarketing" class="CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyLevelConsentCheckbox" data-target="CybotCookiebotDialogBodyLevelButtonMarketingInline" checked="checked" tabindex="0"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></div></div></div></fieldset></form></div></div></div></div></div><div id="CybotCookiebotDialogBodyEdgeMoreDetails"><a id="CybotCookiebotDialogBodyEdgeMoreDetailsLink" href="#" class="">[#DETAILS#]</a></div></div></div><div class="CybotCookiebotScrollContainer CybotCookiebotDialogHide"><div id="CybotCookiebotDialogTabContentDetails" class="CybotCookiebotDialogTabPanel CybotCookiebotDialogHide CybotCookiebotScrollArea" role="tabpanel" aria-labelledby="CybotCookiebotDialogNavDetails" lang="[#LANGUAGE#]"><div class="CybotCookiebotFader"></div><div class="CybotCookiebotDialogSROnly" role="heading" aria-level="1">[#DETAILSTITLE#]</div><div id="CybotCookiebotDialogDetailBody"><div id="CybotCookiebotDialogDetailBodyContent"><div id="CybotCookiebotDialogDetailBodyContentTextOverview" lang="[#LANGUAGE#]"><div id="CybotCookiebotDialogDetailBodyContentCookieContainer"><ul id="CybotCookiebotDialogDetailBodyContentCookieContainerTypes"><li class="CookieCard"><div id="CybotCookiebotDialogDetailBodyContentCookieContainerNecessaryCard"><div class="CybotCookiebotDialogDetailBodyContentCookieContainerHeader"><button id="CybotCookiebotDialogDetailBodyContentCookieContainerNecessary" class="CybotCookiebotDialogDetailBodyContentCookieContainerButton CybotCookiebotDialogCollapsed" lang="[#LANGUAGE#]" data-target="CybotCookiebotDialogDetailBodyContentCookieTabsNecessary" aria-label="[#COOKIETYPE_NECESSARY#]" aria-controls="CybotCookiebotDialogDetailBodyContentCookieTabsNecessary" aria-expanded="false"><label for="CybotCookiebotDialogBodyLevelButtonNecessaryInline">[#COOKIETYPE_NECESSARY_TITLE#]</label> <span class="CybotCookiebotDialogDetailBulkConsentCount">[#COOKIETYPE_NECESSARY_COUNT#]</span></button><div class="CybotCookiebotDialogBodyLevelButtonSliderWrapper CybotCookiebotDialogBodyLevelButtonSliderWrapperDisabled"><form><input type="checkbox" id="CybotCookiebotDialogBodyLevelButtonNecessaryInline" class="CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyLevelButtonDisabled" disabled="disabled" checked="checked"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></form></div></div><div class="CybotCookiebotDialogDetailBodyContentCookieTypeIntro">[#COOKIETYPEINTRO_NECESSARY#]</div><div id="CybotCookiebotDialogDetailBodyContentCookieTabsNecessary" class="CollapseCard CybotCookiebotDialogHide" aria-labelledby="CybotCookiebotDialogDetailBodyContentCookieContainerNecessaryCard"><div class="CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer">[#COOKIETABLE_NECESSARY#]</div></div></div></li><li class="CookieCard"><div id="CybotCookiebotDialogDetailBodyContentCookieContainerPreferenceCard"><div class="CybotCookiebotDialogDetailBodyContentCookieContainerHeader"><button id="CybotCookiebotDialogDetailBodyContentCookieContainerPreference" class="CybotCookiebotDialogDetailBodyContentCookieContainerButton CybotCookiebotDialogCollapsed" lang="[#LANGUAGE#]" data-target="CybotCookiebotDialogDetailBodyContentCookieTabsPreference" aria-label="[#COOKIETYPE_PREFERENCE#]" aria-controls="CybotCookiebotDialogDetailBodyContentCookieTabsPreference" aria-expanded="false"><label for="CybotCookiebotDialogBodyLevelButtonPreferencesInline">[#COOKIETYPE_PREFERENCE_TITLE#]</label> <span class="CybotCookiebotDialogDetailBulkConsentCount">[#COOKIETYPE_PREFERENCE_COUNT#]</span></button><div class="CybotCookiebotDialogBodyLevelButtonSliderWrapper"><form><input type="checkbox" id="CybotCookiebotDialogBodyLevelButtonPreferencesInline" class="CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyLevelConsentCheckbox" data-target="CybotCookiebotDialogBodyLevelButtonPreferences" checked="checked" tabindex="0"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></form></div></div><div class="CybotCookiebotDialogDetailBodyContentCookieTypeIntro">[#COOKIETYPEINTRO_PREFERENCE#]</div><div id="CybotCookiebotDialogDetailBodyContentCookieTabsPreference" class="CollapseCard CybotCookiebotDialogHide" aria-labelledby="CybotCookiebotDialogDetailBodyContentCookieContainerPreferenceCard"><div class="CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer">[#COOKIETABLE_PREFERENCE#]</div></div></div></li><li class="CookieCard"><div id="CybotCookiebotDialogDetailBodyContentCookieContainerStatisticsCard"><div class="CybotCookiebotDialogDetailBodyContentCookieContainerHeader"><button id="CybotCookiebotDialogDetailBodyContentCookieContainerStatistics" class="CybotCookiebotDialogDetailBodyContentCookieContainerButton CybotCookiebotDialogCollapsed" lang="[#LANGUAGE#]" data-target="CybotCookiebotDialogDetailBodyContentCookieTabsStatistics" aria-label="[#COOKIETYPE_STATISTICS#]" aria-controls="CybotCookiebotDialogDetailBodyContentCookieTabsStatistics" aria-expanded="false"><label for="CybotCookiebotDialogBodyLevelButtonStatisticsInline">[#COOKIETYPE_STATISTICS_TITLE#]</label> <span class="CybotCookiebotDialogDetailBulkConsentCount">[#COOKIETYPE_STATISTICS_COUNT#]</span></button><div class="CybotCookiebotDialogBodyLevelButtonSliderWrapper"><form><input type="checkbox" id="CybotCookiebotDialogBodyLevelButtonStatisticsInline" class="CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyLevelConsentCheckbox" data-target="CybotCookiebotDialogBodyLevelButtonStatistics" checked="checked" tabindex="0"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></form></div></div><div class="CybotCookiebotDialogDetailBodyContentCookieTypeIntro">[#COOKIETYPEINTRO_STATISTICS#]</div><div id="CybotCookiebotDialogDetailBodyContentCookieTabsStatistics" class="CollapseCard CybotCookiebotDialogHide" aria-labelledby="CybotCookiebotDialogDetailBodyContentCookieContainerStatisticsCard"><div class="CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer">[#COOKIETABLE_STATISTICS#]</div></div></div></li><li class="CookieCard"><div id="CybotCookiebotDialogDetailBodyContentCookieContainerAdvertisingCard"><div class="CybotCookiebotDialogDetailBodyContentCookieContainerHeader"><button id="CybotCookiebotDialogDetailBodyContentCookieContainerAdvertising" class="CybotCookiebotDialogDetailBodyContentCookieContainerButton CybotCookiebotDialogCollapsed" lang="[#LANGUAGE#]" data-target="CybotCookiebotDialogDetailBodyContentCookieTabsAdvertising" aria-label="[#COOKIETYPE_ADVERTISING#]" aria-controls="CybotCookiebotDialogDetailBodyContentCookieTabsAdvertising" aria-expanded="false"><label for="CybotCookiebotDialogBodyLevelButtonMarketingInline">[#COOKIETYPE_ADVERTISING_TITLE#]</label> <span class="CybotCookiebotDialogDetailBulkConsentCount">[#COOKIETYPE_ADVERTISING_COUNT#]</span></button><div class="CybotCookiebotDialogBodyLevelButtonSliderWrapper"><form><input type="checkbox" id="CybotCookiebotDialogBodyLevelButtonMarketingInline" class="CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyLevelConsentCheckbox" data-target="CybotCookiebotDialogBodyLevelButtonMarketing" checked="checked" tabindex="0"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></form></div></div><div class="CybotCookiebotDialogDetailBodyContentCookieTypeIntro">[#COOKIETYPEINTRO_ADVERTISING#]</div><div id="CybotCookiebotDialogDetailBodyContentCookieTabsAdvertising" class="CollapseCard CybotCookiebotDialogHide" aria-labelledby="CybotCookiebotDialogDetailBodyContentCookieContainerAdvertisingCard"><div class="CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer">[#COOKIETABLE_ADVERTISING#]</div></div></div></li><li class="CookieCard"><div id="CybotCookiebotDialogDetailBodyContentCookieContainerUnclassifiedCard"><button id="CybotCookiebotDialogDetailBodyContentCookieContainerUnclassified" class="CybotCookiebotDialogDetailBodyContentCookieContainerButton CybotCookiebotDialogCollapsed" lang="[#LANGUAGE#]" data-target="CybotCookiebotDialogDetailBodyContentCookieTabsUnclassified" aria-label="[#COOKIETYPE_UNCLASSIFIED#]" aria-controls="CybotCookiebotDialogDetailBodyContentCookieTabsUnclassified" aria-expanded="false">[#COOKIETYPE_UNCLASSIFIED_TITLE#] <span class="CybotCookiebotDialogDetailBulkConsentCount">[#COOKIETYPE_UNCLASSIFIED_COUNT#]</span></button><div class="CybotCookiebotDialogDetailBodyContentCookieTypeIntro">[#COOKIETYPEINTRO_UNCLASSIFIED#]</div></div><div id="CybotCookiebotDialogDetailBodyContentCookieTabsUnclassified" class="CollapseCard CybotCookiebotDialogHide" aria-labelledby="CybotCookiebotDialogDetailBodyContentCookieContainerUnclassifiedCard" aria-expanded="false"><div class="CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer">[#COOKIETABLE_UNCLASSIFIED#]</div></div></li></ul></div></div></div><div id="CybotCookiebotDialogDetailBulkConsent" lang="[#LANGUAGE#]"><a id="CybotCookiebotDialogDetailBulkConsentLink" href="#" class="CybotExpandLink CybotCookiebotDialogCollapsed" data-target="CybotCookiebotDialogDetailBulkConsentListWrapper">[#BULK_CONSENT_HEADER#]<span class="CybotCookiebotDialogDetailBulkConsentCount">[#BULK_CONSENT_DOMAINS_COUNT#]</span></a> [#BULK_CONSENT_TITLE#]<div id="CybotCookiebotDialogDetailBulkConsentListWrapper" class="CybotCookiebotDialogHide" aria-expanded="false"><span>[#BULK_CONSENT_LIST#]</span> [#BULK_CONSENT_DOMAINS#]</div></div><div id="CybotCookiebotDialogDetailFooter" lang="[#LANGUAGE#]">[#LASTUPDATED#]</div></div></div><div class="CybotCookiebotScrollbarContainer"></div></div><div class="CybotCookiebotScrollContainer CybotCookiebotDialogHide"><div id="CybotCookiebotDialogDetailBodyContentTextIABv2" class="CybotCookiebotDialogTabPanel CybotCookiebotDialogHide CybotCookiebotScrollArea" role="tabpanel" aria-labelledby="CybotCookiebotDialogNavAdSettings" lang="[#LANGUAGE#]"><div class="CybotCookiebotFader"></div><div id="CybotCookiebotDialogDetailBodyContentIABContainer"><div id="CybotCookiebotDialogDetailBodyContentIABv2Tabs"><div class="CybotCookiebotDialogDetailBodyContentIABv2TabsIntro"><div class="CybotCookiebotDialogBodyContentHeading" role="heading" aria-level="1">[#IABV2_TITLE#]</div>[#IABV2_BODY_INTRO#]</div><div class="CybotCookiebotDialogDetailBodyContentIABv2TabsIntro">[#IABV2_BODY_LEGITIMATE_INTEREST_INTRO#]</div><div class="CybotCookiebotDialogDetailBodyContentIABv2TabsIntro">[#IABV2_BODY_PREFERENCE_INTRO#]</div><div class="CookieCard"><div id="CybotCookiebotDialogDetailBodyContentIABv2PurposesCard"><button id="CybotCookiebotDialogDetailBodyContentIABv2Purposes" class="CybotCookiebotDialogDetailBodyContentIABv2Tab CybotCookiebotDialogCollapsed" tabindex="0" data-target="CybotCookiebotDialogDetailBodyContentIABv2PurposesBody" lang="[#LANGUAGE#]" aria-label="[#IABV2_LABEL_PURPOSES_ARIA_LABEL#]" aria-controls="CybotCookiebotDialogDetailBodyContentIABv2PurposesBody">[#IABV2_LABEL_PURPOSES#]</button><div class="CybotCookiebotDialogDetailBodyContentIABv2CardIntro">[#IABV2_BODY_PURPOSES_INTRO#]</div></div><div id="CybotCookiebotDialogDetailBodyContentIABv2PurposesBody" class="CollapseCard CybotCookiebotDialogHide" aria-labelledby="CybotCookiebotDialogDetailBodyContentIABv2PurposesCard" aria-expanded="false">[#IABV2_BODY_PURPOSES#]</div></div><div class="CookieCard"><div id="CybotCookiebotDialogDetailBodyContentIABv2FeaturesCard"><button id="CybotCookiebotDialogDetailBodyContentIABv2Features" class="CybotCookiebotDialogDetailBodyContentIABv2Tab CybotCookiebotDialogCollapsed" tabindex="0" data-target="CybotCookiebotDialogDetailBodyContentIABv2FeaturesBody" lang="[#LANGUAGE#]" aria-label="[#IABV2_LABEL_FEATURES_ARIA_LABEL#]" aria-controls="CybotCookiebotDialogDetailBodyContentIABv2FeaturesBody">[#IABV2_LABEL_FEATURES#]</button><div class="CybotCookiebotDialogDetailBodyContentIABv2CardIntro">[#IABV2_BODY_FEATURES_INTRO#]</div></div><div id="CybotCookiebotDialogDetailBodyContentIABv2FeaturesBody" class="CollapseCard CybotCookiebotDialogHide" aria-labelledby="CybotCookiebotDialogDetailBodyContentIABv2FeaturesCard" aria-expanded="false">[#IABV2_BODY_FEATURES#]</div></div><div class="CookieCard"><div id="CybotCookiebotDialogDetailBodyContentIABv2PartnersCard"><button id="CybotCookiebotDialogDetailBodyContentIABv2Partners" class="CybotCookiebotDialogDetailBodyContentIABv2Tab CybotCookiebotDialogCollapsed" tabindex="0" data-target="CybotCookiebotDialogDetailBodyContentIABv2PartnersBody" lang="[#LANGUAGE#]" aria-label="[#IABV2_LABEL_PARTNERS_ARIA_LABEL#]" aria-controls="CybotCookiebotDialogDetailBodyContentIABv2PartnersBody">[#IABV2_LABEL_PARTNERS#]</button><div class="CybotCookiebotDialogDetailBodyContentIABv2CardIntro">[#IABV2_BODY_PARTNERS_INTRO#]</div></div><div id="CybotCookiebotDialogDetailBodyContentIABv2PartnersBody" class="CollapseCard CybotCookiebotDialogHide" aria-labelledby="CybotCookiebotDialogDetailBodyContentIABv2PartnersCard" aria-expanded="false">[#IABV2_BODY_PARTNERS#]</div></div></div></div></div><div class="CybotCookiebotScrollbarContainer"></div></div><div class="CybotCookiebotScrollContainer CybotCookiebotDialogHide"><div id="CybotCookiebotDialogDetailBodyContentTextAbout" class="CybotCookiebotDialogTabPanel CybotCookiebotDialogHide CybotCookiebotScrollArea" role="tabpanel" aria-labelledby="CybotCookiebotDialogNavAbout" lang="[#LANGUAGE#]"><div class="CybotCookiebotDialogSROnly" role="heading" aria-level="1">[#ABOUTCOOKIES#]</div><div class="CybotCookiebotFader"></div>[#COOKIESGENERALINTRO#]</div><div class="CybotCookiebotScrollbarContainer"></div></div></div><div id="CybotCookiebotDialogFooter" class="CybotCookiebotScrollContainer"><div class="CybotCookiebotScrollArea"><div id="CybotCookiebotDialogBodyButtons"><div class="CybotCookiebotDialogBodyLevelButtonWrapper CybotCookiebotDialogBodyContentControlsWrapper CybotCookiebotDialogHide"><form class="CybotCookiebotDialogBodyLevelButtonSliderWrapper"><input type="checkbox" id="CybotCookiebotDialogBodyContentCheckboxPersonalInformation" class="CybotCookiebotDialogBodyLevelButton"> <span class="CybotCookiebotDialogBodyLevelButtonSlider"></span></form><label class="CybotCookiebotDialogBodyLevelButtonLabel" for="CybotCookiebotDialogBodyContentCheckboxPersonalInformation"><strong class="CybotCookiebotDialogBodyLevelButtonDescription">[#OOI_PERSONAL_INFORMATION#]</strong></label></div><div id="CybotCookiebotDialogBodyButtonsWrapper"><button id="CybotCookiebotDialogBodyButtonDecline" class="CybotCookiebotDialogBodyButton CybotCookiebotDialogHide" tabindex="0" lang="[#LANGUAGE#]">[#DECLINE#]</button> <button id="CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection" class="CybotCookiebotDialogBodyButton CybotCookiebotDialogHide" tabindex="0" lang="[#LANGUAGE#]">[#LEVELOPTIN_ALLOW_SELECTION#]</button> <button id="CybotCookiebotDialogBodyLevelButtonCustomize" class="CybotCookiebotDialogBodyButton CybotCookiebotDialogHide" tabindex="0" lang="[#LANGUAGE#]">[#CUSTOMIZE#]<div class="CybotCookiebotDialogArrow"></div></button> <button id="CybotCookiebotDialogBodyButtonAccept" class="CybotCookiebotDialogBodyButton CybotCookiebotDialogHide" tabindex="0" lang="[#LANGUAGE#]">[#ACCEPT#]</button></div></div></div><div class="CybotCookiebotScrollbarContainer"></div></div><button id="CybotCookiebotBannerCloseButtonE2E" class="CybotCookiebotBannerCloseButton" aria-label="[#BANNER_CLOSE#]"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14"><path d="M14 1.41L12.59 0L7 5.59L1.41 0L0 1.41L5.59 7L0 12.59L1.41 14L7 8.41L12.59 14L14 12.59L8.41 7L14 1.41Z"></path></svg></button></div></div>';
    this.addStyle('bottom-v2', '#CybotCookiebotDialog *,#CybotCookiebotDialogBodyUnderlay *{background:transparent;box-sizing:border-box;color:inherit;font-family:inherit;font-size:15px;margin:0;outline:0;padding:0;vertical-align:baseline}#CybotCookiebotDialog #CybotCookiebotDialogNav :after,#CybotCookiebotDialog #CybotCookiebotDialogNav :before{content:none}#CybotCookiebotDialog label{width:auto}#CybotCookiebotDialogBodyUnderlay{background-color:#000;height:100%;left:0;margin:0;opacity:0;overflow:hidden;padding:0;pointer-events:none;position:fixed;top:0;transition:opacity .5s ease;width:100%;z-index:2147483630}#CybotCookiebotDialog.CybotCookiebotDialogActive+#CybotCookiebotDialogBodyUnderlay{opacity:.75;pointer-events:auto}#CybotCookiebotDialog{background-color:#000001;border-radius:8px;box-shadow:0 32px 68px rgba(0,0,0,.3);box-sizing:border-box;color:#000002;font-family:sans-serif;font-size:15px;height:auto;left:50%;letter-spacing:.1px;line-height:24px;max-height:calc(100% - 16px);overflow:hidden;position:fixed;text-align:initial;top:50%;transform:translate(-50%,-50%);transition:all .5s ease;transition-property:width,max-width,top,bottom,left,opacity;width:calc(100% - 16px);z-index:2147483631}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl{max-height:calc(100vh - 10px);width:calc(100vw - 10px)}#CybotCookiebotDialog ol,#CybotCookiebotDialog ul{list-style-position:inside}#CybotCookiebotDialog .CybotCookiebotDialogContentWrapper{align-items:flex-start;display:flex;flex-direction:column;width:100%}#CybotCookiebotDialog .CybotCookiebotDialogSROnly{clip:rect(0,0,0,0);border:0;height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}:root #CybotCookiebotDialog,:root #CybotCookiebotDialog #CybotCookiebotDialogTabContent,_:-ms-fullscreen{height:100%}:root #CybotCookiebotDialogBody,:root #CybotCookiebotDialogTabContent .CybotCookiebotDialogTabPanel,_:-ms-fullscreen{flex:auto}@media screen and (min-width:601px){#CybotCookiebotDialog{max-width:900px}}@media screen and (min-width:1280px){#CybotCookiebotDialog{left:50%;max-height:80vh;top:0;transform:translate(-50%)}#CybotCookiebotDialog.CybotEdge{box-shadow:0 30px 70px rgba(0,0,0,.3);height:auto;max-height:70vh;max-width:100vw;min-width:100vw;padding:24px;transition-property:transform,opacity,top;width:100vw}#CybotCookiebotDialog.CybotEdge .CybotCookiebotDialogContentWrapper{flex-direction:row;margin:0 auto;max-width:1600px;position:relative}#CybotCookiebotDialog[data-template=bottom]{top:100%;transform:translate(-50%,-100%)}#CybotCookiebotDialog[data-template=pushdown],#CybotCookiebotDialog[data-template=slidedown]{transform:translate(-50%,-150%)}#CybotCookiebotDialog[data-template=pushdown].CybotCookiebotDialogActive,#CybotCookiebotDialog[data-template=slidedown].CybotCookiebotDialogActive{transform:translate(-50%)}#CybotCookiebotDialog[data-template=slideup]{top:100%;transform:translate(-50%,50%)}#CybotCookiebotDialog[data-template=slideup].CybotCookiebotDialogActive{transform:translate(-50%,-100%)}#CybotCookiebotDialog[data-template=overlay],#CybotCookiebotDialog[data-template=popup]{opacity:0;top:50%;transform:translate(-50%,-50%)}#CybotCookiebotDialog[data-template=overlay].CybotCookiebotDialogActive,#CybotCookiebotDialog[data-template=popup].CybotCookiebotDialogActive{opacity:1}}#CybotCookiebotDialogHeader{align-items:center;border-bottom:1px solid #000004;display:flex;padding:1em;width:100%}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogHeader{padding:.5em 1em}#CybotCookiebotDialogHeaderLogosWrapper{align-items:center;display:flex;flex:1;justify-content:space-between}#CybotCookiebotDialogPoweredbyCybot,#CybotCookiebotDialogPoweredbyLink{align-items:center;display:flex;width:50%}#CybotCookiebotDialogPoweredbyCybot{justify-content:flex-end;width:175px}#CybotCookiebotDialogPoweredbyImage{max-height:1.5em;width:auto}#CybotCookiebotDialogPoweredbyCybot svg{fill:#000020;height:1.7em;max-width:133px}@media screen and (min-width:601px){#CybotCookiebotDialogPoweredbyCybot svg{height:2em}}@media screen and (min-width:1280px){#CybotCookiebotDialogHeader{padding:1.5em}#CybotCookiebotDialogPoweredbyImage{max-height:2.125em}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogHeader{align-items:center;align-self:stretch;border:none;justify-content:space-between;padding:0;width:210px}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogHeaderLogosWrapper{align-self:stretch;flex-direction:column}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogPoweredbyLink{flex:1}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogPoweredbyImage{height:auto;max-height:6em;max-width:100%}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogPoweredbyCybot{height:2em;margin-top:2em}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogPoweredbyCybot,#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogPoweredbyLink{justify-content:center}}#CybotCookiebotDialogNav{border-bottom:1px solid #000004;position:relative;width:100%}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogNav{display:none}#CybotCookiebotDialogNav .CybotCookiebotDialogNavItems{display:flex;list-style:none;overflow-x:auto}#CybotCookiebotDialogNav .CybotCookiebotDialogNavItems::-webkit-scrollbar{height:0;width:0}#CybotCookiebotDialogNav .CybotCookiebotDialogNavItem{flex:1 1 0%;margin:0 auto}#CybotCookiebotDialogNav .CybotCookiebotDialogNavItemLink{border-bottom:1px solid #000001;color:#000002;display:block;font-weight:600;height:100%;outline-offset:-5px;padding:1em;text-align:center;text-decoration:none;white-space:nowrap}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogNav .CybotCookiebotDialogNavItemLink{padding:.5em}#CybotCookiebotDialogNav .CybotCookiebotDialogNavItemLink:hover{color:#000003}#CybotCookiebotDialogNav .CybotCookiebotDialogNavItemLink.CybotCookiebotDialogActive{border-color:transparent;border-bottom:1px solid #000003;color:#000003}@media screen and (min-width:1280px){#CybotCookiebotDialogNav .CybotCookiebotDialogNavItemLink.CybotCookiebotDialogActive{border-width:3px}}#CybotCookiebotDialogTabContent{display:flex;flex-direction:column;height:auto;min-height:60px;overflow:auto;width:100%}#CybotCookiebotDialogTabContent .CybotCookiebotScrollContainer{display:flex;flex:1;flex-direction:column}#CybotCookiebotDialogTabContent .CybotCookiebotDialogTabPanel{flex:1;overflow-x:hidden;overflow-y:auto;width:100%}#CybotCookiebotDialogSpecialFeaturesText ul{margin:.25em 0 .25em 2em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogSpecialFeaturesText ul{margin:.25em 2em .25em 0}#CybotCookiebotDialog .CybotCookiebotScrollContainer{border-bottom:1px solid #000004;height:100%;padding:.375em;position:relative}#CybotCookiebotDialog .CybotCookiebotScrollArea{height:100%}#CybotCookiebotDialog .CybotCookiebotDialogBodyBottomWrapper{width:100%}@media screen and (min-width:601px){#CybotCookiebotDialog .CybotCookiebotScrollContainer{display:flex;min-height:auto}}@media screen and (min-width:1280px){#CybotCookiebotDialog.CybotEdge .CybotCookiebotScrollContainer{border-bottom:none;display:none}#CybotCookiebotDialog.CybotEdge.CybotMultilevel .CybotCookiebotScrollContainer{width:calc(100% - 286px - 1.5em)}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogTabContent{flex:1;margin-left:1.5em;overflow:visible}#CybotCookiebotDialog.CybotEdge[dir=rtl] #CybotCookiebotDialogTabContent{margin-left:0;margin-right:1.5em}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogTabContent .CybotCookiebotDialogTabPanel{overflow:visible}#CybotCookiebotDialog.CybotEdge .CybotCookiebotDialogBodyBottomWrapper{align-items:flex-end;display:flex;flex-wrap:wrap;justify-content:flex-start;margin-top:1.5em;padding-left:.375em}#CybotCookiebotDialog.CybotEdge[dir=rtl] .CybotCookiebotDialogBodyBottomWrapper{padding-left:0;padding-right:.375em}#CybotCookiebotDialog.CybotEdge.CybotMultilevel .CybotCookiebotDialogBodyBottomWrapper{border-top:1px solid #000004;padding-top:1em}}@media screen and (min-width:1510px){#CybotCookiebotDialog.CybotEdge:not([lang=ta]):not([lang=bg]):not([lang=is]):not([lang=el]) #CybotCookiebotDialogTabContent{margin:0 1.5em}#CybotCookiebotDialog.CybotEdge:not([lang=ta]):not([lang=bg]):not([lang=is]):not([lang=el]) .CybotCookiebotScrollContainer{width:auto}#CybotCookiebotDialog.CybotEdge:not([lang=ta]):not([lang=bg]):not([lang=is]):not([lang=el]) .CybotCookiebotDialogBodyBottomWrapper{border-top:none;padding-top:0}}#CybotCookiebotDialog .CybotCookiebotFader{bottom:0;height:5em;left:1px;opacity:0;pointer-events:none;position:absolute;transition:opacity .3s;width:calc(100% - 1em);z-index:10}#CybotCookiebotDialog .CybotCookiebotFader:not(.CybotCookiebotFaderRight):not(.CybotCookiebotFaderLeft){max-height:50%}#CybotCookiebotDialog[dir=rtl] .CybotCookiebotFader:not(.CybotCookiebotFaderLeft){left:auto;right:1px}#CybotCookiebotDialog .CybotCookiebotFader.CybotCookiebotDialogActive{opacity:1}#CybotCookiebotDialog .CybotCookiebotFaderLeft,#CybotCookiebotDialog .CybotCookiebotFaderRight{height:100%;width:3.5em}#CybotCookiebotDialog .CybotCookiebotFaderLeft{left:0}#CybotCookiebotDialog .CybotCookiebotFaderRight{left:auto;right:0}#CybotCookiebotDialog .CybotCookiebotFader:not(.CybotCookiebotFaderLeft):not(.CybotCookiebotFaderRight){max-height:30%}@media screen and (min-width:1280px){#CybotCookiebotDialog .CybotCookiebotFader:not(.CybotCookiebotFaderLeft):not(.CybotCookiebotFaderRight){width:calc(100% - 1.5em)}}#CybotCookiebotDialogBody{display:flex;flex-direction:column;height:100%}#CybotCookiebotDialogBody .CybotCookiebotScrollContainer{display:flex;flex-direction:column;max-height:18em}#CybotCookiebotDialog #CybotCookiebotDialogBodyContent{max-height:inherit}#CybotCookiebotDialog .CybotCookiebotDialogBodyContentHeading{font-weight:600;letter-spacing:.25px;line-height:1.6em;margin-bottom:.5em}#CybotCookiebotDialogBodyContent{flex:1;height:100%;letter-spacing:.5px;line-height:1.6em;max-height:100%;overflow-x:hidden;padding:1.625em .625em}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogBodyContent{padding:.8em}#CybotCookiebotDialog .CybotCookiebotDialogDetailBodyContentCookieTabContent{list-style-type:none}#CybotCookiebotDialogDetailBulkConsent{border:1px solid #000004;border-radius:.5em;margin:0 .625em 1em;padding:1em}#CybotCookiebotDialogDetailBulkConsent:before{border-top:1px solid #000004;content:"";width:100%}#CybotCookiebotDialogDetailBulkConsentLink{color:#000002;display:block;font-weight:600;line-height:1.6em;margin-bottom:.625em;text-decoration:none}#CybotCookiebotDialogDetailBulkConsentLink:hover{color:#000003}#CybotCookiebotDialogTabContent .CybotCookiebotDialogDetailBulkConsentCount{background-color:#000004;border-radius:5em;display:inline-block;font-size:.8em;font-weight:700;letter-spacing:.25px;line-height:1.2em;margin-left:.5em;padding:.25em .5em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogTabContent .CybotCookiebotDialogDetailBulkConsentCount{margin-left:0;margin-right:.5em}#CybotCookiebotDialogDetailBulkConsentListWrapper{background-color:#000016;border:1px solid #000004;border-radius:.5em;margin-top:1.5em;padding:1em}#CybotCookiebotDialogDetailBulkConsentListWrapper>span{border-bottom:1px solid #000004;display:block;font-weight:600;padding-bottom:1em}#CybotCookiebotDialogDetailBulkConsentList{margin-top:1em}#CybotCookiebotDialogDetailFooter{letter-spacing:.3px;line-height:1.6em;padding:0 1em 1em}#CybotCookiebotDialogDetailFooter a{color:#000002}#CybotCookiebotDialogDetailBulkConsentList dt:not(:last-of-type){margin-bottom:.5em}@media screen and (min-width:1280px){#CybotCookiebotDialog #CybotCookiebotDialogBody .CybotCookiebotScrollContainer{display:flex;flex:auto;height:auto;max-height:15.5em;overflow:hidden}#CybotCookiebotDialogBodyContent{padding:1.125em}#CybotCookiebotDialogDetailBulkConsent{margin:0 2em 1em;padding:1.5em}#CybotCookiebotDialogDetailFooter{padding:0 2em 1.125em}#CybotCookiebotDialogDetailBulkConsentListWrapper{margin-top:2em;padding:1.5em}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBody{display:flex;justify-content:space-between;overflow:hidden}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyContent{height:auto;padding:0 1.125em 0 0}#CybotCookiebotDialog[dir=rtl].CybotEdge #CybotCookiebotDialogBodyContent{padding-left:1.125em;padding-right:0}}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeader{font-weight:600;line-height:1.6em;margin-bottom:1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABWrapper{border:2px solid #000004;border-radius:1em;margin:1.5em 0 1em;padding:1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABWrapper:last-of-type{margin-bottom:0}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainer,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed{background-color:#000016;border:2px solid #000004;border-radius:1em;margin-bottom:.5em;padding:.5em 1em 1em;position:relative}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainer:last-of-type,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed:last-of-type{margin-bottom:0}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonWrapper{align-items:center;display:flex;font-weight:600;margin:.5em 2em 0 0}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonWrapper{margin:.5em 0 0 2em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonWrapper:nth-of-type(2){margin-right:0}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonWrapper:nth-of-type(2){margin-left:0;margin-right:0}#CybotCookiebotDialogDetailBodyContentIABv2Tabs #CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonWrapper:nth-of-type(2){margin-right:3.5em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs #CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonWrapper:nth-of-type(2){margin-left:3.5em;margin-right:0}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription{border-top:1px solid #000004;margin-top:1em;padding-top:1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABPurposeCount{margin-top:2em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABPurposeCount .CybotCookiebotDialogDetailBulkConsentCount{margin-left:.4em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABLinkWrapper{font-weight:700}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABLinkWrapper:nth-of-type(2){margin-top:1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABLinkWrapper a{margin-top:0;word-break:break-word}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription a{align-items:center;display:inline-flex;margin-top:.5em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription .CybotCookiebotDialogBodyLevelButtonIABBullet{margin:1em 0 0 1em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription .CybotCookiebotDialogBodyLevelButtonIABBullet{margin:1em 1em 0 0}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription .CybotCookiebotDialogBodyLevelButtonIABList{font-weight:700;margin-top:1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription .CybotCookiebotDialogBodyLevelButtonIABList li{font-weight:400;margin-left:2px}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription .CybotCookiebotDialogBodyLevelButtonIABList li{font-weight:400;margin-right:2px}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed .CybotCookiebotDialogBodyLevelButtonIABDescription{display:none}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainer .CybotCookiebotDialogBodyLevelButtonIABDescription,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription.CybotCookiebotDialogShow{display:block}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow{display:block;height:2em;position:absolute;right:1.35em;top:.75em;width:2em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide,#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow{left:1.35em;right:auto}#CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonIABContainer:before,#CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed:before{border-style:solid;border-width:.15em .15em 0 0;content:"";display:inline-block;height:.5em;position:absolute;right:2em;top:1.3em;transform:rotate(-225deg);width:.5em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonIABContainer:before,#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed:before{left:2em;right:auto}#CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonIABContainer:before{top:1.6em;transform:rotate(-45deg)}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyIABIntroContainer{padding-bottom:1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABLabel{line-height:1.5em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs p.CybotCookiebotDialogBodyLevelButtonIABLabel{padding-left:2em}@media screen and (min-width:1280px){#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABWrapper{padding:1.5em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeader{align-items:center;border-bottom:1px solid #000004;display:flex;margin-bottom:1.5em;padding-bottom:1.5em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyIABIntroContainer{padding-bottom:1.5em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerTogglesWrapper{align-items:center;display:flex;justify-content:space-between;width:100%}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainer,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed{padding:1em 1.5em 1.5em}#CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonIABContainer:before,#CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonIABContainerCollapsed:before{top:1.8em}#CybotCookiebotDialogDetailBodyContentIABv2PartnersBody .CybotCookiebotDialogBodyLevelButtonIABContainer:before{top:2.1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABDescription{width:100%}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow{top:1.2em}}#CybotCookiebotDialogDetailBodyContentTextAbout{padding:1.625em .625em}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogDetailBodyContentTextAbout{padding:.5em}@media screen and (min-width:1280px){#CybotCookiebotDialogDetailBodyContentTextAbout{padding:1.125em}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogDetailBodyContentTextAbout{padding:.5em}}#CybotCookiebotDialogFooter.CybotCookiebotScrollContainer{height:auto;min-height:80px;width:100%}#CybotCookiebotDialogFooter .CybotCookiebotScrollArea{padding:1em;width:100%}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter .CybotCookiebotScrollArea{padding:.5em}#CybotCookiebotDialog:not(.CybotCookiebotDialogZoomedLg):not(.CybotCookiebotDialogZoomedXl) #CybotCookiebotDialogFooter.CybotCookiebotScrollContainer{min-height:auto;padding:0}#CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter .CybotCookiebotScrollArea,#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter .CybotCookiebotScrollArea{overflow:auto}#CybotCookiebotDialogBodyButtons{align-items:flex-start;display:flex;flex-direction:column;flex-wrap:wrap}@media screen and (min-width:601px){#CybotCookiebotDialogBodyButtons{align-items:center;flex-direction:row}}@media screen and (min-width:1280px){#CybotCookiebotDialogFooter .CybotCookiebotScrollArea{padding:1em 1.5em 1.5em}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter{display:block;padding:0;width:auto}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotScrollArea{padding:0}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotScrollbarContainer{display:none}#CybotCookiebotDialog.CybotEdge.CybotMultilevel #CybotCookiebotDialogFooter{position:absolute;right:0;top:0}#CybotCookiebotDialog.CybotEdge[dir=rtl] #CybotCookiebotDialogFooter{left:0;right:auto}#CybotCookiebotDialog.CybotEdge.CybotMultilevel.CybotCloseButtonEnabled #CybotCookiebotDialogFooter{right:51px}#CybotCookiebotDialog.CybotEdge[dir=rtl].CybotCloseButtonEnabled #CybotCookiebotDialogFooter{left:51px;right:auto}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyButtons{align-items:flex-end;flex-direction:column-reverse;max-width:286px}}@media screen and (min-width:1510px){#CybotCookiebotDialog.CybotEdge:not([lang=ta]):not([lang=bg]):not([lang=is]):not([lang=el]) #CybotCookiebotDialogFooter{position:relative;right:0}#CybotCookiebotDialog.CybotEdge[dir=rtl]:not([lang=ta]):not([lang=bg]):not([lang=is]):not([lang=el]) #CybotCookiebotDialogFooter{left:0;position:relative;right:auto}}#CybotCookiebotDialog .CybotCookiebotScrollContainer>div:first-of-type::-webkit-scrollbar,#CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter>div:first-of-type::-webkit-scrollbar,#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter>div:first-of-type::-webkit-scrollbar{width:.25em}#CybotCookiebotDialog .CybotCookiebotScrollContainer>div:first-of-type::-webkit-scrollbar-track,#CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter>div:first-of-type::-webkit-scrollbar-track,#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter>div:first-of-type::-webkit-scrollbar-track{background:#000018;border-radius:.313em}#CybotCookiebotDialog .CybotCookiebotScrollContainer>div:first-of-type::-webkit-scrollbar-thumb,#CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter>div:first-of-type::-webkit-scrollbar-thumb,#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter>div:first-of-type::-webkit-scrollbar-thumb{background:#000019;border-radius:.313em}#CybotCookiebotDialog .CybotCookiebotScrollContainer .CybotCookiebotScrollbarContainer{background:#000001;display:none;height:100%;pointer-events:none;position:absolute;right:.375em;top:0;transition:opacity .5s;width:.6em}#CybotCookiebotDialog:hover .CybotCookiebotScrollContainer .CybotCookiebotScrollbarContainer{opacity:0}#CybotCookiebotDialog .CybotCookiebotScrollContainer>div:first-of-type:focus{outline:none}#CybotCookiebotDialog .CybotCookiebotScrollContainer>div:first-of-type:focus::-webkit-scrollbar-thumb,#CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter>div:first-of-type:focus::-webkit-scrollbar-thumb,#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter>div:first-of-type:focus::-webkit-scrollbar-thumb{background:#000006}@-moz-document url-prefix(){#CybotCookiebotDialog .CybotCookiebotScrollContainer>div:first-of-type,#CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter>div:first-of-type,#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter>div:first-of-type{scrollbar-track-color:#000018;scrollbar-face-color:#000019;scrollbar-color:#000019 #000018;scrollbar-width:thin}}#CybotCookiebotDialog .CybotCookiebotScrollContainer>div:first-of-type:focus,#CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter>div:first-of-type:focus,#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter>div:first-of-type:focus{scrollbar-color:#000006 #000018}@media screen and (min-width:1510px){#CybotCookiebotDialog .CybotCookiebotScrollContainer>div:first-of-type::-webkit-scrollbar,#CybotCookiebotDialog.CybotCookiebotDialogZoomedLg #CybotCookiebotDialogFooter>div:first-of-type::-webkit-scrollbar,#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogFooter>div:first-of-type::-webkit-scrollbar{width:.5em}#CybotCookiebotDialog .CybotCookiebotScrollContainer .CybotCookiebotScrollbarContainer{display:block}}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABContainerToggleHide,#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABContainerToggleShow,#CybotCookiebotDialog a:after,#CybotCookiebotDialog a:before,#CybotCookiebotDialog button:after,#CybotCookiebotDialog button:before{border-color:#000002}#CybotCookiebotDialog a:hover:after,#CybotCookiebotDialog a:hover:before,#CybotCookiebotDialog button:hover:after,#CybotCookiebotDialog button:hover:before{border-color:#000003}#CybotCookiebotDialog #CybotCookiebotBannerCloseButtonE2E,#CybotCookiebotDialog .CybotCookiebotBannerCloseButton{fill:#000002;border:none;display:none}#CybotCookiebotDialog.CybotCloseButtonEnabled .CybotCookiebotBannerCloseButton{display:flex;margin-left:2.313rem}#CybotCookiebotDialog[dir=rtl] .CybotCookiebotBannerCloseButton{margin-left:auto;margin-right:2.313rem}#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtonsWrapper{display:flex;flex-direction:column;width:100%}#CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyButton:not(:first-of-type),#CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:not(:first-of-type){margin-top:.5em}#CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyContentControlsWrapper{align-items:center;display:flex;margin-bottom:.5em}#CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyContentControlsWrapper .CybotCookiebotDialogBodyLevelButtonSliderWrapper{margin-right:1em}#CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyContentControlsWrapper .CybotCookiebotDialogBodyLevelButtonDescription{font-weight:600}#CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton{background-color:#000013;border:2px solid #000014;border-radius:.25em;color:#000015;display:block;font-weight:600;padding:1em;text-align:center;user-select:none;width:100%}#CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:hover{opacity:.85}#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyLevelButtonCustomize,#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyLevelButtonLevelOptinAllowallSelection{background-color:#000009;border-color:#000010;color:#000012}#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtonAccept,#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyLevelButtonAccept,#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll{background-color:#000005;border-color:#000006;color:#000008}#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyLevelButtonCustomize{align-items:center}#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyLevelButtonCustomize .CybotCookiebotDialogArrow{border-color:#000012;border-style:solid;border-width:.15em .15em 0 0;display:inline-block;height:.5em;margin-left:1em;transform:rotate(45deg);vertical-align:baseline;width:.5em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogFooter #CybotCookiebotDialogBodyLevelButtonCustomize .CybotCookiebotDialogArrow{margin-left:0;margin-right:1em;transform:rotate(-135deg)}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggle{border-bottom:1px solid #000004;display:flex;flex-wrap:wrap;justify-content:flex-end;margin:1em 0 1.5em auto;padding-bottom:1.5em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderButton,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectVendorsLink,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectVendorsLink{align-items:center;background-color:#000013;border:2px solid #000014;border-radius:.25em;color:#000015;display:flex;font-weight:600;padding:.75em 1em;text-decoration:none;user-select:none}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderButton:hover,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectVendorsLink:hover,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectVendorsLink:hover{opacity:.85}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderButton.select,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectVendorsLink{background-color:#000005;border-color:#000006;color:#000008;margin-left:.5em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderButton.select,#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectVendorsLink{margin-left:0;margin-right:.5em}@media screen and (min-width:601px){#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtonsWrapper{align-items:stretch;flex:1;flex-direction:row;justify-content:flex-end}#CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyButton:not(:first-of-type),#CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton,#CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:not(:first-of-type){margin-top:0;width:33%}#CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyContentControlsWrapper:not(.CybotCookiebotDialogHide)+#CybotCookiebotDialogBodyButtonsWrapper .CybotCookiebotDialogBodyButton{max-width:286px;width:100%}#CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyButton:not(:last-of-type){margin-right:.5em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:not(:last-of-type){margin-left:.5em;margin-right:0}#CybotCookiebotDialogBodyButtons .CybotCookiebotDialogBodyContentControlsWrapper{margin-bottom:0;margin-right:1em}}@media screen and (min-width:1280px){#CybotCookiebotDialog.CybotEdge .CybotCookiebotBannerCloseButton{display:none}#CybotCookiebotDialog.CybotEdge.CybotCloseButtonEnabled #CybotCookiebotBannerCloseButtonE2E{display:flex}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggle{border-bottom:none;justify-content:flex-start;margin:0 0 0 auto;padding:0}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonIABHeaderToggle{margin-left:0;margin-right:auto}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter #CybotCookiebotDialogBodyButtonsWrapper{flex:auto;flex-direction:column}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton{max-width:none;width:286px}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogFooter .CybotCookiebotDialogBodyButton:not(:first-of-type){margin-top:.5em}}#CybotCookiebotDialogBodyLevelWrapper{width:100%}#CybotCookiebotDialogBodyEdgeMoreDetails{display:none}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes{list-style-type:none}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyEdgeMoreDetails{display:flex;justify-content:flex-end;margin:1.5em 2em .5em 0}#CybotCookiebotDialog.CybotEdge[dir=rtl] #CybotCookiebotDialogBodyEdgeMoreDetails{margin-left:1.125em;margin-right:0}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyEdgeMoreDetails a{align-items:center;color:#000003;display:flex;font-weight:600;text-decoration:none}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyEdgeMoreDetails a:after{border-style:solid;border-width:.15em .15em 0 0;color:#000002;content:"";display:block;height:.563em;margin-left:1em;transform:rotate(45deg);width:.563em}#CybotCookiebotDialog.CybotEdge[dir=rtl] #CybotCookiebotDialogBodyEdgeMoreDetails a:after{margin-left:0;margin-right:1em;transform:rotate(225deg)}#CybotCookiebotDialogBodyLevelButtons{width:100%}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper{-webkit-backface-visibility:hidden;backface-visibility:hidden;display:flex;flex-shrink:0;height:32px;position:relative;width:57px}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper:hover input[type=checkbox]:not(:disabled)+.CybotCookiebotDialogBodyLevelButtonSlider{opacity:.85}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper input[type=checkbox].CybotCookiebotDialogBodyLevelButton{opacity:0}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSlider{background-color:#000002;border-radius:32px;bottom:0;left:0;pointer-events:none;position:absolute;right:0;top:0;transition:background-color .4s}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSlider:before{background-color:#000001;border-radius:50%;bottom:4px;content:"";height:24px;left:4px;position:absolute;transition:transform .4s;width:24px}#CybotCookiebotDialog input:checked+.CybotCookiebotDialogBodyLevelButtonSlider{background-color:#000003}#CybotCookiebotDialog input:checked+.CybotCookiebotDialogBodyLevelButtonSlider:before,#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogTabContent input+.CybotCookiebotDialogBodyLevelButtonSlider:before{background-color:#000017;transform:translateX(26px)}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogTabContent input:checked+.CybotCookiebotDialogBodyLevelButtonSlider:before{transform:translateX(0)}#CybotCookiebotDialog form input[type=checkbox][disabled]:checked+.CybotCookiebotDialogBodyLevelButtonSlider{background-color:#000004;pointer-events:none}#CybotCookiebotDialogBodyLevelButtonsSelectPane{border-bottom:1px solid #000004;padding:1em 0}#CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonWrapper{align-items:center;display:flex;justify-content:space-between;padding:1em;text-align:center;width:100%}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogBodyLevelButtonWrapper+.CybotCookiebotDialogBodyLevelButtonWrapper label{font-size:.875em;font-style:italic;font-weight:400;letter-spacing:.15px;padding-bottom:0}#CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonDescription{font-weight:700}#CybotCookiebotDialogBodyLevelButtonsSelectPane label:not([for=CybotCookiebotDialogBodyLevelButtonNecessary]) .CybotCookiebotDialogBodyLevelButtonDescription:hover{color:#000003}@media screen and (min-width:601px){#CybotCookiebotDialog #CybotCookiebotDialogBodyLevelButtonsSelectPane{padding:0}#CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonWrapper{flex-direction:column;padding:1.5em 1em;width:25%}#CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonWrapper:not(:last-of-type){border-right:1px solid #000004}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonWrapper:not(:last-of-type){border-left:1px solid #000004;border-right:none}#CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonLabel{margin-bottom:.75em}#CybotCookiebotDialogTabContent input:focus+.CybotCookiebotDialogBodyLevelButtonSlider{box-shadow:0 0 1px #000003}}@media screen and (min-width:1280px){#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyLevelButtonsSelectPane{border-bottom:none}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonWrapper{border:none;flex-direction:row;margin:.5em 2.5em 0 0;padding:0;width:auto}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonLabel{margin-bottom:0}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyLevelWrapper{width:auto}#CybotCookiebotDialog.CybotEdge .CybotCookiebotDialogBodyLevelButtonLabel{margin-right:1em}#CybotCookiebotDialog.CybotEdge[dir=rtl] .CybotCookiebotDialogBodyLevelButtonLabel{margin-left:1em;margin-right:0}#CybotCookiebotDialog.CybotEdge[dir=rtl] #CybotCookiebotDialogBodyLevelButtonsSelectPane .CybotCookiebotDialogBodyLevelButtonWrapper{border-left:none;margin:.5em 0 0 2.5em}#CybotCookiebotDialog.CybotEdge #CybotCookiebotDialogBodyEdgeMoreDetails{display:inline-flex;height:2em;margin:0}}#CybotCookiebotDialog input[type=checkbox]{height:1.5em;margin-right:.5em;width:1.5em}#CybotCookiebotDialog[dir=rtl] input[type=checkbox]{margin-left:.5em;margin-right:0}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper form{height:100%;width:100%}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper input[type=checkbox]{height:100%;margin-right:0;width:100%}#CybotCookiebotDialog #CybotCookiebotDialogDetailBodyContentIABv2Tabs input[type=checkbox]{-moz-appearance:none;-webkit-appearance:none;-o-appearance:none;background-color:#000001;border:2px solid #000004;border-radius:4px;position:relative}#CybotCookiebotDialog #CybotCookiebotDialogDetailBodyContentIABv2Tabs input[type=checkbox]:not(:checked):hover{border-color:#000002}#CybotCookiebotDialog #CybotCookiebotDialogDetailBodyContentIABv2Tabs input[type=checkbox]:checked{background-color:#000003;border-color:#000003}#CybotCookiebotDialog #CybotCookiebotDialogDetailBodyContentIABv2Tabs input[type=checkbox]:checked:after{border-bottom:2px solid #000001;border-right:2px solid #000001;content:"";display:inline-block;height:50%;left:50%;position:absolute;top:calc(50% - 2px);transform:translate(-50%,-50%) rotate(45deg);width:25%}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes,#CybotCookiebotDialogDetailBodyContentIABv2Tabs{padding:0 .625em;width:100%}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogDetailBodyContentIABv2TabsIntro{padding:1.125em 1.125em .25em}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogDetailBodyContentIABv2TabsIntro{padding:.5em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogDetailBodyContentIABv2TabsIntro:nth-child(3){margin-bottom:1.5em}.CybotCookiebotDialogDetailBodyContentCookieContainerHeader{display:flex;justify-content:space-between}.CybotCookiebotDialogDetailBodyContentCookieContainerButton:before,.CybotCookiebotDialogDetailBodyContentIABv2Tab:before{border-style:solid;border-width:.15em .15em 0 0;content:"";display:inline-block;height:.5em;left:0;margin-right:1.875em;position:relative;top:.625em;transform:rotate(-45deg);vertical-align:top;width:.5em}#CybotCookiebotDialog[dir=rtl] .CybotCookiebotDialogDetailBodyContentCookieContainerButton:before,#CybotCookiebotDialog[dir=rtl] .CybotCookiebotDialogDetailBodyContentIABv2Tab:before{margin-left:1.875em;margin-right:0}.CybotCookiebotDialogDetailBodyContentCookieContainerButton.CybotCookiebotDialogCollapsed:before,.CybotCookiebotDialogDetailBodyContentIABv2Tab.CybotCookiebotDialogCollapsed:before{top:.25em;transform:rotate(-225deg)}#CybotCookiebotDialog .CookieCard{border-bottom:1px solid #000004;padding:1.5em 0}#CybotCookiebotDialog.CybotCookiebotDialogZoomedXl .CookieCard:first-of-type{padding-top:.5em}#CybotCookiebotDialog .CookieCard:not(:first-child){padding-top:1.5em}#CybotCookiebotDialog #CybotCookiebotDialogDetailBodyContentIABContainer .CookieCard{border-bottom:none;border-top:1px solid #000004}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CookieCard:last-of-type{margin-bottom:1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CookieCard:first-of-type{padding-top:1.625em}#CybotCookiebotDialog .CookieCard .CybotCookiebotDialogDetailBodyContentCookieContainerButton,#CybotCookiebotDialog .CookieCard .CybotCookiebotDialogDetailBodyContentIABv2Tab{border:1px solid transparent;font-weight:700;line-height:1.5em;padding-right:.75em;user-select:none}#CybotCookiebotDialog[dir=rtl] .CookieCard .CybotCookiebotDialogDetailBodyContentCookieContainerButton,#CybotCookiebotDialog[dir=rtl] .CookieCard .CybotCookiebotDialogDetailBodyContentIABv2Tab{padding-left:.75em;padding-right:0}#CybotCookiebotDialog .CookieCard .CybotCookiebotDialogDetailBodyContentCookieContainerButton:hover,#CybotCookiebotDialog .CookieCard .CybotCookiebotDialogDetailBodyContentIABv2Tab:hover,#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider:not(.CybotCookiebotDialogDetailBodyContentCookieInfoCount):hover{color:#000003}#CybotCookiebotDialog .CookieCard .CybotCookiebotDialogDetailBodyContentCookieTypeIntro,#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CollapseCard{padding-top:1em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CollapseCard>div:not(.CybotCookiebotDialogBodyLevelButtonIABWrapper){letter-spacing:.3px;line-height:1.6em;margin-left:2.9em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogDetailBodyContentIABv2CardIntro{letter-spacing:.3px;line-height:1.6em;margin-left:2.9em;padding-top:1em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CollapseCard>div:not(.CybotCookiebotDialogBodyLevelButtonIABWrapper),#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CybotCookiebotDialogDetailBodyContentIABv2CardIntro{margin-left:0;margin-right:2.9em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyEmptyCategoryMessage{border:1px solid #000004;border-radius:.5em;font-weight:600;margin:1em 0;padding:1em 1.5em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieGroup{border:1px solid #000004;border-radius:.5em;margin-bottom:.5em;padding:1em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieGroup:not(.open):hover{background-color:rgba(0,0,0,.05)}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieGroup:last-of-type{margin-bottom:0}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider{display:block;font-weight:700;position:relative;text-decoration:none}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider>div{pointer-events:none}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider:not(.CybotCookiebotDialogDetailBodyContentCookieInfoCount){color:#000002}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider.CybotCookiebotDialogCollapsed:after,#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider:after{border-style:solid;border-width:.15em .15em 0 0;content:"";display:inline-block;height:.5em;position:absolute;right:1em;top:.5em;transform:rotate(-45deg);width:.5em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider.CybotCookiebotDialogCollapsed:after,#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider:after{left:1em;right:auto}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProvider.CybotCookiebotDialogCollapsed:after{transform:rotate(-225deg)}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieLink{align-items:center;display:inline-flex;padding-top:1em;position:relative}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfo{background-color:#000016;border:1px solid #000004;border-radius:1em;margin-bottom:.5em;padding:1em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfo:last-of-type{margin-bottom:0}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper.CybotCookiebotDialogShow{display:block}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper{margin-top:3.125em;position:relative}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper:before{border-top:1px solid #000004;content:"";left:0;position:absolute;top:-1.5em;width:100%}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProviderDescription{margin-bottom:1.56em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoTitle{display:block;font-weight:700;line-height:1.6em;margin-bottom:.5em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoDescription{display:block;letter-spacing:.3px;padding-bottom:1em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoFooter{border-top:1px solid #000004;display:flex;flex-wrap:wrap;padding-top:.5em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoFooterContent{margin-top:.5em;width:100%}@media screen and (min-width:1280px){#CybotCookiebotDialogDetailBodyContentCookieContainerTypes,#CybotCookiebotDialogDetailBodyContentIABv2Tabs{padding:0 1.125em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer{margin-top:2em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer,#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CollapseCard{margin-left:3em;padding-top:.5em}#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieTypeTableContainer,#CybotCookiebotDialog[dir=rtl] #CybotCookiebotDialogDetailBodyContentIABv2Tabs .CollapseCard{margin-left:0;margin-right:3em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CollapseCard>div:not(.CybotCookiebotDialogBodyLevelButtonIABWrapper){margin-left:0}#CybotCookiebotDialog .CookieCard{padding:1.125em 0 1.5em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CookieCard:last-of-type{margin-bottom:1.5em;padding-bottom:2em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CookieCard:first-of-type{padding-top:1.125em}#CybotCookiebotDialogDetailBodyContentIABv2Tabs .CookieCard:last-of-type{padding-bottom:1.125em}#CybotCookiebotDialog .CookieCard .CybotCookiebotDialogDetailBodyContentCookieTypeIntro{padding-left:3em}#CybotCookiebotDialog[dir=rtl] .CookieCard .CybotCookiebotDialogDetailBodyContentCookieTypeIntro{padding-left:0;padding-right:3em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyEmptyCategoryMessage{margin:0 0 1.5em;padding:1.5em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieGroup,#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfo{padding:1.5em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper{margin-top:3.75em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoWrapper:before{top:-2em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieProviderDescription{margin-bottom:1.875em}#CybotCookiebotDialogDetailBodyContentCookieContainerTypes .CybotCookiebotDialogDetailBodyContentCookieInfoFooterContent{width:50%}}#CybotCookiebotDialog .CybotCookiebotDialogHide{display:none}.CybotExpandLink{position:relative}.CybotExpandLink.CybotCookiebotDialogCollapsed:after,.CybotExpandLink:after{border-style:solid;border-width:.15em .15em 0 0;content:"";height:.5em;position:absolute;right:1em;top:.3em;transform:rotate(-45deg);width:.5em}#CybotCookiebotDialog[dir=rtl] .CybotExpandLink.CybotCookiebotDialogCollapsed:after,#CybotCookiebotDialog[dir=rtl] .CybotExpandLink:after{left:0;right:auto}.CybotExpandLink.CybotCookiebotDialogCollapsed:after{transform:rotate(-225deg)}#CybotCookiebotDialog .CybotExternalLinkArrow{margin-left:.625em}#CybotCookiebotDialog[dir=rtl] .CybotExternalLinkArrow{margin-left:0;margin-right:.625em;transform:scaleX(-1)}#CybotCookiebotDialog .CookieCard .CybotCookiebotDialogDetailBodyContentCookieContainerButton:not(:disabled):not(.disabled),#CybotCookiebotDialog .CookieCard .CybotCookiebotDialogDetailBodyContentIABv2Tab:not(:disabled):not(.disabled),#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper input[type=checkbox],#CybotCookiebotDialog button,#CybotCookiebotDialog input,#CybotCookiebotDialog label:not([for=CybotCookiebotDialogBodyLevelButtonNecessary]){cursor:pointer}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper input[type=checkbox]:disabled{pointer-events:none}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapperDisabled{cursor:not-allowed}#CybotCookiebotDialog dt{word-break:break-all}#CybotCookiebotDialog fieldset{border:none;width:100%}#CybotCookiebotDialog fieldset #CybotCookiebotDialogBodyFieldsetInnerContainer{display:flex;flex-wrap:wrap;width:100%}#CybotCookiebotDialog legend.visuallyhidden{display:block}#CybotCookiebotDialog .visuallyhidden{height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}#CybotCookiebotDialog #CybotCookiebotDialogBodyContentText a,#CybotCookiebotDialog #CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink,#CybotCookiebotDialog #CybotCookiebotDialogDetailBulkConsentList dt a,#CybotCookiebotDialog #CybotCookiebotDialogDetailFooter a,#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABDescription a,#CybotCookiebotDialog .CybotCookiebotDialogDetailBodyContentCookieLink,#CybotCookiebotDialogDetailBodyContentTextAbout a{color:#000023;font-weight:600;text-decoration:none}#CybotCookiebotDialog #CybotCookiebotDialogBodyContentText a:focus,#CybotCookiebotDialog #CybotCookiebotDialogBodyContentText a:hover,#CybotCookiebotDialog #CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink:focus,#CybotCookiebotDialog #CybotCookiebotDialogBodyLevelButtonIABHeaderViewPartnersLink:hover,#CybotCookiebotDialog #CybotCookiebotDialogDetailBulkConsentList dt a:focus,#CybotCookiebotDialog #CybotCookiebotDialogDetailBulkConsentList dt a:hover,#CybotCookiebotDialog #CybotCookiebotDialogDetailFooter a:focus,#CybotCookiebotDialog #CybotCookiebotDialogDetailFooter a:hover,#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABDescription a:focus,#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABDescription a:hover,#CybotCookiebotDialog .CybotCookiebotDialogDetailBodyContentCookieLink:focus,#CybotCookiebotDialog .CybotCookiebotDialogDetailBodyContentCookieLink:hover,#CybotCookiebotDialogDetailBodyContentTextAbout a:focus,#CybotCookiebotDialogDetailBodyContentTextAbout a:hover{text-decoration:underline}#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper input:focus-visible+span,#CybotCookiebotDialog :focus-visible,#CybotCookiebotDialog:focus-visible{outline:none}@media screen and (min-width:601px){#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper input:focus-visible+span,#CybotCookiebotDialog :focus-visible{outline:2px solid #000003}#CybotCookiebotDialog .CybotCookiebotBannerCloseButton:focus-visible,#CybotCookiebotDialog .CybotCookiebotDialogBodyButton:focus-visible,#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABHeaderButton:focus-visible,#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleDeselectVendorsLink:focus-visible,#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonIABHeaderToggleSelectVendorsLink:focus-visible,#CybotCookiebotDialog .CybotCookiebotDialogBodyLevelButtonSliderWrapper input:focus-visible+span{outline-offset:2px}}@media not all and (min-resolution:.001dpcm){@media screen and (min-width:1280px){#CybotCookiebotDialog #CybotCookiebotDialogBody .CybotCookiebotScrollContainer{display:block}}}#CookiebotSessionPixel{display:none}');
}
CookieConsent.handleCcpaOptinInFrontend = true;
var CookiebotDialog, CookieConsentDialog;
CookiebotDialog = CookieConsentDialog = new CookieControl.Dialog(CookieConsent, 'bottom-v2_white', 'This website uses cookies', 'We use cookies to personalize content and ads, to provide social media features and to analyze our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you’ve provided to them or that they’ve collected from your use of their services.&nbsp; <a href="https://www.bni.com/privacy-policy" title="Privacy Policy" target="_blank" style="">Privacy Policy</a> | <a href="https://www.bni.com/terms-and-conditions" title="Terms And Conditions" target="_blank" style="">Terms And Conditions</a>', 'Allow all cookies', 'Use necessary cookies only', 'leveloptin', null, false, 'strict', 'en', 'Cookies are small text files that can be used by websites to make a user\'s experience more efficient.<br style=""><br style="">The law states that we can store cookies on your device if they are strictly necessary for the operation of this site. For all other types of cookies we need your permission.<br style=""><br style="">This site uses different types of cookies. Some cookies are placed by third party services that appear on our pages.<br style=""><br style="">You can at any time change or withdraw your consent from the Cookie Declaration on our website.<br style=""><br style="">Learn more about who we are, how you can contact us and how we process personal data in our Privacy Policy.<br style=""><br style="">Please state your consent ID and date when you contact us regarding your consent.', 'Necessary cookies help make a website usable by enabling basic functions like page navigation and access to secure areas of the website. The website cannot function properly without these cookies.', 'Preference cookies enable a website to remember information that changes the way the website behaves or looks, like your preferred language or the region that you are in.', 'Statistic cookies help website owners to understand how visitors interact with websites by collecting and reporting information anonymously.', 'Marketing cookies are used to track visitors across websites. The intention is to display ads that are relevant and engaging for the individual user and thereby more valuable for publishers and third party advertisers.', 'Unclassified cookies are cookies that we are in the process of classifying, together with the providers of individual cookies.', 'OK', 'Allow all cookies', 'Allow selection', 'allowselectdecline', 'Hide details', 'Show details', 'Customize', 'Do not sell or share my personal information');
CookieConsentDialog.noCookiesTypeText = 'We do not use cookies of this type.';
CookieConsentDialog.aboutCookiesText = 'About';
CookieConsentDialog.cookiesOverviewText = 'Cookie declaration';
CookieConsentDialog.googleCookieDescription = 'Some of the data collected by this provider is for the purposes of personalization and measuring advertising effectiveness.';
CookieConsentDialog.consentTitle = 'Consent';
CookieConsentDialog.consentSelection = 'Consent Selection';
CookieConsentDialog.details = 'Details';
CookieConsentDialog.about = 'About';
CookieConsentDialog.domainConsent = 'Cross-domain consent';
CookieConsentDialog.domainConsentList = 'List of domains your consent applies to:';
CookieConsentDialog.providerLinkText = 'Learn more about this provider';
CookieConsentDialog.opensInNewWindowText = 'opens in a new window';
CookieConsentDialog.externalLinkIcon = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAC6SURBVHgBpdTdCcMgEAdwT/vk04EOkBG6QifpHH3rCF2hk3SVvBaEuoDYu4IgRRMv/iEkD/Hn+QnOuatS6gEAqDoJIQC/vfe594+m576FjAZKL6XXkSDiYox5UQFLXZEoNZJzXg9B/0hK6SKGWkiMcRVBewjnNIuURdIzyFBFo0jZPnoGqaMbCEqRJkSNIiFPCfILj7F1GLkySfvuqnFlShDxWesF6D76zF4jPJ/GWvum7/NRjBCegtsXQuuTY/odOJIAAAAASUVORK5CYII=';
CookieConsentDialog.externalLinkIconAltText = 'Arrow icon';
CookieConsentDialog.bannerCloseText = 'Close banner';
CookieConsentDialog.cookieHeaderTypeNecessary = 'Necessary ({0})';
CookieConsentDialog.cookieHeaderTypePreference = 'Preferences ({0})';
CookieConsentDialog.cookieHeaderTypeStatistics = 'Statistics ({0})';
CookieConsentDialog.cookieHeaderTypeAdvertising = 'Marketing ({0})';
CookieConsentDialog.cookieHeaderTypeUnclassified = 'Unclassified ({0})';
CookieConsentDialog.cookieTableHeaderName = 'Name';
CookieConsentDialog.cookieTableHeaderProvider = 'Provider';
CookieConsentDialog.cookieTableHeaderPurpose = 'Purpose';
CookieConsentDialog.cookieTableHeaderType = 'Type';
CookieConsentDialog.cookieTableHeaderExpiry = 'Maximum Storage Duration';
CookieConsentDialog.promotionBannerEnabled = false;
CookieConsentDialog.bulkconsentDomainsString = '';
CookieConsentDialog.domainlist = '<dl id=CybotCookiebotDialogDetailBulkConsentList><dt><a target=_blank href=https://www.bni.com rel="noopener noreferrer nofollow">www.bni.com</a></dt></dl>';
CookieConsentDialog.domainlistCount = '1';
CookieConsentDialog.bannerButtonDesign = 'mixed';
CookieConsentDialog.ucDataShieldPromotionBannerTitle = 'Tired of cookie banners?';
CookieConsentDialog.ucDataShieldPromotionBannerBody = 'Download our browser extension for FREE';
CookieConsentDialog.ucDataShieldPromotionBannerCTA = 'Install Usercentrics Data Shield';
CookieConsentDialog.impliedConsentOnScroll = true;
CookieConsentDialog.impliedConsentOnRefresh = false;
CookieConsentDialog.showLogo = true;
CookieConsentDialog.mandatoryText = 'Mandatory - can not be deselected.';
CookieConsentDialog.logoAltText = 'logo';
CookieConsentDialog.logoCookiebotAltText = 'Cookiebot';
CookieConsentDialog.logo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGoAAAAuCAYAAADA6IztAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAyBSURBVHhe7ZsLUFNXGsfp7Gt2uzt97sj6QhEs8hCQNwiICvIqPvBVa/FJd2lR2yJYFZUdFSxWpZUqtV1Lu1VXK7paHy3Y57ZM7ZhASAIkgUsSQhJCEnmLVHP2O9cTBsIFbuBGmep/5j864X7f+e753fO4Nzd2j/RIj/RIv04hhB4j/+0vUVDMl2LngNLy5zj0VP9SoWd4qWRRUqkmM6dU98npkl9OnI81mUwOpFnWMpy/fFDuFUHnZGyrt+EYynNWqfyNHdkk3Gp1CsSZ6oiFpWVOPsxt9HKZk29pQ0hcqfHKte0knBac52Rl2s7S8nFujHG9jXNUTfLmKTP3XoS4Z0iK/hL6zPlFPmkGkjr6cG6Z2U5+qGH2QlS/dJ26MTN7b6dKNYE0P6T0RRe/07mHIinLGmUTpiPNrAXIWPxtLlyhvyFpWKtdIDrdMnsRkkAepvy9LXHwQs0B0ch4qfgUCacFHe5uSM9C0menMsZh437B8Wo4L1VKetfNqyWzSDizRAFRRtFET1Q2yct2dvBEvLGuSDzOHSk8QpF8/kpNS9Hl3aSEQaU/e/Eq5RqMyqyoUTDmOaRZmYKaf/rJh6RhrQ5hVWFDxALEH+fGmLu3+RM8UL3vXABVcpyE0wJQropNW1HZM06Mcdg4VgoXgzZtp65dp5tBQgeWyD/S9qB6GRco/psr0s1JRPqjhUdJGQNqOKDwhVEJHV2fslkCnTaNpGKl+wHKDEmz4c2mZoXCl4QNrvsNymw+XPXasOdR07lLh0gpjBoWKDB/vAdqcJ2JVFm5V0gqVrI1KP7E6UgyHiC9mtHUoVT6kRAc8/igU/WDAlU22QsJx7ggxbL17be0WkdSTj8NFxR2OUy1Uo/QO41HPkwn6YaULUHxYRRJxnkApC1NHXp9IDncrpWiwo15BZTq7cNTyUf99cBAgfGJKt1CUMP+/PcH2pqOBBR2BUyz2gVJSH36XDhJOahsBQpDqp7giTQpm/UtjY3B5FC7zu7OkMYt/2xVxb2AWi6XjE5Q2OKxbki2JlVrK1DY1TDV1EQmXld///1fSdoBZQtQeLqrhvNsSEm/2Wk0ziSH2XWbTEHandnNMvhbVfwLpi5xjTP5U39ZA4oProCFWjJ5Rj8Lx7sjnr0LvZAzxQ5o2A2q4lZ03dYZlpOS+ogLULij5M7+SLt198/QiYPC4hoUDQmvlynpLa1KZRg5BB8T2Jh98KYU+o7/rDOqnv+iqYsv5gaUAPb9As/w1sqw+HJxaGyPK8OeL6+OX25smp+ExHAMD6AxxTOZj3eA0ctQ6w3+VlJSH3EBChvfHjQFxSDljpw9JDWjuATFf8qRhqRc/1pbp1rdAwlGUkDT3kN6KemrcugDTkHVwo1rZexSxl0UFDfNJKFW1W/bLatxCaRPgimHpXGHqKFjDGcupJFUfcQVKGzcIVRgVJf65GerSPp+4gqUfOObqOovDkiV/HpbW5Ws52YWIPnrdx/QSSd591zQtgEVvWTQ7S4U6aRat0kugiuJKYelcYdoZs1HTafOMe7MuASFp26RvSvSrN2IulSaeNJEH3EFqumVDKRMXN3RJhRGkI/xszwfw96DGhlMd71nHRuBWnyVhA4o9aEjP8im+LJar/gwJakjE01t5RUbSXgfcQkKmw811Tr6IGrVq3i9epw00yNOQBna3DtPX9Boiy5Eko8wPG/j/ny1bLIP4lnkfnCg8gpYgxLhe52EF/VwtT1JwvuIa1DY+GpWuIYg1f78YujAP5CmaHEBSnRG9HvI2/OA9bbJ5Gl8+4hG5ggjCc7XMs8DAQUdbi9fvEZWyWY0wY6IcvRF9dkHi0l4P9kCFG282wyKRlTarqWkKVpcgOotAOahB0g1MIotR5LZnIOiAFRV3PLPSWiPoBgHcLT6QEG0dNk6Xs3UABoCUw6z8XohHDMNqVf83dR7R2Qpm4ECC6GD6mKWdbb8eL1nveISFPSJu+GdY2r8pHwgSNicgxJO9kYVnmF6oc/sa8IZET2WLVvfoHtlC1KEJ6BK2HLiE2CKN5uGBDd5VHAMUu3LW0NKYZQtQeH1qhLq0GzY2tnV1UV3Uoeo6mMuQGFITbmH1bVw0fKgDaZ4szkHde+G1wvVwPrT23id4eGbOzYnB8fizpFDZ8jfyFxPyhhQtgSFjUd+rZM/UqRsPonb6xBXFapnLxwRKIA0XpP/QQM93Q0BCZtzUFxYOD0UqVelKvVnL6wmJQwqq0HBKMEXA+PfBjA+Xu0XibRHj+d063Q7lKHxqIzFTfsgoDw0r21DvCcmMcZZelSBwg8lBTD6DIWnkKnt1mzS/JCyChTewDj7IllAFP2oC88AjMdZGj/JH+uOqgPn3VTlHFpd4RHaWjHEGos9CCjGp+cDefSNKLzGuQUjWXCsQbM5i9fJFwz4hMAsa0Dh6UoaEov0p87xyqb4tglYjAqz8XolAovnLLwL6/CdsocaFBh/oVcBU40E/jUsXoPkW3btJKUwyipQAKYhJA613xBsU2zf+4HKI4z+jOnYgSzA0yYLSNi/alBm4yu43H4aqnWbiVQc3UdhKGoApT97aRfcz/22LnFNcQ1+Oo2nRIbjR+qHApTZAhhZlFsIqt3w5oifnptBGc5fzsGxHRQVoFmZckcEHcF6vbLCoxYUPlkBFFcFnVsFmwNGw7Qhgn+tmXIEUKguYSVq/vZ/K0hZPRoeqEs97/U1/utEEhUY/YsAb7dh08AUN1yPWlDlAKg6dlm7as8BqXLXvr7OypUqd2RL61IzpFUxS3Uq/yhUzuIeAhtPTdLx05E8I0sIU9afSWm0RgoKi1qXulHtM4fVvZE1HrWg8LM+SeLqq9CZjw1mKNSh5djH2VX+kbfwCyZMuSwtGOuKJFGJd7vEfYvlAhTU9GRDetZ1Cm4P+BPZff3CxqMaVOW8xaxfv2rMe/+/dXQns9jqwmitD5iHmku+3U/CaXEBCktbUTGmdsFLUgnk4WpzMbpBsfiaw6z2sorPFL4w5cAJMeXrbXylq2B6UuUePkzCaXEFCquFV7EWv5GE30xiirfWvxpQN7/4+pTCM5zViMLHKOFY+aZteSScFpegsFT5x9Kl3rNMZSzXz8E8akFRTv6oKnZpv685mGTq7vanEl4slTj6MObqZzOotB02BYVFbdhyXOsZQR/PlIetRycoBy+EOx12dD8pt+eEKbfssvDuMCpte5hkUVKY+p2jJ+rXbuquphdv9nf5DTD1afIKjpDSaNkCFGwuHFWpGTL8htBI1qtRO6JwpwtdAlFtSCyqDY7p76BoJPMKR7Kp/vQuji0k2nDSCv+ou82fF28jpdGyBSisxitfTZEvTOoS2U9jzMXGoxYUbdz5eMuNpw0Gl+O/D+MqFdi7IMmClXdRXZ09KY2WrUBhGb7+PlsbuZjuKKZ8Q3l0g7KB8ciTT/FDyszsr+Ek/0hKo2VLUFiqzOy3pFP97+IRzZRzMD90oAQw/SjmLW3t/Jnf70V+W4PCqt+6myeH6dqqqRr8UIHCv5MyzFqAlHkFO0hJfXQ/QHV3dPspXnhZa+3NsC1BGS9cjr9ztDC18d1j974Jf1CgcIfgkaQOjUfGT8+U4Mc8dEEWuh+gsJT73/OTBUXr8c9XmXIzmWtQLQSU7j9F640H3jOhi18idP4LVJeakX/fQeHpBX9xiJ+7yeNW3G7Zl7cKIP2JPkMG3S9QWLrCkzlNYQn0O39M+S3NNahbIpETjm/Yc5BvzP/wRt0/0n7QHv5ARL38xof3QE2wASg8hQAUfDI8KERIvhqpey4QUXMXdSleeuXfuqvXhvyRcQ8oFjWOFBRcML+DG+6Papz97u1iGdro7SFBPT2FMc7S+AvUPqB27+ffOnvxOrV2I6UuKLykPXL8Ozux31zUMMWf/v0Qp3YJQgr3UFQP+XVRS5B4Zly7Jvl1seFQwafNX1zzp8+IhfRFF39s9oqgd4WM7fQyNXkG6pqdiG6ev9Ln6YY1gk5+Wr55Z4faOQDVOQ3eJuXogzpCYOq+XHKGhNOCHB5tW/cg+RhXxjhLKyZ6I23iGtT6zY8uOF6V++7q1rcOm1pOFJ3o+Ogk0rxzTG9XGZGQVOkSnCxw5dYiv7nJlTFLkqnUjGRT8TfJt3U6b/osrJThwqVoOeRiasPSZc4ByQ1RS5Kbiq70/Ih5OOquqwvUxiyn8zG1Y3aZC7QXnpDc+uVXfd70hZH5lDwjK1kw0ZMxrp+d/ZJli1evN5bceIKksFNu2zOvPTc/ubvgk5fbhRJP8vEjjW7Z2f0fYrgrIdw1bckAAAAASUVORK5CYII=';
CookieConsentDialog.prechecked.preferences = false;
CookieConsentDialog.prechecked.statistics = false;
CookieConsentDialog.prechecked.marketing = false;
CookieConsentDialog.optionaloptinSettings.displayConsentBanner = false;
CookieConsentDialog.bannerCloseButtonEnabled = true;
CookieConsentDialog.lastUpdatedText = 'Cookie declaration last updated on {0} by <a href="https://www.cookiebot.com" target="_blank" rel="noopener" title="Cookiebot">Cookiebot</a>';
CookieConsentDialog.lastUpdatedDate = 1746401281283;
CookieConsentDialog.cookieTableNecessary = [
    ["__cf_bm", "app-ab24.marketo.com<br/>vimeo.com<br/>www2.bni.com", "This cookie is used to distinguish between humans and bots. This is beneficial for the website, in order to make valid reports on the use of their website.", "1 day", "HTTP Cookie", "1", "^__cf_bm$", "app-ab24.marketo.com<br/>vimeo.com<br/>www2.bni.com", "en"],
    ["BIGipServer#", "app-ab24.marketo.com<br/>www2.bni.com", "Used to distribute traffic to the website on several servers in order to optimise response times.", "Session", "HTTP Cookie", "1", "^BIGipServer.*", "app-ab24.marketo.com<br/>www2.bni.com", "en"],
    ["bcookie", "linkedin.com", "Used in order to detect spam and improve the website's security. ", "1 year", "HTTP Cookie", "1", "", "linkedin.com", "en"],
    ["li_gc", "linkedin.com", "Stores the user's cookie consent state for the current domain", "180 days", "HTTP Cookie", "1", "", "linkedin.com", "en"],
    ["_cfuvid", "vimeo.com", "This cookie is a part of the services provided by Cloudflare - Including load-balancing, deliverance of website content and serving DNS connection for website operators. ", "Session", "HTTP Cookie", "1", "", "vimeo.com", "en"],
    ["CookieConsent", "www.bni.com<br/>www2.bni.com", "Stores the user's cookie consent state for the current domain", "1 year", "HTTP Cookie", "1", "", "consent.cookiebot.com<br/>www2.bni.com", "en"],
    ["wpEmojiSettingsSupports", "www.bni.com", "This cookie is part of a bundle of cookies which serve the purpose of content delivery and presentation. The cookies keep the correct state of font, blog/picture sliders, color themes and other website settings.", "Session", "HTML Local Storage", "2", "", "www.bni.com", "en"]
];
CookieConsentDialog.cookieTablePreference = [
    ["lidc", "linkedin.com", "Registers which server-cluster is serving the visitor. This is used in context with load balancing, in order to optimize user experience.  ", "1 day", "HTTP Cookie", "1", "", "linkedin.com", "en"],
    ["maps/gen_204", "maps.googleapis.com", "Used in context with the website's map integration. The cookie stores user interaction with the map in order to optimize its functionality.", "Session", "Pixel Tracker", "5", "", "maps.googleapis.com", "en"]
];
CookieConsentDialog.cookieTableStatistics = [
    ["_ga", "bni.com", "Registers a unique ID that is used to generate statistical data on how the visitor uses the website.", "2 years", "HTTP Cookie", "1", "", "www.googletagmanager.com", "en"],
    ["_ga_#", "bni.com", "Used by Google Analytics to collect data on the number of times a user has visited the website as well as dates for the first and most recent visit. ", "2 years", "HTTP Cookie", "1", "^_ga_[\\dA-Za-z]{8,}$", "www.googletagmanager.com", "en"]
];
CookieConsentDialog.cookieTableAdvertising = [
    ["_fbp", "bni.com", "Used by Facebook to deliver a series of advertisement products such as real time bidding from third party advertisers.", "3 months", "HTTP Cookie", "1", "", "connect.facebook.net", "en"],
    ["lastExternalReferrer", "connect.facebook.net", "Detects how the user reached the website by registering their last URL-address.", "Persistent", "HTML Local Storage", "2", "", "connect.facebook.net", "en"],
    ["lastExternalReferrerTime", "connect.facebook.net", "Detects how the user reached the website by registering their last URL-address.", "Persistent", "HTML Local Storage", "2", "", "connect.facebook.net", "en"],
    ["NID", "google.com", "Registers a unique ID that identifies a returning user's device. The ID is used for targeted ads.", "6 months", "HTTP Cookie", "1", "", "google.com", "en"],
    ["#-#", "youtube.com", "Used to track user’s interaction with embedded content.", "Session", "HTML Local Storage", "2", "^\\d+-\\d$", "www.youtube.com", "en"],
    ["__Secure-ROLLOUT_TOKEN", "youtube.com", "Pending", "180 days", "HTTP Cookie", "1", "", "youtube.com", null],
    ["iU5q-!O9@$", "youtube.com", "Registers a unique ID to keep statistics of what videos from YouTube the user has seen.", "Session", "HTML Local Storage", "2", "", "www.youtube.com", "en"],
    ["LAST_RESULT_ENTRY_KEY", "youtube.com", "Used to track user’s interaction with embedded content.", "Session", "HTTP Cookie", "1", "", "www.youtube.com", "en"],
    ["LogsDatabaseV2:V#||LogsRequestsStore", "youtube.com", "Used to track user’s interaction with embedded content.", "Persistent", "IndexedDB", "6", "^LogsDatabaseV2:V[\\a-f]{8}\\|\\|#LogsRequestsStore$", "www.youtube.com", "en"],
    ["nextId", "youtube.com", "Used to track user’s interaction with embedded content.", "Session", "HTTP Cookie", "1", "", "www.youtube.com", "en"],
    ["remote_sid", "youtube.com", "Necessary for the implementation and functionality of YouTube video-content on the website.  ", "Session", "HTTP Cookie", "1", "", "www.youtube.com", "en"],
    ["requests", "youtube.com", "Used to track user’s interaction with embedded content.", "Session", "HTTP Cookie", "1", "", "www.youtube.com", "en"],
    ["ServiceWorkerLogsDatabase#SWHealthLog", "youtube.com", "Necessary for the implementation and functionality of YouTube video-content on the website.  ", "Persistent", "IndexedDB", "6", "", "www.youtube.com", "en"],
    ["TESTCOOKIESENABLED", "youtube.com", "Used to track user’s interaction with embedded content.", "1 day", "HTTP Cookie", "1", "", "www.youtube.com", "en"],
    ["VISITOR_INFO1_LIVE", "youtube.com", "Tries to estimate the users' bandwidth on pages with integrated YouTube videos.", "180 days", "HTTP Cookie", "1", "", "youtube.com", "en"],
    ["YSC", "youtube.com", "Registers a unique ID to keep statistics of what videos from YouTube the user has seen.", "Session", "HTTP Cookie", "1", "", "youtube.com", "en"],
    ["YtIdbMeta#databases", "youtube.com", "Used to track user’s interaction with embedded content.", "Persistent", "IndexedDB", "6", "", "www.youtube.com", "en"],
    ["yt-remote-cast-available", "youtube.com", "Stores the user's video player preferences using embedded YouTube video", "Session", "HTML Local Storage", "2", "", "www.youtube.com", "en"],
    ["yt-remote-cast-installed", "youtube.com", "Stores the user's video player preferences using embedded YouTube video", "Session", "HTML Local Storage", "2", "", "www.youtube.com", "en"],
    ["yt-remote-connected-devices", "youtube.com", "Stores the user's video player preferences using embedded YouTube video", "Persistent", "HTML Local Storage", "2", "", "www.youtube.com", "en"],
    ["yt-remote-device-id", "youtube.com", "Stores the user's video player preferences using embedded YouTube video", "Persistent", "HTML Local Storage", "2", "", "www.youtube.com", "en"],
    ["yt-remote-fast-check-period", "youtube.com", "Stores the user's video player preferences using embedded YouTube video", "Session", "HTML Local Storage", "2", "", "www.youtube.com", "en"],
    ["yt-remote-session-app", "youtube.com", "Stores the user's video player preferences using embedded YouTube video", "Session", "HTML Local Storage", "2", "", "www.youtube.com", "en"],
    ["yt-remote-session-name", "youtube.com", "Stores the user's video player preferences using embedded YouTube video", "Session", "HTML Local Storage", "2", "", "www.youtube.com", "en"]
];
CookieConsentDialog.cookieTableUnclassified = [
    ["cf.turnstile.u", "challenges.cloudflare.com", "Pending", "Persistent", "HTML Local Storage", "2", "", "challenges.cloudflare.com", null],
    ["topicsLastReferenceTime", "connect.facebook.net", "Pending", "Persistent", "HTML Local Storage", "2", "", "connect.facebook.net", null],
    ["limit", "www.bni.com", "Pending", "Session", "HTTP Cookie", "1", "", "cdnjs.cloudflare.com", null],
    ["limit_category", "www.bni.com", "Pending", "Session", "HTTP Cookie", "1", "", "cdnjs.cloudflare.com", null],
    ["limit_post", "www.bni.com", "Pending", "Session", "HTTP Cookie", "1", "", "cdnjs.cloudflare.com", null],
    ["page", "www.bni.com", "Pending", "Session", "HTTP Cookie", "1", "", "cdnjs.cloudflare.com", null],
    ["ppc_last_visited_page", "www.bni.com", "Pending", "1 day", "HTTP Cookie", "1", "", "www.bni.com", null]
];
CookieConsentDialog.cookieTableNecessaryCount = 11;
CookieConsentDialog.cookieTablePreferenceCount = 2;
CookieConsentDialog.cookieTableStatisticsCount = 2;
CookieConsentDialog.cookieTableAdvertisingCount = 24;
CookieConsentDialog.cookieTableUnclassifiedCount = 7;
CookieConsent.whitelist = ["__cf_bm", "BIGipServer#", "bcookie", "li_gc", "_cfuvid", "CookieConsent", "wpEmojiSettingsSupports"];
CookieConsentDialog.privacyPolicies = [
    ["app-ab24.marketo.com", "Marketo", "https://legal.marketo.com/privacy/"],
    ["cdnjs.cloudflare.com", "Cloudflare", "https://www.cloudflare.com/privacypolicy/"],
    ["challenges.cloudflare.com", "Cloudflare", "https://www.cloudflare.com/privacypolicy/"],
    ["connect.facebook.net", " Meta Platforms, Inc.", "https://www.facebook.com/policy.php/"],
    ["consent.cookiebot.com", "Cookiebot", "https://www.cookiebot.com/goto/privacy-policy/"],
    ["google.com", "Google", "https://business.safety.google/privacy/"],
    ["linkedin.com", "LinkedIn", "https://www.linkedin.com/legal/privacy-policy"],
    ["maps.googleapis.com", "Google", "https://business.safety.google/privacy/"],
    ["vimeo.com", "Vimeo", "https://vimeo.com/privacy"],
    ["www.googletagmanager.com", "Google", "https://business.safety.google/privacy/"],
    ["www.youtube.com", "YouTube", "https://business.safety.google/privacy/"],
    ["youtube.com", "YouTube", "https://business.safety.google/privacy/"]
];
CookieConsentDialog.privacyPolicyText = '{0}\'s privacy policy';
CookieConsentDialog.userCountry = 'IN';
CookieConsent.userCountry = 'IN';
CookieConsent.updateRegulations();
CookieConsentDialog.userCulture = 'en-US';